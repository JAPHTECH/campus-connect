
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Textarea } from "@/components/ui/textarea";
import { ArrowLeft, Star, MapPin, Phone, MessageCircle, Heart, Share2, Send } from "lucide-react";
import { Link, useParams } from "react-router-dom";
import { useToast } from "@/hooks/use-toast";

const ItemDetail = () => {
  const { id } = useParams();
  const { toast } = useToast();
  const [showChat, setShowChat] = useState(false);
  const [isFavorited, setIsFavorited] = useState(false);
  const [chatMessage, setChatMessage] = useState("");

  // Mock item data - in real app, this would be fetched based on ID
  const item = {
    id: 1,
    title: "MacBook Pro 13\" M1",
    price: "1,200,000",
    category: "Electronics",
    condition: "Used - Good",
    location: "UDSM Main Campus",
    seller: "John Mwanza",
    sellerRating: 4.8,
    sellerPhone: "+255712345678",
    contactMethod: "whatsapp",
    images: [
      "https://images.unsplash.com/photo-1517336714731-489689fd1ca8?w=800&h=600&fit=crop",
      "https://images.unsplash.com/photo-1541807084-5c52b6b3adef?w=800&h=600&fit=crop"
    ],
    description: "MacBook Pro 13-inch with M1 chip in excellent working condition. Comes with original charger and box. Perfect for students and professionals. Battery health is at 89%. No scratches on the screen, minor wear on the corners.",
    postedDate: "2 days ago",
    specifications: {
      "Processor": "Apple M1 Chip",
      "RAM": "8GB",
      "Storage": "256GB SSD",
      "Screen": "13.3-inch Retina",
      "Year": "2021"
    }
  };

  const handleWhatsAppClick = () => {
    const message = encodeURIComponent("Hi! I'm interested in your MacBook Pro. Is this still available please?");
    const whatsappUrl = `https://wa.me/${item.sellerPhone.replace('+', '')}?text=${message}`;
    window.open(whatsappUrl, '_blank');
  };

  const handleChatSubmit = () => {
    if (chatMessage.trim()) {
      console.log("Chat message sent:", chatMessage);
      toast({
        title: "Message Sent",
        description: "Your message has been sent to the seller.",
      });
      setChatMessage("");
    }
  };

  const handleSaveItem = () => {
    setIsFavorited(!isFavorited);
    toast({
      title: isFavorited ? "Item Removed" : "Item Saved",
      description: isFavorited ? "Item removed from your saved list." : "Item added to your saved list.",
    });
  };

  const handleShare = () => {
    if (navigator.share) {
      navigator.share({
        title: item.title,
        text: `Check out this ${item.title} for ${item.price} TSh`,
        url: window.location.href,
      });
    } else {
      navigator.clipboard.writeText(window.location.href);
      toast({
        title: "Link Copied",
        description: "Item link has been copied to clipboard.",
      });
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <Link to="/marketplace" className="flex items-center space-x-2 text-purple-600 hover:text-purple-700">
              <ArrowLeft className="h-5 w-5" />
              <span>Back to Marketplace</span>
            </Link>
            <div className="flex items-center space-x-2">
              <Button
                variant="outline"
                size="sm"
                onClick={handleSaveItem}
                className={isFavorited ? "text-red-600 border-red-200" : ""}
              >
                <Heart className={`h-4 w-4 mr-1 ${isFavorited ? 'fill-red-600' : ''}`} />
                {isFavorited ? 'Saved' : 'Save'}
              </Button>
              <Button variant="outline" size="sm" onClick={handleShare}>
                <Share2 className="h-4 w-4 mr-1" />
                Share
              </Button>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Images Section */}
          <div className="space-y-4">
            <div className="aspect-square bg-gray-200 rounded-lg overflow-hidden">
              <img 
                src={item.images[0]} 
                alt={item.title}
                className="w-full h-full object-cover"
              />
            </div>
            <div className="grid grid-cols-3 gap-2">
              {item.images.slice(1).map((image, index) => (
                <div key={index} className="aspect-square bg-gray-200 rounded-lg overflow-hidden">
                  <img 
                    src={image} 
                    alt={`${item.title} ${index + 2}`}
                    className="w-full h-full object-cover cursor-pointer hover:opacity-75"
                  />
                </div>
              ))}
            </div>
          </div>

          {/* Details Section */}
          <div className="space-y-6">
            <div>
              <div className="flex items-center justify-between mb-2">
                <Badge variant="secondary">{item.category}</Badge>
                <Badge className="bg-green-100 text-green-800">{item.condition}</Badge>
              </div>
              <h1 className="text-3xl font-bold text-gray-900 mb-2">{item.title}</h1>
              <div className="text-3xl font-bold text-purple-600 mb-4">{item.price} TSh</div>
              <div className="flex items-center space-x-2 text-gray-600 mb-4">
                <MapPin className="h-4 w-4" />
                <span>{item.location}</span>
                <span>•</span>
                <span>{item.postedDate}</span>
              </div>
            </div>

            {/* Seller Info */}
            <Card>
              <CardContent className="p-4">
                <div className="flex items-center space-x-3">
                  <Avatar className="h-12 w-12">
                    <AvatarFallback className="bg-purple-100 text-purple-700">
                      {item.seller.split(' ').map(n => n[0]).join('')}
                    </AvatarFallback>
                  </Avatar>
                  <div className="flex-1">
                    <h3 className="font-semibold text-gray-900">{item.seller}</h3>
                    <div className="flex items-center space-x-1">
                      <Star className="h-4 w-4 fill-yellow-400 text-yellow-400" />
                      <span className="text-sm text-gray-600">{item.sellerRating} rating</span>
                    </div>
                  </div>
                  <div className="flex space-x-2">
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => setShowChat(!showChat)}
                      className="text-blue-600 border-blue-200"
                    >
                      <MessageCircle className="h-4 w-4 mr-1" />
                      Chat
                    </Button>
                    <Button
                      size="sm"
                      onClick={handleWhatsAppClick}
                      className="bg-green-600 hover:bg-green-700"
                    >
                      <Phone className="h-4 w-4 mr-1" />
                      WhatsApp
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Description */}
            <Card>
              <CardHeader>
                <CardTitle>Description</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-700">{item.description}</p>
              </CardContent>
            </Card>

            {/* Specifications */}
            <Card>
              <CardHeader>
                <CardTitle>Specifications</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  {Object.entries(item.specifications).map(([key, value]) => (
                    <div key={key} className="flex justify-between">
                      <span className="text-gray-600">{key}:</span>
                      <span className="font-medium">{value}</span>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Action Buttons */}
            <div className="flex space-x-4">
              <Button 
                className="flex-1 bg-purple-600 hover:bg-purple-700"
                onClick={handleWhatsAppClick}
              >
                Contact Seller
              </Button>
              <Button variant="outline" className="flex-1">
                Make Offer
              </Button>
            </div>
          </div>
        </div>

        {/* Chat Section */}
        {showChat && (
          <Card className="mt-8 bg-blue-50 border-blue-200">
            <CardContent className="p-6">
              <h3 className="font-semibold text-blue-900 mb-4">Chat with {item.seller}</h3>
              <div className="bg-white rounded-lg p-4 mb-4 max-h-60 overflow-y-auto">
                <div className="space-y-3">
                  <div className="bg-gray-100 p-3 rounded-lg">
                    <p className="text-sm">Hi! I'm interested in your {item.title}.</p>
                    <span className="text-xs text-gray-500">You - just now</span>
                  </div>
                </div>
              </div>
              <div className="flex space-x-2">
                <Textarea
                  placeholder="Type your message..."
                  value={chatMessage}
                  onChange={(e) => setChatMessage(e.target.value)}
                  className="flex-1 min-h-[60px] bg-white"
                />
                <Button 
                  onClick={handleChatSubmit}
                  className="bg-blue-600 hover:bg-blue-700"
                >
                  <Send className="h-4 w-4" />
                </Button>
              </div>
            </CardContent>
          </Card>
        )}
      </main>
    </div>
  );
};

export default ItemDetail;
