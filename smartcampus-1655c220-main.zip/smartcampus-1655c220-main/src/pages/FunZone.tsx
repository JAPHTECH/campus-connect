
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Search, Laugh, Sparkles, Star } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { useIsMobile } from "@/hooks/use-mobile";
import { FunHeader } from "@/components/fun-zone/FunHeader";
import { WelcomeBanner } from "@/components/fun-zone/WelcomeBanner";
import { QuickPost } from "@/components/fun-zone/QuickPost";
import { FunContentCard } from "@/components/fun-zone/FunContentCard";
import { DailyGames } from "@/components/fun-zone/DailyGames";
import { SwahiliMemes } from "@/components/fun-zone/SwahiliMemes";
import { UniversityNews } from "@/components/fun-zone/UniversityNews";

import { funContent } from "@/components/fun-zone/mockData";

const FunZone = () => {
  const { toast } = useToast();
  const isMobile = useIsMobile();
  const [searchTerm, setSearchTerm] = useState("");
  const [newPost, setNewPost] = useState("");
  const [selectedPoll, setSelectedPoll] = useState<{[key: number]: string}>({});

  const filteredContent = funContent.filter(content => {
    const matchesSearch = content.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         content.author.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         content.content?.toLowerCase().includes(searchTerm.toLowerCase());
    return matchesSearch;
  });

  const handleUploadMeme = () => {
    console.log("Upload meme clicked");
    toast({
      title: "Pakia Meme 📸",
      description: "Kipengele cha kupakia meme kinakuja hivi karibuni! Ngoja kidogo ili uweze kushare content ya kuchekesha, rafiki!",
    });
  };

  const handlePhotoUpload = () => {
    console.log("Photo upload clicked");
    toast({
      title: "Pakia Picha 📷",
      description: "Kipengele cha kupakia picha kimeanzishwa! Share moments zako za campus, bana!",
    });
  };

  const handleCreatePoll = () => {
    console.log("Create poll clicked");
    toast({
      title: "Unda Poll 🗳️",
      description: "Kipengele cha kuunda poll kimeanzishwa! Unda polls za kuvutia kwa wanafunzi wenzako, mkuu!",
    });
  };

  const handleReaction = (postId: number, reactionType: string) => {
    console.log(`Reacted with ${reactionType} to post ${postId}`);
    const reactionEmojis = {
      laugh: "😂",
      fire: "🔥", 
      heart: "❤️",
      brain: "🤔"
    };
    toast({
      title: "Reaction Imeongezwa! 🎉",
      description: `Umereact na ${reactionEmojis[reactionType as keyof typeof reactionEmojis]} - poa sana, jamani!`,
    });
  };

  const handlePollVote = (postId: number, optionIndex: number) => {
    setSelectedPoll({ ...selectedPoll, [postId]: optionIndex.toString() });
    toast({
      title: "Kura Imerekodi! 🗳️",
      description: "Asante sana kushiriki kwenye poll hii, mkuu wa Tanzania!",
    });
  };

  const handleShare = (postId: number, title: string) => {
    if (navigator.share) {
      navigator.share({
        title: title,
        text: "Angalia hii post ya fun kutoka UDSM Fun Zone, bana!",
        url: window.location.href
      });
    } else {
      navigator.clipboard.writeText(window.location.href + `#post-${postId}`);
      toast({
        title: "Link Imekopiwa! 📋",
        description: "Link ya post imekopiwa kwenye clipboard - share na marafiki wako!",
      });
    }
  };

  const handleNewPost = () => {
    if (newPost.trim()) {
      console.log("New post:", newPost);
      toast({
        title: "Post Imeshare! 🎉",
        description: "Content yako ya fun imeshare na jamii! Poa kabisa, ndugu!",
      });
      setNewPost("");
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 via-blue-50 to-green-50 relative overflow-hidden">
      {/* Animated background elements */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-10 left-10 w-20 h-20 bg-blue-200 rounded-full opacity-20 animate-pulse"></div>
        <div className="absolute top-32 right-20 w-16 h-16 bg-purple-200 rounded-full opacity-30 animate-bounce" style={{animationDelay: '1s'}}></div>
        <div className="absolute bottom-20 left-1/4 w-12 h-12 bg-green-200 rounded-full opacity-25 animate-ping" style={{animationDelay: '2s'}}></div>
        <div className="absolute bottom-40 right-1/3 w-8 h-8 bg-yellow-200 rounded-full opacity-20 animate-pulse" style={{animationDelay: '0.5s'}}></div>
        <Sparkles className="absolute top-1/4 left-1/3 w-6 h-6 text-purple-300 opacity-40 animate-spin" style={{animationDuration: '3s'}} />
        <Star className="absolute bottom-1/3 right-1/4 w-5 h-5 text-blue-300 opacity-30 animate-pulse" />
      </div>

      <FunHeader onUploadMeme={handleUploadMeme} />

      <main className="max-w-6xl mx-auto px-2 sm:px-4 lg:px-6 py-3 sm:py-4 relative z-10 pb-4">
        <WelcomeBanner />

        <QuickPost
          newPost={newPost}
          setNewPost={setNewPost}
          onNewPost={handleNewPost}
          onPhotoUpload={handlePhotoUpload}
          onCreatePoll={handleCreatePoll}
        />

        {/* Enhanced Fun Zone Features */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-3 sm:gap-4 mb-4">
          <DailyGames />
          <SwahiliMemes />
        </div>

        <div className="mb-4">
          <UniversityNews />
        </div>

        {/* Search Bar with Swanglish */}
        <div className="mb-4 sm:mb-6 animate-fade-in" style={{animationDelay: '0.2s'}}>
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4 sm:h-5 sm:w-5" />
            <Input
              placeholder={isMobile ? "Tafuta kitu..." : "Tafuta memes, mazungumzo ya moto, polls... vyote vipo hapa, bana!"}
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-9 sm:pl-10 py-2 sm:py-3 text-sm sm:text-lg bg-white/60 backdrop-blur-sm border-white/20 rounded-lg focus:bg-white/80 transition-all duration-300"
            />
          </div>
        </div>

        {/* Fun Content */}
        <div className="space-y-4 sm:space-y-6">
          {filteredContent.map((content, index) => (
            <FunContentCard
              key={content.id}
              content={content}
              index={index}
              selectedPoll={selectedPoll}
              onReaction={handleReaction}
              onPollVote={handlePollVote}
              onShare={handleShare}
            />
          ))}
        </div>

        {/* Empty State with Swanglish */}
        {filteredContent.length === 0 && (
          <div className="text-center py-8 sm:py-12 animate-bounce-in px-4">
            <div className="text-gray-400 mb-4">
              <Laugh className="h-12 w-12 sm:h-16 sm:w-16 mx-auto animate-pulse" />
            </div>
            <h3 className="text-base sm:text-lg font-medium bg-gradient-to-r from-gray-600 to-gray-800 bg-clip-text text-transparent mb-2">
              Hakuna fun content hapa, jamani
            </h3>
            <p className="text-gray-600 mb-4 text-sm sm:text-base">
              Kuwa wa kwanza kushare kitu cha fun, ndugu wa Tanzania!
            </p>
            <Button 
              onClick={() => { setSearchTerm(""); }}
              className="bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 text-white shadow-lg hover:shadow-xl transition-all duration-300 hover:scale-105 transform text-sm w-full sm:w-auto"
            >
              Share Kitu cha Fun! 🎉 Twende pamoja tucheze!
            </Button>
          </div>
        )}
      </main>
    </div>
  );
};

export default FunZone;
