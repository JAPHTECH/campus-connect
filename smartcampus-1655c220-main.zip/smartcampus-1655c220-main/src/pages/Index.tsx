import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { 
  BookOpen, 
  Users, 
  Home, 
  ShoppingCart, 
  MessageSquare, 
  Calendar, 
  User, 
  Star,
  TrendingUp,
  Heart,
  Clock,
  ArrowRight,
  Sparkles
} from "lucide-react";
import { Link } from "react-router-dom";
import { useAuth } from "@/contexts/AuthContext";
import { OnboardingFlow } from "@/components/OnboardingFlow";
import { WelcomeCard } from "@/components/WelcomeCard";
import { UDSMNewsBanner } from "@/components/UDSMNewsBanner";

const Index = () => {
  const { user, profile, signOut } = useAuth();
  const [currentTipIndex, setCurrentTipIndex] = useState(0);
  const [currentWelcomeIndex, setCurrentWelcomeIndex] = useState(0);
  const [currentSubtitleIndex, setCurrentSubtitleIndex] = useState(0);
  const [showOnboarding, setShowOnboarding] = useState(false);
  const [showWelcomeCard, setShowWelcomeCard] = useState(false);

  // Enhanced welcome messages with more greetings
  const welcomeMessages = [
    "Karibu", // Swahili
    "Niaje", // Colloquial Swahili
    "你好", // Chinese
    "Bienvenido", // Spanish
    "Welcome", // English
    "Bienvenue", // French
    "Willkommen" // German
  ];

  // Alternating subtitle messages with different Swanglish vibes
  const subtitleMessages = [
    "Tutafanya kazi pamoja! Let's get it! 🔥",
    "We ni sharp! Ready kusoma? 📚",
    "Mambo vipi? Time ya success! 🚀",
    "Tuko pamoja bro! Academic excellence loading... ⚡",
    "Sawa sawa! Time ya hustle! 💪",
    "Poa kichizi! Let's make it happen! ✨",
    "Vitu ni poa! Ready ku-conquer? 🎯",
    "Built by Huncho ✨"
  ];

  // Enhanced UDSM-specific study tips
  const studyTips = [
    "Study smart at UDSM Library - success is guaranteed! 📚",
    "Join study groups with your coursemates - teamwork makes the dream work! 🤝",
    "Past papers from UDSM archives are game changers! 📝",
    "The Main Library is your second home - utilize it fully! 🏛️",
    "Consistency beats perfection - keep up with your coursework! ⚡",
    "Network with UDSM seniors - connections matter for your career! 🌟",
    "Use UDSM WiFi zones effectively for online research! 📡",
    "Attend UDSM seminars and workshops for extra knowledge! 🎓",
    "Check UDSM academic calendar for important deadlines! 📅",
    "Visit UDSM career center for internship opportunities! 💼"
  ];

  // Check if user is new (first login)
  useEffect(() => {
    if (user && !localStorage.getItem('hasSeenOnboarding')) {
      setShowOnboarding(true);
    }
  }, [user]);

  // Check if user should see welcome card (first time after signup)
  useEffect(() => {
    if (user && !localStorage.getItem('hasSeenWelcomeCard')) {
      // Show welcome card after a short delay for better UX
      const timer = setTimeout(() => {
        setShowWelcomeCard(true);
      }, 1000);
      return () => clearTimeout(timer);
    }
  }, [user]);

  // Detect user language and set initial welcome message
  useEffect(() => {
    const userLang = navigator.language || navigator.languages[0];
    if (userLang.startsWith('sw') || userLang.includes('TZ')) {
      setCurrentWelcomeIndex(0); // Swahili first
    } else if (userLang.startsWith('zh')) {
      setCurrentWelcomeIndex(2); // Chinese first
    } else if (userLang.startsWith('es')) {
      setCurrentWelcomeIndex(3); // Spanish first
    } else if (userLang.startsWith('fr')) {
      setCurrentWelcomeIndex(5); // French first
    } else if (userLang.startsWith('de')) {
      setCurrentWelcomeIndex(6); // German first
    } else {
      setCurrentWelcomeIndex(4); // English first
    }
  }, []);

  // Animate welcome messages every 2 seconds
  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentWelcomeIndex((prev) => (prev + 1) % welcomeMessages.length);
    }, 2000);
    return () => clearInterval(interval);
  }, []);

  // Animate subtitle messages every 3 seconds
  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentSubtitleIndex((prev) => (prev + 1) % subtitleMessages.length);
    }, 3000);
    return () => clearInterval(interval);
  }, []);

  // Animate study tips
  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentTipIndex((prev) => (prev + 1) % studyTips.length);
    }, 4000);
    return () => clearInterval(interval);
  }, []);

  // Get display name from profile settings first, then fallback to user metadata
  const getDisplayName = () => {
    if (profile?.full_name) {
      return profile.full_name;
    }
    if (user?.user_metadata?.full_name) {
      return user.user_metadata.full_name;
    }
    if (user?.email) {
      const emailName = user.email.split('@')[0];
      return emailName.charAt(0).toUpperCase() + emailName.slice(1);
    }
    return 'Student';
  };

  const handleWelcomeCardDismiss = () => {
    setShowWelcomeCard(false);
    localStorage.setItem('hasSeenWelcomeCard', 'true');
  };

  const quickActions = [
    { 
      title: "Study Materials", 
      subtitle: "Notes & Past Papers",
      icon: BookOpen, 
      color: "from-blue-500 to-blue-600", 
      href: "/resources",
      description: "500+ study materials",
      emoji: "📚"
    },
    { 
      title: "Hostels", 
      subtitle: "Find Accommodation",
      icon: Home, 
      color: "from-green-500 to-green-600", 
      href: "/hostels",
      description: "Best hostels near campus",
      emoji: "🏠"
    },
    { 
      title: "Marketplace", 
      subtitle: "Buy & Sell",
      icon: ShoppingCart, 
      color: "from-purple-500 to-purple-600", 
      href: "/marketplace",
      description: "Affordable items",
      emoji: "🛒"
    },
    { 
      title: "Fun Zone", 
      subtitle: "Memes & Entertainment",
      icon: MessageSquare, 
      color: "from-orange-500 to-orange-600", 
      href: "/fun-zone",
      description: "Share memes & have fun",
      emoji: "😂"
    },
    { 
      title: "Timetable", 
      subtitle: "Class Schedule",
      icon: Calendar, 
      color: "from-indigo-500 to-indigo-600", 
      href: "/timetable",
      description: "Organize your classes",
      emoji: "📅"
    },
    { 
      title: "Profile", 
      subtitle: "Your Account",
      icon: User, 
      color: "from-pink-500 to-pink-600", 
      href: "/profile",
      description: "Manage your account",
      emoji: "👤"
    },
  ];

  const recentActivity = [
    { action: "New Chemistry notes uploaded", time: "2 hours ago", icon: BookOpen, color: "text-blue-500" },
    { action: "Hostel near UDSM campus available", time: "5 hours ago", icon: Home, color: "text-green-500" },
    { action: "Hilarious meme shared in Fun Zone", time: "1 day ago", icon: MessageSquare, color: "text-orange-500" },
    { action: "Marketplace item sold", time: "2 days ago", icon: ShoppingCart, color: "text-purple-500" },
  ];

  const stats = [
    { label: "Active Students", value: "1,200+", icon: Users, color: "from-blue-500 to-blue-600" },
    { label: "Study Materials", value: "500+", icon: BookOpen, color: "from-green-500 to-green-600" },
    { label: "Available Hostels", value: "150+", icon: Home, color: "from-purple-500 to-purple-600" },
    { label: "Marketplace Items", value: "300+", icon: ShoppingCart, color: "from-orange-500 to-orange-600" },
  ];

  if (!user) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-purple-900 via-blue-900 to-indigo-900 flex items-center justify-center p-4 relative overflow-hidden">
        {/* Animated background elements */}
        <div className="absolute inset-0 overflow-hidden pointer-events-none">
          <div className="absolute top-10 left-10 w-20 h-20 bg-blue-200 rounded-full opacity-20 animate-pulse"></div>
          <div className="absolute top-32 right-20 w-16 h-16 bg-purple-200 rounded-full opacity-30 animate-bounce" style={{animationDelay: '1s'}}></div>
          <div className="absolute bottom-20 left-1/4 w-12 h-12 bg-green-200 rounded-full opacity-25 animate-ping" style={{animationDelay: '2s'}}></div>
          <Sparkles className="absolute top-1/4 left-1/3 w-6 h-6 text-purple-300 opacity-40 animate-spin" style={{animationDuration: '3s'}} />
          <Star className="absolute bottom-1/3 right-1/4 w-5 h-5 text-blue-300 opacity-30 animate-pulse" />
        </div>
        
        <Card className="w-full max-w-md bg-white/10 backdrop-blur-xl border-white/20 shadow-2xl animate-scale-in hover:shadow-3xl transition-all duration-300">
          <CardHeader className="text-center">
            <div className="mx-auto bg-gradient-to-r from-blue-400 to-purple-400 p-3 rounded-xl w-fit mb-4 animate-pulse">
              <BookOpen className="h-8 w-8 text-white" />
            </div>
            <CardTitle className="text-2xl font-bold text-white animate-fade-in">UDSM Hub ✨</CardTitle>
            <CardDescription className="text-blue-200 animate-fade-in" style={{animationDelay: '0.2s'}}>
              Welcome to your digital campus! Join the community! 🚀
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <Link to="/auth">
              <Button className="w-full bg-gradient-to-r from-blue-500 to-purple-500 hover:from-blue-600 hover:to-purple-600 text-white shadow-lg hover:shadow-xl transition-all duration-300 h-12 hover:scale-105 transform animate-fade-in" style={{animationDelay: '0.4s'}}>
                🎓 Sign In or Join Now
              </Button>
            </Link>
            <p className="text-center text-blue-200 text-sm animate-fade-in" style={{animationDelay: '0.6s'}}>
              Access study materials, hostels, marketplace and more! 
            </p>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <>
      {showOnboarding && (
        <OnboardingFlow onComplete={() => {
          setShowOnboarding(false);
          localStorage.setItem('hasSeenOnboarding', 'true');
        }} />
      )}

      {showWelcomeCard && (
        <WelcomeCard 
          userName={getDisplayName()}
          onDismiss={handleWelcomeCardDismiss}
        />
      )}
      
      <div className="min-h-screen bg-gradient-to-br from-purple-50 via-blue-50 to-green-50 pb-20 relative overflow-hidden">
        {/* Animated background elements */}
        <div className="absolute inset-0 overflow-hidden pointer-events-none">
          <div className="absolute top-10 left-10 w-20 h-20 bg-blue-200 rounded-full opacity-20 animate-pulse"></div>
          <div className="absolute top-32 right-20 w-16 h-16 bg-purple-200 rounded-full opacity-30 animate-bounce" style={{animationDelay: '1s'}}></div>
          <div className="absolute bottom-20 left-1/4 w-12 h-12 bg-green-200 rounded-full opacity-25 animate-ping" style={{animationDelay: '2s'}}></div>
          <div className="absolute bottom-40 right-1/3 w-8 h-8 bg-yellow-200 rounded-full opacity-20 animate-pulse" style={{animationDelay: '0.5s'}}></div>
          <Sparkles className="absolute top-1/4 left-1/3 w-6 h-6 text-purple-300 opacity-40 animate-spin" style={{animationDuration: '3s'}} />
          <Star className="absolute bottom-1/3 right-1/4 w-5 h-5 text-blue-300 opacity-30 animate-pulse" />
        </div>

        {/* Main Content */}
        <div className="max-w-6xl mx-auto px-4 py-6 relative z-10">
          {/* Welcome Section with Enhanced Animation */}
          <div className="text-center mb-4 sm:mb-6">
            <div className="mb-3">
              <h2 className="text-xl sm:text-2xl md:text-3xl font-bold text-gray-800 mb-2 animate-fade-in leading-tight">
                <span 
                  key={currentWelcomeIndex}
                  className="inline-block transition-all duration-500 transform animate-scale-in"
                >
                  {welcomeMessages[currentWelcomeIndex]}! ✨
                </span>
              </h2>
              <div className="text-lg sm:text-xl md:text-2xl font-bold text-blue-600 mb-2 animate-fade-in animate-scale-in">
                <span className="inline-block hover:scale-105 transition-transform duration-300">
                  {getDisplayName()}
                </span>
              </div>
              <p className="text-gray-600 text-sm sm:text-base md:text-lg mb-3 sm:mb-4 animate-fade-in px-2" style={{animationDelay: '0.2s'}}>
                <span 
                  key={currentSubtitleIndex}
                  className="inline-block transition-all duration-500 transform animate-scale-in"
                >
                  {subtitleMessages[currentSubtitleIndex]}
                </span>
              </p>
            </div>
            
            {/* Enhanced Tip ya Leo with Glassmorphism */}
            <div className="bg-gradient-to-r from-blue-500/90 to-purple-500/90 backdrop-blur-xl text-white rounded-xl p-3 max-w-sm mx-auto shadow-lg border border-white/20 animate-scale-in hover:scale-105 transition-transform duration-300" style={{animationDelay: '0.4s'}}>
              <div className="flex items-center justify-center space-x-2 text-xs mb-2">
                <Star className="h-3 w-3 text-yellow-300 animate-pulse" />
                <span className="text-yellow-200 font-medium">Tip ya Leo:</span>
              </div>
              <p className="text-white transition-all duration-500 text-xs sm:text-sm leading-relaxed" key={currentTipIndex}>
                {studyTips[currentTipIndex]}
              </p>
            </div>
          </div>

          {/* Stats Cards with Glassmorphism */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-2 mb-4">
            {stats.map((stat, index) => (
              <Card key={index} className="bg-white/60 backdrop-blur-sm shadow-lg border border-white/20 hover:shadow-xl transition-all duration-300 hover:bg-white/70 hover:scale-105 animate-fade-in" style={{animationDelay: `${index * 0.1}s`}}>
                <CardContent className="p-2 sm:p-3 text-center">
                  <div className={`bg-gradient-to-r ${stat.color} text-white p-1.5 rounded-lg inline-flex mb-1.5 animate-pulse`}>
                    <stat.icon className="h-3 w-3 sm:h-4 sm:w-4" />
                  </div>
                  <div className="text-sm sm:text-lg md:text-xl font-bold text-gray-800">{stat.value}</div>
                  <div className="text-xs text-gray-600 leading-tight">{stat.label}</div>
                </CardContent>
              </Card>
            ))}
          </div>

          {/* Quick Actions Grid with Enhanced Animations */}
          <div className="mb-4">
            <h3 className="text-base sm:text-lg md:text-xl font-bold text-gray-800 mb-3 text-center animate-fade-in">
              What would you like to do today? 🤔
            </h3>
            <div className="grid grid-cols-2 sm:grid-cols-2 md:grid-cols-3 gap-2 sm:gap-3">
              {quickActions.map((action, index) => (
                <Link key={index} to={action.href}>
                  <Card className="bg-white/60 backdrop-blur-sm shadow-lg border border-white/20 hover:shadow-xl transition-all duration-300 hover:-translate-y-1 group h-full hover:bg-white/70 animate-scale-in hover:scale-105 min-h-[100px] sm:min-h-[120px]" style={{animationDelay: `${index * 0.1}s`}}>
                    <CardContent className="p-2 sm:p-3 text-center h-full flex flex-col justify-between">
                      <div>
                        <div className={`bg-gradient-to-r ${action.color} text-white p-1.5 sm:p-2 rounded-lg inline-flex mb-1.5 sm:mb-2 group-hover:scale-110 transition-transform duration-300`}>
                          <action.icon className="h-3 w-3 sm:h-4 sm:w-4" />
                        </div>
                        <div className="text-lg sm:text-xl mb-1">{action.emoji}</div>
                        <h4 className="font-bold text-gray-800 mb-0.5 text-xs sm:text-sm group-hover:text-blue-600 transition-colors leading-tight">
                          {action.title}
                        </h4>
                        <p className="text-xs text-gray-600 mb-0.5">{action.subtitle}</p>
                        <p className="text-xs text-gray-500 hidden sm:block">{action.description}</p>
                      </div>
                      <div className="flex items-center justify-center mt-1 sm:mt-2 text-blue-500 group-hover:text-blue-600 transition-colors">
                        <span className="text-xs font-medium mr-1">Access</span>
                        <ArrowRight className="h-2 w-2 sm:h-3 sm:w-3 group-hover:translate-x-1 transition-transform" />
                      </div>
                    </CardContent>
                  </Card>
                </Link>
              ))}
            </div>
          </div>

          {/* UDSM News Banner */}
          <UDSMNewsBanner />

          {/* Recent Activity with Glassmorphism */}
          <Card className="bg-white/60 backdrop-blur-sm shadow-xl border border-white/20 mb-4 sm:mb-6 hover:bg-white/70 transition-all duration-300 animate-fade-in" style={{animationDelay: '0.6s'}}>
            <CardHeader className="pb-3">
              <CardTitle className="flex items-center space-x-2 text-base sm:text-lg">
                <TrendingUp className="h-4 w-4 sm:h-5 sm:w-5 text-green-500 animate-pulse" />
                <span>Recent Activity 📈</span>
              </CardTitle>
              <CardDescription className="text-sm">See what's happening on campus</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-2 sm:space-y-3">
                {recentActivity.map((activity, index) => (
                  <div key={index} className="flex items-center space-x-3 p-2 sm:p-2.5 bg-gradient-to-r from-gray-50/80 to-blue-50/80 backdrop-blur-sm rounded-lg hover:shadow-md transition-all duration-300 group border border-white/20 hover:scale-105">
                    <activity.icon className={`h-3 w-3 sm:h-4 sm:w-4 ${activity.color} group-hover:scale-110 transition-transform`} />
                    <div className="flex-1">
                      <span className="text-gray-700 text-xs sm:text-sm group-hover:text-blue-600 transition-colors">{activity.action}</span>
                      <div className="text-xs text-gray-500 flex items-center mt-1">
                        <Clock className="h-3 w-3 mr-1" />
                        {activity.time}
                      </div>
                    </div>
                    <ArrowRight className="h-3 w-3 text-gray-400 group-hover:text-blue-500 group-hover:translate-x-1 transition-all" />
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Footer with Glassmorphism */}
          <div className="text-center">
            <div className="bg-white/60 backdrop-blur-sm rounded-lg p-3 sm:p-4 border border-white/20 shadow-lg hover:bg-white/70 transition-all duration-300 animate-scale-in hover:scale-105" style={{animationDelay: '0.8s'}}>
              <div className="flex items-center justify-center space-x-2 mb-2">
                <Heart className="h-4 w-4 text-red-500 animate-pulse" />
                <span className="text-gray-600 text-xs sm:text-sm">
                  Built with love by <span className="text-blue-600 font-semibold">Japhet Jr</span> ❤️
                </span>
              </div>
              <p className="text-gray-500 text-xs">
                East Africa's Premier Student Platform 🌍
              </p>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default Index;
