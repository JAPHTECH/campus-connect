
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { ArrowLeft, Bell, Check, X, MessageSquare, Users, BookOpen, ShoppingBag } from "lucide-react";
import { Link } from "react-router-dom";
import { useToast } from "@/hooks/use-toast";

const Notifications = () => {
  const { toast } = useToast();
  const [notifications, setNotifications] = useState([
    {
      id: 1,
      type: 'message',
      icon: MessageSquare,
      title: 'New forum reply',
      message: 'Someone replied to your post in "Study Tips"',
      time: '2 hours ago',
      unread: true
    },
    {
      id: 2,
      type: 'community',
      icon: Users,
      title: 'New study group',
      message: 'A new study group for Mathematics has been created',
      time: '5 hours ago',
      unread: true
    },
    {
      id: 3,
      type: 'resource',
      icon: BookOpen,
      title: 'Resource uploaded',
      message: 'New past papers for Computer Science uploaded',
      time: '1 day ago',
      unread: false
    },
    {
      id: 4,
      type: 'marketplace',
      icon: ShoppingBag,
      title: 'Item sold',
      message: 'Your textbook has been sold successfully',
      time: '2 days ago',
      unread: false
    },
    {
      id: 5,
      type: 'tip',
      icon: Bell,
      title: 'New Tip ya Leo',
      message: 'Today\'s study tip: Use UDSM WiFi zones effectively!',
      time: '3 hours ago',
      unread: true
    }
  ]);

  const getIconColor = (type: string) => {
    switch (type) {
      case 'message': return 'text-blue-500';
      case 'community': return 'text-purple-500';
      case 'resource': return 'text-green-500';
      case 'marketplace': return 'text-orange-500';
      case 'tip': return 'text-yellow-500';
      default: return 'text-gray-500';
    }
  };

  const markAllAsRead = () => {
    setNotifications(prev => prev.map(notif => ({ ...notif, unread: false })));
    toast({
      title: "Notifications marked as read",
      description: "All notifications have been marked as read.",
    });
  };

  const removeNotification = (id: number) => {
    setNotifications(prev => prev.filter(notif => notif.id !== id));
    toast({
      title: "Notification removed",
      description: "The notification has been removed.",
    });
  };

  const markAsRead = (id: number) => {
    setNotifications(prev => prev.map(notif => 
      notif.id === id ? { ...notif, unread: false } : notif
    ));
  };

  const unreadCount = notifications.filter(n => n.unread).length;

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-indigo-100 pb-20">
      {/* Header */}
      <div className="bg-gradient-to-r from-blue-600 via-purple-600 to-indigo-600 text-white">
        <div className="max-w-4xl mx-auto px-4 py-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <Link to="/profile">
                <Button variant="ghost" size="sm" className="text-white hover:bg-white/20 transition-all duration-300">
                  <ArrowLeft className="h-4 w-4" />
                </Button>
              </Link>
              <div>
                <h1 className="text-2xl font-bold">Notifications</h1>
                {unreadCount > 0 && (
                  <p className="text-blue-200 text-sm">{unreadCount} unread notifications</p>
                )}
              </div>
            </div>
            <Button 
              variant="ghost" 
              size="sm" 
              className="text-white hover:bg-white/20 transition-all duration-300"
              onClick={markAllAsRead}
            >
              <Check className="h-4 w-4 mr-2" />
              Mark All Read
            </Button>
          </div>
        </div>
      </div>

      {/* Content */}
      <div className="max-w-2xl mx-auto px-4 -mt-8">
        <Card className="shadow-xl border-0 bg-white/80 backdrop-blur-sm">
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <Bell className="h-5 w-5" />
              <span>All Notifications</span>
            </CardTitle>
            <CardDescription>Stay updated with your latest activities</CardDescription>
          </CardHeader>
          <CardContent className="space-y-3">
            {notifications.length === 0 ? (
              <div className="text-center py-8">
                <Bell className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                <p className="text-gray-600">No notifications yet</p>
              </div>
            ) : (
              notifications.map((notification) => (
                <div
                  key={notification.id}
                  className={`flex items-start space-x-3 p-3 rounded-lg transition-all duration-300 hover:bg-blue-50 cursor-pointer ${
                    notification.unread ? 'bg-blue-50/50 border border-blue-200' : 'bg-gray-50'
                  }`}
                  onClick={() => markAsRead(notification.id)}
                >
                  <div className={`p-2 rounded-lg bg-white shadow-sm ${getIconColor(notification.type)}`}>
                    <notification.icon className="h-4 w-4" />
                  </div>
                  <div className="flex-1">
                    <div className="flex items-center justify-between">
                      <h3 className="font-medium text-gray-900">{notification.title}</h3>
                      {notification.unread && (
                        <Badge variant="secondary" className="bg-blue-100 text-blue-700">
                          New
                        </Badge>
                      )}
                    </div>
                    <p className="text-sm text-gray-600 mt-1">{notification.message}</p>
                    <p className="text-xs text-gray-500 mt-2">{notification.time}</p>
                  </div>
                  <Button 
                    variant="ghost" 
                    size="sm" 
                    className="text-gray-400 hover:text-gray-600 transition-colors duration-300"
                    onClick={(e) => {
                      e.stopPropagation();
                      removeNotification(notification.id);
                    }}
                  >
                    <X className="h-4 w-4" />
                  </Button>
                </div>
              ))
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default Notifications;
