import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { 
  User, 
  Mail, 
  Phone, 
  MapPin, 
  Calendar, 
  Book, 
  Trophy, 
  Star, 
  Edit,
  Settings,
  Heart,
  Download,
  Share,
  Bell,
  Shield,
  Zap,
  TrendingUp,
  Award,
  Target,
  Crown,
  ArrowLeft
} from "lucide-react";
import { useAuth } from "@/contexts/AuthContext";
import { Link, useNavigate } from "react-router-dom";
import { toast } from "sonner";
import { NotificationBadge } from "@/components/NotificationBadge";
import { OnboardingFlow } from "@/components/OnboardingFlow";
import { HelpCenter } from "@/components/HelpCenter";
import { SignOutConfirmDialog } from "@/components/SignOutConfirmDialog";

const Profile = () => {
  const { user, profile, signOut } = useAuth();
  const navigate = useNavigate();
  const [showOnboarding, setShowOnboarding] = useState(false);
  const [showSignOutDialog, setShowSignOutDialog] = useState(false);
  const [showHelpCenter, setShowHelpCenter] = useState(false);
  const [unreadNotifications, setUnreadNotifications] = useState(3);

  console.log('User data:', user);
  console.log('Profile data:', profile);

  // Check if user needs onboarding
  useEffect(() => {
    const hasCompletedOnboarding = localStorage.getItem('onboarding_completed');
    if (!hasCompletedOnboarding && user) {
      setTimeout(() => setShowOnboarding(true), 1000);
    }
  }, [user]);

  // Get display name from user or profile data
  const getDisplayName = () => {
    if (profile?.full_name) {
      return profile.full_name;
    }
    if (user?.user_metadata?.full_name) {
      return user.user_metadata.full_name;
    }
    if (user?.email) {
      // Extract name from email before @ symbol and capitalize
      const emailName = user.email.split('@')[0];
      return emailName.charAt(0).toUpperCase() + emailName.slice(1);
    }
    return 'UDSM Student';
  };

  const getUserEmail = () => {
    return user?.email || "student@udsm.ac.tz";
  };

  const getUserPhone = () => {
    return profile?.phone || "+255 123 456 789";
  };

  const getUserLocation = () => {
    return profile?.location || "Dar es Salaam, Tanzania";
  };

  const getUserCourse = () => {
    return profile?.course || "Computer Science";
  };

  const getUserYear = () => {
    return profile?.year || "Year 3";
  };

  const getJoinDate = () => {
    if (user?.created_at) {
      return new Date(user.created_at).toLocaleDateString('en-US', {
        year: 'numeric',
        month: 'long',
        day: 'numeric'
      });
    }
    return "Recently";
  };

  const handleSignOut = async () => {
    try {
      console.log('Starting sign out process');
      await signOut();
      toast.success('Logged out successfully!');
      setShowSignOutDialog(false);
      navigate('/auth');
    } catch (error) {
      console.error('Sign out error:', error);
      toast.error('Error signing out. Please try again.');
    }
  };

  // Enhanced user data with actual user info
  const userProfile = {
    name: getDisplayName(),
    email: getUserEmail(),
    phone: getUserPhone(),
    location: getUserLocation(),
    joinDate: getJoinDate(),
    course: getUserCourse(),
    year: getUserYear(),
    gpa: "3.8",
    completedCourses: 24,
    badges: ["Top Contributor", "Study Group Leader", "Resource Sharer", "Campus Legend"],
    achievements: [
      { title: "Academic Excellence", points: 1200, icon: Trophy, color: "text-yellow-500" },
      { title: "Community Helper", points: 850, icon: Star, color: "text-purple-500" },
      { title: "Resource Master", points: 650, icon: Book, color: "text-blue-500" },
    ],
    stats: [
      { label: "Resources Shared", value: "45", icon: Book, color: "bg-blue-500" },
      { label: "Forum Posts", value: "128", icon: User, color: "bg-purple-500" },
      { label: "Study Hours", value: "1,240", icon: Calendar, color: "bg-green-500" },
      { label: "Reputation", value: "4.9", icon: Star, color: "bg-yellow-500" },
    ],
    recentActivity: [
      { action: "Shared Chemistry Notes", time: "2 hours ago", icon: Book },
      { action: "Joined Physics Study Group", time: "1 day ago", icon: User },
      { action: "Uploaded Calculus Past Paper", time: "3 days ago", icon: Download },
      { action: "Helped student in Forum", time: "1 week ago", icon: Heart },
    ]
  };

  const quickActions = [
    { title: "Edit Profile", icon: Edit, color: "bg-blue-500", href: "/edit-profile" },
    { title: "Settings", icon: Settings, color: "bg-gray-500", href: "/settings" },
    { title: "Notifications", icon: Bell, color: "bg-purple-500", href: "/notifications", hasNotification: true },
    { title: "Privacy", icon: Shield, color: "bg-green-500", href: "/privacy" },
  ];

  const getInitials = () => {
    const name = getDisplayName();
    return name.split(' ').map(n => n[0]).join('').substring(0, 2).toUpperCase();
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-indigo-100 pb-6">
      {/* Mobile-optimized Header with Glassmorphism */}
      <div className="bg-gradient-to-r from-blue-600 via-purple-600 to-indigo-600 text-white relative overflow-hidden">
        <div className="absolute top-0 right-0 w-32 h-32 bg-white/10 rounded-full -translate-y-16 translate-x-16 md:w-64 md:h-64 md:-translate-y-32 md:translate-x-32"></div>
        <div className="absolute bottom-0 left-0 w-24 h-24 bg-white/5 rounded-full translate-y-12 -translate-x-12 md:w-48 md:h-48 md:translate-y-24 md:-translate-x-24"></div>
        
        <div className="relative max-w-4xl mx-auto px-4 py-6">
          {/* Back Button */}
          <div className="mb-4">
            <Link to="/">
              <Button variant="ghost" size="sm" className="text-white hover:bg-white/20 transition-all duration-300">
                <ArrowLeft className="h-4 w-4 mr-2" />
                Back Home
              </Button>
            </Link>
          </div>

          <div className="flex flex-col items-center text-center space-y-4">
            {/* Profile Avatar */}
            <div className="relative group">
              <Avatar className="w-20 h-20 md:w-28 md:h-28 border-4 border-white/20 shadow-2xl group-hover:scale-110 transition-all duration-500">
                <AvatarImage src={profile?.avatar_url || "/placeholder.svg"} />
                <AvatarFallback className="bg-gradient-to-r from-blue-500 to-purple-500 text-white text-xl md:text-3xl font-bold">
                  {getInitials()}
                </AvatarFallback>
              </Avatar>
              <div className="absolute -bottom-1 -right-1 md:-bottom-2 md:-right-2 bg-gradient-to-r from-yellow-400 to-orange-400 text-black p-1.5 md:p-2 rounded-full shadow-lg">
                <Crown className="h-3 w-3 md:h-5 md:w-5" />
              </div>
            </div>

            {/* User Info */}
            <div className="space-y-2">
              <h1 className="text-2xl md:text-4xl font-bold">{userProfile.name}</h1>
              <p className="text-blue-100 text-lg md:text-xl">{userProfile.course} • {userProfile.year}</p>
              <div className="flex flex-col md:flex-row items-center justify-center space-y-2 md:space-y-0 md:space-x-4 text-sm text-blue-200">
                <div className="flex items-center space-x-1">
                  <MapPin className="h-4 w-4" />
                  <span>{userProfile.location}</span>
                </div>
                <div className="flex items-center space-x-1">
                  <Calendar className="h-4 w-4" />
                  <span>Joined {userProfile.joinDate}</span>
                </div>
              </div>
            </div>

            {/* Premium Badge */}
            <Badge className="bg-gradient-to-r from-yellow-400 to-orange-400 text-black border-0 shadow-lg px-3 py-1.5 md:px-4 md:py-2">
              Campus Legend
            </Badge>

            {/* Quick Stats */}
            <div className="grid grid-cols-2 gap-4 w-full max-w-sm mt-6">
              <div className="bg-white/10 backdrop-blur-sm rounded-lg p-3 md:p-4 text-center hover:bg-white/20 transition-all duration-300">
                <div className="text-2xl md:text-3xl font-bold">85%</div>
                <div className="text-xs md:text-sm text-blue-200">Attendance Rate</div>
              </div>
              <div className="bg-white/10 backdrop-blur-sm rounded-lg p-3 md:p-4 text-center hover:bg-white/20 transition-all duration-300">
                <div className="text-2xl md:text-3xl font-bold">{userProfile.completedCourses}</div>
                <div className="text-xs md:text-sm text-blue-200">Courses Done</div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="max-w-4xl mx-auto px-4 -mt-6">
        {/* Quick Actions with Notification Badge */}
        <Card className="mb-4 shadow-xl border-0 bg-white/60 backdrop-blur-sm border border-white/20">
          <CardHeader className="pb-3">
            <CardTitle className="flex items-center space-x-2 text-lg">
              <Zap className="h-5 w-5 text-yellow-500" />
              <span>Quick Actions</span>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 gap-3">
              {quickActions.map((action, index) => (
                <Link key={index} to={action.href}>
                  <div className="flex items-center space-x-3 p-3 rounded-lg bg-gradient-to-r from-slate-50/80 to-blue-50/80 hover:from-blue-50/80 hover:to-indigo-50/80 transition-all duration-300 cursor-pointer group backdrop-blur-sm border border-white/20">
                    <div className={`${action.color} text-white p-2 rounded-lg group-hover:scale-110 transition-all duration-300 shadow-lg`}>
                      {action.hasNotification ? (
                        <NotificationBadge count={unreadNotifications}>
                          <action.icon className="h-4 w-4" />
                        </NotificationBadge>
                      ) : (
                        <action.icon className="h-4 w-4" />
                      )}
                    </div>
                    <span className="font-medium text-gray-700 group-hover:text-blue-600 transition-colors text-sm md:text-base">{action.title}</span>
                  </div>
                </Link>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Stats Grid with Glassmorphism */}
        <div className="grid grid-cols-2 gap-3 mb-4">
          {userProfile.stats.map((stat, index) => (
            <Card key={index} className="shadow-lg border-0 bg-white/60 backdrop-blur-sm border border-white/20">
              <CardContent className="p-3">
                <div className="flex items-center space-x-2">
                  <div className={`${stat.color} text-white p-1.5 rounded-lg`}>
                    <stat.icon className="h-4 w-4" />
                  </div>
                  <div>
                    <div className="text-lg md:text-2xl font-bold text-gray-800">{stat.value}</div>
                    <div className="text-xs text-gray-600">{stat.label}</div>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Contact Information with Glassmorphism */}
        <Card className="mb-4 shadow-xl border-0 bg-white/60 backdrop-blur-sm border border-white/20">
          <CardHeader className="pb-3">
            <CardTitle className="flex items-center space-x-2 text-lg">
              <User className="h-5 w-5 text-indigo-500" />
              <span>Account Details</span>
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <div className="flex items-center space-x-3 p-3 bg-gradient-to-r from-gray-50/80 to-blue-50/80 rounded-lg backdrop-blur-sm border border-white/20">
              <Mail className="h-4 w-4 text-blue-500" />
              <span className="text-gray-700 text-sm md:text-base">{userProfile.email}</span>
            </div>
            <div className="flex items-center space-x-3 p-3 bg-gradient-to-r from-gray-50/80 to-blue-50/80 rounded-lg backdrop-blur-sm border border-white/20">
              <Phone className="h-4 w-4 text-green-500" />
              <span className="text-gray-700 text-sm md:text-base">{userProfile.phone}</span>
            </div>
          </CardContent>
        </Card>

        {/* Help Center Toggle */}
        <Card className="mb-4 shadow-xl border-0 bg-white/60 backdrop-blur-sm border border-white/20">
          <CardContent className="p-4">
            <Button 
              onClick={() => setShowHelpCenter(!showHelpCenter)} 
              variant="outline" 
              className="w-full transition-all duration-300 hover:bg-blue-50"
            >
              {showHelpCenter ? 'Hide Help Center' : 'Show Help Center'}
            </Button>
          </CardContent>
        </Card>

        {/* Help Center */}
        {showHelpCenter && (
          <div className="mb-4">
            <HelpCenter />
          </div>
        )}

        {/* Sign Out Button with Confirmation */}
        <Card className="mb-4 shadow-xl border-0 bg-white/60 backdrop-blur-sm border border-white/20">
          <CardContent className="p-4">
            <Button 
              onClick={() => setShowSignOutDialog(true)} 
              variant="outline" 
              className="w-full border-red-200 text-red-600 hover:bg-red-50 hover:border-red-300 transition-all duration-300 h-12 text-base font-semibold"
            >
              Sign Out
            </Button>
          </CardContent>
        </Card>

        {/* App Credit with Glassmorphism */}
        <div className="text-center mb-4">
          <div className="bg-white/60 backdrop-blur-sm rounded-lg p-3 border border-white/20 shadow-lg">
            <p className="text-gray-600 text-sm">
              Built with love by <span className="text-blue-600 font-bold">Japhet Jr</span>
            </p>
            <p className="text-gray-500 text-xs mt-1">
              East Africa's Premier Student Platform
            </p>
          </div>
        </div>
      </div>

      {/* Onboarding Flow - Updated to use only onComplete prop */}
      {showOnboarding && (
        <OnboardingFlow 
          onComplete={() => setShowOnboarding(false)} 
        />
      )}

      {/* Sign Out Confirmation Dialog */}
      <SignOutConfirmDialog 
        isOpen={showSignOutDialog}
        onClose={() => setShowSignOutDialog(false)}
        onConfirm={handleSignOut}
      />
    </div>
  );
};

export default Profile;
