
import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { BookOpen, Search, Plus, Star, MapPin, MessageSquare, ShoppingBag, User, Filter, Grid, List, Heart, Share2, ArrowRight, Sparkles, ArrowLeft } from "lucide-react";
import { Link } from "react-router-dom";
import { toast } from 'sonner';
import { supabase } from "@/integrations/supabase/client";

const Marketplace = () => {
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedCategory, setSelectedCategory] = useState("all");
  const [viewMode, setViewMode] = useState("grid");
  const [items, setItems] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchMarketplaceItems();
  }, []);

  const fetchMarketplaceItems = async () => {
    try {
      const { data, error } = await supabase
        .from('marketplace_items')
        .select(`
          *,
          profiles(full_name)
        `)
        .order('created_at', { ascending: false });

      if (error) {
        console.error('Error fetching marketplace items:', error);
        toast.error('Failed to load marketplace items');
        return;
      }

      setItems(data || []);
    } catch (error) {
      console.error('Error:', error);
      toast.error('Failed to load marketplace items');
    } finally {
      setLoading(false);
    }
  };

  const categories = ["all", "Electronics", "Books", "Clothing", "Furniture", "Sports", "Others"];

  const filteredItems = items.filter(item => {
    const matchesSearch = item.title?.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         item.category?.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         item.profiles?.full_name?.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         item.location?.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCategory = selectedCategory === "all" || item.category === selectedCategory;
    return matchesSearch && matchesCategory;
  });

  const handleContactSeller = (e: React.MouseEvent, item: any) => {
    e.preventDefault();
    e.stopPropagation();
    const message = encodeURIComponent("Hi! I'm interested in your " + item.title + ". Is this still available please?");
    const whatsappUrl = `https://wa.me/255712345678?text=${message}`;
    window.open(whatsappUrl, '_blank');
  };

  const handleAddToWishlist = (e: React.MouseEvent, itemId: number) => {
    e.preventDefault();
    e.stopPropagation();
    toast.success('Added to wishlist!');
  };

  const handleShare = (e: React.MouseEvent, item: any) => {
    e.preventDefault();
    e.stopPropagation();
    if (navigator.share) {
      navigator.share({
        title: item.title,
        text: `Check out this ${item.title} for ${item.price} TSh`,
        url: window.location.href
      });
    } else {
      toast.success('Link copied to clipboard!');
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 via-blue-50 to-green-50 relative overflow-hidden">
      {/* Animated background elements */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-10 left-10 w-20 h-20 bg-orange-200 rounded-full opacity-20 animate-pulse"></div>
        <div className="absolute top-32 right-20 w-16 h-16 bg-red-200 rounded-full opacity-30 animate-bounce" style={{animationDelay: '1s'}}></div>
        <div className="absolute bottom-20 left-1/4 w-12 h-12 bg-yellow-200 rounded-full opacity-25 animate-ping" style={{animationDelay: '2s'}}></div>
        <div className="absolute bottom-40 right-1/3 w-8 h-8 bg-purple-200 rounded-full opacity-20 animate-pulse" style={{animationDelay: '0.5s'}}></div>
        <Sparkles className="absolute top-1/4 left-1/3 w-6 h-6 text-orange-300 opacity-40 animate-spin" style={{animationDuration: '3s'}} />
        <Star className="absolute bottom-1/3 right-1/4 w-5 h-5 text-red-300 opacity-30 animate-pulse" />
      </div>

      {/* Header */}
      <header className="bg-white/60 backdrop-blur-xl shadow-sm border-b border-white/20 sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4">
          <div className="flex justify-between items-center h-14">
            <div className="flex items-center space-x-3">
              <Link to="/" className="flex items-center space-x-2 text-gray-600 hover:text-gray-900 transition-colors hover:scale-105 transform duration-300">
                <ArrowLeft className="h-4 w-4 sm:h-5 sm:w-5" />
                <span className="text-sm font-medium">Back to Home</span>
              </Link>
              <div className="flex items-center space-x-2">
                <div className="bg-gradient-to-r from-orange-500 to-red-500 text-white p-2 rounded-lg animate-pulse">
                  <ShoppingBag className="h-5 w-5" />
                </div>
                <span className="text-lg font-bold bg-gradient-to-r from-orange-500 to-red-500 bg-clip-text text-transparent">UDSM Market ✨</span>
              </div>
            </div>
            <Link to="/marketplace/sell">
              <Button size="sm" className="bg-gradient-to-r from-orange-500 to-red-500 hover:from-orange-600 hover:to-red-600 text-white shadow-lg hover:shadow-xl transition-all duration-300 hover:scale-105 transform">
                <Plus className="h-4 w-4 mr-1" />
                Sell
              </Button>
            </Link>
          </div>
        </div>
      </header>

      {/* Search Bar */}
      <div className="bg-white/60 backdrop-blur-xl border-b border-white/20">
        <div className="max-w-7xl mx-auto px-4 py-3">
          <div className="flex gap-2">
            <div className="flex-1 relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
              <Input
                placeholder="Search for anything..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10 h-10 bg-white/60 backdrop-blur-sm border-white/20 focus:ring-orange-500 focus:border-orange-500 focus:bg-white/80 transition-all duration-300"
              />
            </div>
            <Button variant="outline" size="sm" className="h-10 px-3 bg-white/60 backdrop-blur-sm border-white/20 hover:bg-white/80 hover:scale-105 transition-all duration-300">
              <Filter className="h-4 w-4" />
            </Button>
          </div>
        </div>
      </div>

      {/* Categories Bar */}
      <div className="bg-white/60 backdrop-blur-xl border-b border-white/20">
        <div className="max-w-7xl mx-auto px-4 py-2">
          <div className="flex gap-2 overflow-x-auto">
            {categories.map(category => (
              <button
                key={category}
                onClick={() => setSelectedCategory(category)}
                className={`px-3 py-1 rounded-full text-sm font-medium whitespace-nowrap transition-all duration-300 hover:scale-105 transform ${
                  selectedCategory === category
                    ? 'bg-gradient-to-r from-orange-500 to-red-500 text-white shadow-lg'
                    : 'bg-white/60 backdrop-blur-sm text-gray-700 hover:bg-white/80 border border-white/20'
                }`}
              >
                {category === "all" ? "All" : category}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 py-4 relative z-10">
        {/* Results Header */}
        <div className="flex justify-between items-center mb-4 animate-fade-in">
          <p className="text-sm text-gray-600">
            {filteredItems.length} results {searchTerm && `for "${searchTerm}"`}
          </p>
          <div className="flex items-center gap-2">
            <Button
              variant={viewMode === "grid" ? "default" : "outline"}
              size="sm"
              onClick={() => setViewMode("grid")}
              className="hover:scale-105 transition-transform duration-300"
            >
              <Grid className="h-4 w-4" />
            </Button>
            <Button
              variant={viewMode === "list" ? "default" : "outline"}
              size="sm"
              onClick={() => setViewMode("list")}
              className="hover:scale-105 transition-transform duration-300"
            >
              <List className="h-4 w-4" />
            </Button>
          </div>
        </div>

        {/* Items Grid */}
        {loading ? (
          <div className="text-center py-8">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-orange-500 mx-auto mb-3"></div>
            <p className="text-gray-600 text-sm">Loading marketplace items...</p>
          </div>
        ) : (
          <div className={`grid gap-2 sm:gap-3 mb-6 ${
            viewMode === "grid" 
              ? "grid-cols-2 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4" 
              : "grid-cols-1"
          }`}>
            {filteredItems.map((item, index) => (
            <Link key={item.id} to={`/marketplace/item/${item.id}`} className="animate-fade-in" style={{animationDelay: `${index * 0.1}s`}}>
              <Card className="hover:shadow-xl transition-all duration-300 overflow-hidden group border-0 shadow-lg bg-white/60 backdrop-blur-xl hover:bg-white/70 hover:scale-105 transform">
                <div className="relative">
                   <div className={`bg-gray-200 bg-cover bg-center relative overflow-hidden ${
                     viewMode === "grid" ? "h-28 sm:h-32 md:h-36" : "h-24 sm:h-28"
                   }`} style={{backgroundImage: item.image_url ? `url(${item.image_url})` : 'none'}}>
                     {!item.image_url && <div className="absolute inset-0 bg-gradient-to-br from-gray-100 to-gray-200 flex items-center justify-center">
                       <ShoppingBag className="h-8 w-8 sm:h-10 sm:w-10 text-gray-400" />
                     </div>}
                     <div className="absolute inset-0 bg-black bg-opacity-0 group-hover:bg-opacity-5 transition-all duration-200" />
                     
                     {/* Top badges */}
                     <div className="absolute top-2 left-2 flex flex-col gap-1">
                       {item.verified && (
                         <Badge className="bg-gradient-to-r from-green-500 to-emerald-500 text-white text-xs px-2 py-0.5 animate-pulse">
                           Verified
                         </Badge>
                       )}
                       {item.fast_delivery && (
                         <Badge className="bg-gradient-to-r from-orange-500 to-red-500 text-white text-xs px-2 py-0.5 animate-pulse">
                           Fast Delivery
                         </Badge>
                       )}
                     </div>

                     {/* Heart icon with glassmorphism */}
                     <button
                       onClick={(e) => handleAddToWishlist(e, item.id)}
                       className="absolute top-2 right-2 p-1.5 bg-white/80 backdrop-blur-sm rounded-full hover:bg-white transition-all duration-300 hover:scale-110 transform border border-white/20"
                     >
                       <Heart className="h-3 w-3 text-gray-600" />
                     </button>

                     {/* Discount badge */}
                     {item.original_price && (
                       <div className="absolute bottom-2 left-2">
                         <Badge className="bg-gradient-to-r from-red-500 to-pink-500 text-white text-xs px-2 py-0.5 animate-pulse">
                           -{Math.round((1 - Number(item.price) / Number(item.original_price)) * 100)}%
                         </Badge>
                       </div>
                     )}
                  </div>
                </div>

                <CardContent className="p-2 sm:p-3">
                  <div className="space-y-1.5">
                    {/* Title */}
                    <h3 className="font-medium text-gray-900 text-xs sm:text-sm leading-tight line-clamp-2 group-hover:text-orange-600 transition-colors">
                      {item.title}
                    </h3>

                     {/* Price */}
                     <div className="flex items-center gap-1.5">
                       <span className="text-sm sm:text-base font-bold bg-gradient-to-r from-orange-600 to-red-600 bg-clip-text text-transparent">
                         {Number(item.price).toLocaleString()} TSh
                       </span>
                       {item.original_price && (
                         <span className="text-xs text-gray-500 line-through">
                           {Number(item.original_price).toLocaleString()} TSh
                         </span>
                       )}
                     </div>

                     {/* Seller */}
                     <div className="text-xs text-gray-600 truncate">
                       Seller: {item.profiles?.full_name || 'Unknown Seller'}
                     </div>

                    {/* Location and Condition */}
                    <div className="flex items-center justify-between text-xs text-gray-600">
                      <div className="flex items-center gap-1">
                        <MapPin className="h-3 w-3 text-orange-500 animate-pulse" />
                        <span>{item.location}</span>
                      </div>
                      <span>{item.condition}</span>
                    </div>

                    {/* Action Buttons */}
                    <div className="flex gap-1.5 pt-1.5">
                      <Button 
                        size="sm"
                        className="flex-1 bg-gradient-to-r from-orange-500 to-red-500 hover:from-orange-600 hover:to-red-600 text-white h-7 text-xs shadow-lg hover:shadow-xl transition-all duration-300 hover:scale-105 transform"
                        onClick={(e) => handleContactSeller(e, item)}
                      >
                        Contact <ArrowRight className="h-3 w-3 ml-0.5" />
                      </Button>
                      <Button
                        variant="outline"
                        size="sm"
                        className="h-7 px-1.5 bg-white/60 backdrop-blur-sm border-white/20 hover:bg-white/80 hover:scale-105 transition-all duration-300"
                        onClick={(e) => handleShare(e, item)}
                      >
                        <Share2 className="h-3 w-3" />
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </Link>
          ))}
          </div>
        )}

        {!loading && filteredItems.length === 0 && (
          <div className="text-center py-12 animate-fade-in">
            <div className="text-gray-400 mb-4">
              <Search className="h-16 w-16 mx-auto animate-pulse" />
            </div>
            <h3 className="text-lg font-medium text-gray-900 mb-2">No items found</h3>
            <p className="text-gray-600 mb-4">Try adjusting your search or filter criteria</p>
            <Button onClick={() => { setSearchTerm(""); setSelectedCategory("all"); }} className="hover:scale-105 transition-transform duration-300">
              Clear filters
            </Button>
          </div>
        )}

        {/* Quick Stats with glassmorphism */}
        <div className="grid grid-cols-2 gap-3 mb-20 animate-fade-in" style={{animationDelay: '0.6s'}}>
          <Card className="text-center p-4 bg-gradient-to-br from-orange-50/60 to-red-50/60 backdrop-blur-sm border border-white/20 shadow-lg hover:shadow-xl transition-all duration-300 hover:scale-105">
            <div className="text-2xl font-bold bg-gradient-to-r from-orange-600 to-red-600 bg-clip-text text-transparent mb-1 animate-pulse">300+</div>
            <div className="text-xs text-orange-800">Active Listings</div>
          </Card>
          <Card className="text-center p-4 bg-gradient-to-br from-blue-50/60 to-indigo-50/60 backdrop-blur-sm border border-white/20 shadow-lg hover:shadow-xl transition-all duration-300 hover:scale-105">
            <div className="text-2xl font-bold bg-gradient-to-r from-blue-600 to-indigo-600 bg-clip-text text-transparent mb-1 animate-pulse">1200+</div>
            <div className="text-xs text-blue-800">Happy Students</div>
          </Card>
        </div>

        {/* Enhanced Footer with glassmorphism */}
        <div className="text-center mb-20">
          <div className="bg-white/60 backdrop-blur-sm rounded-lg p-3 border border-white/20 shadow-lg hover:bg-white/70 transition-all duration-300 animate-scale-in hover:scale-105" style={{animationDelay: '0.8s'}}>
            <div className="flex items-center justify-center space-x-2 mb-2">
              <Sparkles className="h-4 w-4 text-orange-500 animate-pulse" />
              <span className="text-gray-600 text-xs">
                Marketplace powered by <span className="bg-gradient-to-r from-orange-500 to-red-500 bg-clip-text text-transparent font-semibold">Japhet Jr</span> ✨
              </span>
            </div>
            <p className="text-gray-500 text-xs">
              Buy, sell, and discover amazing deals 🛒
            </p>
          </div>
        </div>
      </main>
    </div>
  );
};

export default Marketplace;
