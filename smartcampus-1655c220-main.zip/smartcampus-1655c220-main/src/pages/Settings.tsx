
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { ArrowLeft, Settings as SettingsIcon, Bell, Shield, User, Palette, Key, Smartphone } from "lucide-react";
import { Link } from "react-router-dom";
import { toast } from "sonner";
import { useAuth } from "@/contexts/AuthContext";

const Settings = () => {
  const { user } = useAuth();
  const [settings, setSettings] = useState({
    pushNotifications: true,
    emailNotifications: false,
    forumNotifications: true,
    tipNotifications: true,
    publicProfile: true,
    activityStatus: false,
    dataSharing: false,
    darkMode: false,
    compactView: false,
    hapticFeedback: true
  });

  const [passwordReset, setPasswordReset] = useState({
    email: user?.email || '',
    isLoading: false
  });

  const [twoFactor, setTwoFactor] = useState({
    enabled: false,
    isSetup: false
  });

  const handleToggle = (setting: string) => {
    setSettings(prev => ({ ...prev, [setting]: !prev[setting as keyof typeof prev] }));
    
    // Haptic feedback simulation
    if (settings.hapticFeedback && 'vibrate' in navigator) {
      navigator.vibrate(50);
    }
    
    toast.success(`${setting.replace(/([A-Z])/g, ' $1').toLowerCase()} has been ${!settings[setting as keyof typeof settings] ? 'enabled' : 'disabled'}.`);
  };

  const handlePasswordReset = async () => {
    setPasswordReset(prev => ({ ...prev, isLoading: true }));
    
    try {
      // Simulate password reset email
      setTimeout(() => {
        toast.success("Password reset email sent! Check your inbox.");
        setPasswordReset(prev => ({ ...prev, isLoading: false }));
      }, 2000);
    } catch (error) {
      toast.error("Failed to send password reset email.");
      setPasswordReset(prev => ({ ...prev, isLoading: false }));
    }
  };

  const handleSetup2FA = () => {
    if (!twoFactor.enabled) {
      setTwoFactor({ enabled: true, isSetup: true });
      toast.success("Two-factor authentication enabled!");
    } else {
      setTwoFactor({ enabled: false, isSetup: false });
      toast.success("Two-factor authentication disabled!");
    }
  };

  const handleDownloadData = () => {
    // Create a mock data file
    const userData = {
      email: user?.email || "user@example.com",
      profile: "User profile data",
      activity: "User activity data",
      settings: settings,
      exportDate: new Date().toISOString()
    };
    
    const dataStr = JSON.stringify(userData, null, 2);
    const dataBlob = new Blob([dataStr], { type: 'application/json' });
    const url = URL.createObjectURL(dataBlob);
    
    const link = document.createElement('a');
    link.href = url;
    link.download = `udsm-hub-data-${new Date().toISOString().split('T')[0]}.json`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
    
    toast.success("Your data has been downloaded successfully.");
  };

  const handleDeleteAccount = () => {
    toast.error("Account deletion requires additional confirmation. Please contact support at support@udsmhub.tz", {
      duration: 5000
    });
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-indigo-100 pb-20">
      {/* Header */}
      <div className="bg-gradient-to-r from-blue-600 via-purple-600 to-indigo-600 text-white">
        <div className="max-w-4xl mx-auto px-4 py-6">
          <div className="flex items-center space-x-4">
            <Link to="/profile">
              <Button variant="ghost" size="sm" className="text-white hover:bg-white/20 transition-all duration-300">
                <ArrowLeft className="h-4 w-4" />
              </Button>
            </Link>
            <h1 className="text-2xl font-bold">Settings</h1>
          </div>
        </div>
      </div>

      {/* Content */}
      <div className="max-w-2xl mx-auto px-4 -mt-8 space-y-4">
        {/* Notifications */}
        <Card className="shadow-xl border-0 bg-white/80 backdrop-blur-sm border border-white/20">
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <Bell className="h-5 w-5" />
              <span>Notifications</span>
            </CardTitle>
            <CardDescription>Manage your notification preferences</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center justify-between">
              <Label htmlFor="push-notifications">Push Notifications</Label>
              <Switch 
                id="push-notifications" 
                checked={settings.pushNotifications}
                onCheckedChange={() => handleToggle('pushNotifications')}
              />
            </div>
            <div className="flex items-center justify-between">
              <Label htmlFor="email-notifications">Email Notifications</Label>
              <Switch 
                id="email-notifications" 
                checked={settings.emailNotifications}
                onCheckedChange={() => handleToggle('emailNotifications')}
              />
            </div>
            <div className="flex items-center justify-between">
              <Label htmlFor="forum-notifications">Forum Updates</Label>
              <Switch 
                id="forum-notifications" 
                checked={settings.forumNotifications}
                onCheckedChange={() => handleToggle('forumNotifications')}
              />
            </div>
            <div className="flex items-center justify-between">
              <Label htmlFor="tip-notifications">Daily Tips</Label>
              <Switch 
                id="tip-notifications" 
                checked={settings.tipNotifications}
                onCheckedChange={() => handleToggle('tipNotifications')}
              />
            </div>
          </CardContent>
        </Card>

        {/* Security & Authentication */}
        <Card className="shadow-xl border-0 bg-white/80 backdrop-blur-sm border border-white/20">
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <Shield className="h-5 w-5" />
              <span>Security</span>
            </CardTitle>
            <CardDescription>Manage your account security settings</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            {/* Password Reset */}
            <div className="space-y-2">
              <Label>Password Reset</Label>
              <div className="flex space-x-2">
                <Input 
                  value={passwordReset.email}
                  onChange={(e) => setPasswordReset(prev => ({ ...prev, email: e.target.value }))}
                  placeholder="Enter your email"
                  className="flex-1"
                />
                <Button 
                  onClick={handlePasswordReset}
                  disabled={passwordReset.isLoading}
                  className="transition-all duration-300"
                >
                  <Key className="h-4 w-4 mr-2" />
                  {passwordReset.isLoading ? 'Sending...' : 'Reset'}
                </Button>
              </div>
            </div>

            {/* Two-Factor Authentication */}
            <div className="flex items-center justify-between">
              <div>
                <Label>Two-Factor Authentication</Label>
                <p className="text-sm text-gray-600">Add an extra layer of security</p>
              </div>
              <Button 
                variant={twoFactor.enabled ? "outline" : "default"}
                onClick={handleSetup2FA}
                className="transition-all duration-300"
              >
                <Smartphone className="h-4 w-4 mr-2" />
                {twoFactor.enabled ? 'Disable' : 'Enable'}
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Privacy */}
        <Card className="shadow-xl border-0 bg-white/80 backdrop-blur-sm border border-white/20">
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <Shield className="h-5 w-5" />
              <span>Privacy</span>
            </CardTitle>
            <CardDescription>Control your privacy settings</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center justify-between">
              <Label htmlFor="profile-visibility">Public Profile</Label>
              <Switch 
                id="profile-visibility" 
                checked={settings.publicProfile}
                onCheckedChange={() => handleToggle('publicProfile')}
              />
            </div>
            <div className="flex items-center justify-between">
              <Label htmlFor="activity-status">Show Activity Status</Label>
              <Switch 
                id="activity-status" 
                checked={settings.activityStatus}
                onCheckedChange={() => handleToggle('activityStatus')}
              />
            </div>
            <div className="flex items-center justify-between">
              <Label htmlFor="data-sharing">Allow Data Sharing</Label>
              <Switch 
                id="data-sharing" 
                checked={settings.dataSharing}
                onCheckedChange={() => handleToggle('dataSharing')}
              />
            </div>
          </CardContent>
        </Card>

        {/* Account Management */}
        <Card className="shadow-xl border-0 bg-white/80 backdrop-blur-sm border border-white/20">
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <User className="h-5 w-5" />
              <span>Account</span>
            </CardTitle>
            <CardDescription>Manage your account data</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <Button variant="outline" className="w-full justify-start transition-all duration-300" onClick={handleDownloadData}>
              Download My Data
            </Button>
            <Button variant="destructive" className="w-full justify-start transition-all duration-300" onClick={handleDeleteAccount}>
              Delete Account
            </Button>
          </CardContent>
        </Card>

        {/* Appearance & Experience */}
        <Card className="shadow-xl border-0 bg-white/80 backdrop-blur-sm border border-white/20">
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <Palette className="h-5 w-5" />
              <span>Appearance & Experience</span>
            </CardTitle>
            <CardDescription>Customize your app experience</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center justify-between">
              <Label htmlFor="dark-mode">Dark Mode</Label>
              <Switch 
                id="dark-mode" 
                checked={settings.darkMode}
                onCheckedChange={() => handleToggle('darkMode')}
              />
            </div>
            <div className="flex items-center justify-between">
              <Label htmlFor="compact-view">Compact View</Label>
              <Switch 
                id="compact-view" 
                checked={settings.compactView}
                onCheckedChange={() => handleToggle('compactView')}
              />
            </div>
            <div className="flex items-center justify-between">
              <Label htmlFor="haptic-feedback">Haptic Feedback</Label>
              <Switch 
                id="haptic-feedback" 
                checked={settings.hapticFeedback}
                onCheckedChange={() => handleToggle('hapticFeedback')}
              />
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default Settings;
