
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { ArrowLeft, Star, MapPin, Phone, Wifi, Car, Shield, Utensils, Heart, Share2, MessageCircle } from "lucide-react";
import { Link, useParams } from "react-router-dom";

const HostelDetail = () => {
  const { id } = useParams();
  const [showChat, setShowChat] = useState(false);
  const [isFavorited, setIsFavorited] = useState(false);

  // Mock hostel data
  const hostel = {
    id: 1,
    name: "University Heights Hostel",
    location: "Kinondoni",
    distance: "0.5 km from campus",
    price: "120,000",
    rating: 4.5,
    reviews: 45,
    contact: "+255712345678",
    images: [
      "https://images.unsplash.com/photo-1555854877-bab0e564b8d5?w=800&h=600&fit=crop",
      "https://images.unsplash.com/photo-1566073771259-6a8506099945?w=800&h=600&fit=crop",
      "https://images.unsplash.com/photo-1582268611958-ebfd161ef9cf?w=800&h=600&fit=crop"
    ],
    description: "Modern hostel facility located just minutes from UDSM campus. Features spacious rooms, reliable internet, 24/7 security, and a friendly community atmosphere. Perfect for serious students who value comfort and convenience.",
    amenities: [
      { name: "WiFi", icon: Wifi, description: "High-speed internet throughout the facility" },
      { name: "Security", icon: Shield, description: "24/7 security guards and CCTV" },
      { name: "Water", icon: "💧", description: "Clean running water available 24/7" },
      { name: "Parking", icon: Car, description: "Secure parking for motorcycles and bicycles" },
      { name: "Kitchen", icon: Utensils, description: "Shared kitchen facilities" }
    ],
    roomTypes: [
      { type: "Single Room", price: "120,000", description: "Private room with shared bathroom" },
      { type: "Double Room", price: "85,000", description: "Shared room with bunk beds" },
      { type: "Studio", price: "150,000", description: "Private room with ensuite bathroom" }
    ],
    rules: [
      "No visitors after 10 PM",
      "Keep common areas clean",
      "No loud music or noise",
      "Respect other residents",
      "No smoking indoors"
    ],
    nearbyPlaces: [
      { name: "UDSM Main Campus", distance: "0.5 km", type: "University" },
      { name: "City Mall", distance: "2.1 km", type: "Shopping" },
      { name: "Muhimbili Hospital", distance: "3.2 km", type: "Healthcare" },
      { name: "Ubungo Bus Station", distance: "5.8 km", type: "Transport" }
    ]
  };

  const handleWhatsAppClick = () => {
    const message = encodeURIComponent("Hi! I'm interested in accommodation at your hostel. Is there availability?");
    const whatsappUrl = `https://wa.me/${hostel.contact.replace('+', '')}?text=${message}`;
    window.open(whatsappUrl, '_blank');
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <Link to="/hostels" className="flex items-center space-x-2 text-green-600 hover:text-green-700">
              <ArrowLeft className="h-5 w-5" />
              <span>Back to Hostels</span>
            </Link>
            <div className="flex items-center space-x-2">
              <Button
                variant="outline"
                size="sm"
                onClick={() => setIsFavorited(!isFavorited)}
                className={isFavorited ? "text-red-600 border-red-200" : ""}
              >
                <Heart className={`h-4 w-4 mr-1 ${isFavorited ? 'fill-red-600' : ''}`} />
                {isFavorited ? 'Saved' : 'Save'}
              </Button>
              <Button variant="outline" size="sm">
                <Share2 className="h-4 w-4 mr-1" />
                Share
              </Button>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Main Content */}
          <div className="lg:col-span-2 space-y-6">
            {/* Images */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="md:col-span-2 aspect-video bg-gray-200 rounded-lg overflow-hidden">
                <img 
                  src={hostel.images[0]} 
                  alt={hostel.name}
                  className="w-full h-full object-cover"
                />
              </div>
              {hostel.images.slice(1, 3).map((image, index) => (
                <div key={index} className="aspect-video bg-gray-200 rounded-lg overflow-hidden">
                  <img 
                    src={image} 
                    alt={`${hostel.name} ${index + 2}`}
                    className="w-full h-full object-cover"
                  />
                </div>
              ))}
            </div>

            {/* Hostel Info */}
            <Card>
              <CardContent className="p-6">
                <div className="flex items-start justify-between mb-4">
                  <div>
                    <h1 className="text-2xl font-bold text-gray-900 mb-2">{hostel.name}</h1>
                    <div className="flex items-center space-x-2 text-gray-600 mb-2">
                      <MapPin className="h-4 w-4" />
                      <span>{hostel.location} • {hostel.distance}</span>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Star className="h-4 w-4 fill-yellow-400 text-yellow-400" />
                      <span className="font-medium">{hostel.rating}</span>
                      <span className="text-gray-600">({hostel.reviews} reviews)</span>
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="text-2xl font-bold text-green-600">{hostel.price} TSh</div>
                    <div className="text-sm text-gray-600">per month</div>
                  </div>
                </div>

                <p className="text-gray-700 mb-6">{hostel.description}</p>

                {/* Amenities */}
                <div className="mb-6">
                  <h3 className="font-semibold text-gray-900 mb-3">Amenities</h3>
                  <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
                    {hostel.amenities.map((amenity, index) => (
                      <div key={index} className="flex items-center space-x-2 p-2 bg-gray-50 rounded-lg">
                        {typeof amenity.icon === 'string' ? (
                          <span className="text-lg">{amenity.icon}</span>
                        ) : (
                          <amenity.icon className="h-5 w-5 text-green-600" />
                        )}
                        <span className="text-sm font-medium">{amenity.name}</span>
                      </div>
                    ))}
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Room Types */}
            <Card>
              <CardHeader>
                <CardTitle>Room Types & Pricing</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {hostel.roomTypes.map((room, index) => (
                    <div key={index} className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                      <div>
                        <h4 className="font-medium text-gray-900">{room.type}</h4>
                        <p className="text-sm text-gray-600">{room.description}</p>
                      </div>
                      <div className="text-right">
                        <div className="font-bold text-green-600">{room.price} TSh</div>
                        <div className="text-sm text-gray-600">per month</div>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Rules */}
            <Card>
              <CardHeader>
                <CardTitle>Hostel Rules</CardTitle>
              </CardHeader>
              <CardContent>
                <ul className="space-y-2">
                  {hostel.rules.map((rule, index) => (
                    <li key={index} className="flex items-start space-x-2">
                      <span className="text-green-600 mt-1">•</span>
                      <span className="text-gray-700">{rule}</span>
                    </li>
                  ))}
                </ul>
              </CardContent>
            </Card>
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Contact Card */}
            <Card>
              <CardHeader>
                <CardTitle>Contact Hostel</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <Button 
                  className="w-full bg-green-600 hover:bg-green-700"
                  onClick={handleWhatsAppClick}
                >
                  <Phone className="h-4 w-4 mr-2" />
                  WhatsApp: {hostel.contact}
                </Button>
                <Button 
                  variant="outline" 
                  className="w-full"
                  onClick={() => setShowChat(!showChat)}
                >
                  <MessageCircle className="h-4 w-4 mr-2" />
                  Send Message
                </Button>
                <Button variant="outline" className="w-full">
                  Schedule Visit
                </Button>
              </CardContent>
            </Card>

            {/* Nearby Places */}
            <Card>
              <CardHeader>
                <CardTitle>Nearby Places</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {hostel.nearbyPlaces.map((place, index) => (
                    <div key={index} className="flex items-center justify-between">
                      <div>
                        <p className="font-medium text-sm">{place.name}</p>
                        <p className="text-xs text-gray-600">{place.type}</p>
                      </div>
                      <Badge variant="outline" className="text-xs">
                        {place.distance}
                      </Badge>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Quick Stats */}
            <Card>
              <CardHeader>
                <CardTitle>Quick Info</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-2 text-sm">
                  <div className="flex justify-between">
                    <span className="text-gray-600">Monthly Rent:</span>
                    <span className="font-medium">{hostel.price} TSh</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">Distance to Campus:</span>
                    <span className="font-medium">{hostel.distance}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">Rating:</span>
                    <span className="font-medium">{hostel.rating}/5</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">Reviews:</span>
                    <span className="font-medium">{hostel.reviews}</span>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>

        {/* Chat Section */}
        {showChat && (
          <Card className="mt-8 bg-green-50 border-green-200">
            <CardContent className="p-6">
              <h3 className="font-semibold text-green-900 mb-4">Send a Message</h3>
              <div className="space-y-4">
                <textarea
                  placeholder="Hi, I'm interested in accommodation at your hostel. Could you please provide more information about availability and pricing?"
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-green-500 min-h-[100px]"
                />
                <Button className="bg-green-600 hover:bg-green-700">
                  Send Message
                </Button>
              </div>
            </CardContent>
          </Card>
        )}
      </main>
    </div>
  );
};

export default HostelDetail;
