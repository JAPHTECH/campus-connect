
import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { ArrowLeft, Camera } from "lucide-react";
import { Link, useNavigate } from "react-router-dom";
import { useAuth } from "@/contexts/AuthContext";
import { toast } from "sonner";
import { ProfileImageCrop } from "@/components/ProfileImageCrop";

const EditProfile = () => {
  const { user, profile, updateProfile } = useAuth();
  const navigate = useNavigate();
  const [profileImage, setProfileImage] = useState("/placeholder.svg");
  const [isLoading, setIsLoading] = useState(false);
  const [isCropOpen, setIsCropOpen] = useState(false);
  const [selectedImage, setSelectedImage] = useState<string>("");
  const [formData, setFormData] = useState({
    full_name: "",
    phone: "",
    location: "",
    course: "",
    year: ""
  });

  // Load existing profile data
  useEffect(() => {
    if (profile) {
      setFormData({
        full_name: profile.full_name || "",
        phone: profile.phone || "",
        location: profile.location || "",
        course: profile.course || "",
        year: profile.year || ""
      });
      if (profile.avatar_url) {
        setProfileImage(profile.avatar_url);
      }
    }
  }, [profile]);

  const handleInputChange = (field: string, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const handlePhotoSelect = () => {
    const input = document.createElement('input');
    input.type = 'file';
    input.accept = 'image/*';
    input.onchange = (e) => {
      const file = (e.target as HTMLInputElement).files?.[0];
      if (file) {
        const reader = new FileReader();
        reader.onload = (e) => {
          const imageUrl = e.target?.result as string;
          setSelectedImage(imageUrl);
          setIsCropOpen(true);
        };
        reader.readAsDataURL(file);
      }
    };
    input.click();
  };

  const handleCroppedImage = (croppedImage: string) => {
    setProfileImage(croppedImage);
    setIsCropOpen(false);
    toast.success("Profile picture updated! Click 'Save Changes' to save.");
  };

  const handleSave = async () => {
    setIsLoading(true);
    try {
      console.log('Saving profile with data:', formData);
      
      const updates = {
        ...formData,
        avatar_url: profileImage !== "/placeholder.svg" ? profileImage : null,
        updated_at: new Date().toISOString()
      };

      console.log('Sending updates:', updates);

      const result = await updateProfile(updates);

      if (result && result.error) {
        console.error('Profile update error:', result.error);
        toast.error("Failed to save changes. Please try again!");
      } else {
        console.log('Profile updated successfully');
        toast.success("Profile saved successfully!");
        // Navigate back to profile after a short delay
        setTimeout(() => {
          navigate('/profile');
        }, 1000);
      }
    } catch (error) {
      console.error('Unexpected error:', error);
      toast.error("Network error. Please check your connection!");
    } finally {
      setIsLoading(false);
    }
  };

  const getDisplayName = () => {
    if (formData.full_name) return formData.full_name;
    if (user?.user_metadata?.full_name) return user.user_metadata.full_name;
    if (user?.email) {
      const emailName = user.email.split('@')[0];
      return emailName.charAt(0).toUpperCase() + emailName.slice(1);
    }
    return 'User';
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-indigo-100 pb-20">
      {/* Header */}
      <div className="bg-gradient-to-r from-blue-600 via-purple-600 to-indigo-600 text-white">
        <div className="max-w-4xl mx-auto px-4 py-6">
          <div className="flex items-center space-x-4">
            <Link to="/profile">
              <Button variant="ghost" size="sm" className="text-white hover:bg-white/20 transition-all duration-300 hover:scale-105">
                <ArrowLeft className="h-4 w-4" />
              </Button>
            </Link>
            <div>
              <h1 className="text-2xl md:text-3xl font-bold">Edit Profile</h1>
              <p className="text-blue-200">Update your information</p>
            </div>
          </div>
        </div>
      </div>

      {/* Content */}
      <div className="max-w-2xl mx-auto px-4 -mt-8">
        <Card className="shadow-xl border-0 bg-white/80 backdrop-blur-sm hover:shadow-2xl transition-all duration-300 border border-white/20">
          <CardHeader>
            <CardTitle className="text-2xl">Profile Information</CardTitle>
            <CardDescription>Update your details and preferences</CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            {/* Profile Picture */}
            <div className="flex items-center space-x-6">
              <Avatar className="w-24 h-24 shadow-xl border-4 border-blue-100 hover:scale-105 transition-transform duration-300">
                <AvatarImage src={profileImage} />
                <AvatarFallback className="bg-gradient-to-r from-blue-500 to-purple-500 text-white text-2xl">
                  {getDisplayName().charAt(0).toUpperCase()}
                </AvatarFallback>
              </Avatar>
              <Button 
                variant="outline" 
                size="sm" 
                onClick={handlePhotoSelect}
                className="hover:bg-blue-50 transition-all duration-300 hover:scale-105"
              >
                <Camera className="h-4 w-4 mr-2" />
                Change Photo
              </Button>
            </div>

            {/* Form Fields */}
            <div className="grid grid-cols-1 gap-4">
              <div>
                <Label htmlFor="full_name" className="text-gray-700 font-medium">Full Name</Label>
                <Input 
                  id="full_name" 
                  placeholder="Enter your full name" 
                  value={formData.full_name}
                  onChange={(e) => handleInputChange('full_name', e.target.value)}
                  className="mt-2 h-12 border-gray-200 focus:border-blue-400 transition-all duration-300 hover:border-blue-300"
                />
              </div>
              <div>
                <Label htmlFor="phone" className="text-gray-700 font-medium">Phone Number</Label>
                <Input 
                  id="phone" 
                  placeholder="Enter your phone number" 
                  value={formData.phone}
                  onChange={(e) => handleInputChange('phone', e.target.value)}
                  className="mt-2 h-12 border-gray-200 focus:border-blue-400 transition-all duration-300 hover:border-blue-300"
                />
              </div>
              <div>
                <Label htmlFor="location" className="text-gray-700 font-medium">Location</Label>
                <Input 
                  id="location" 
                  placeholder="Where do you live? (e.g., Mlimani City)" 
                  value={formData.location}
                  onChange={(e) => handleInputChange('location', e.target.value)}
                  className="mt-2 h-12 border-gray-200 focus:border-blue-400 transition-all duration-300 hover:border-blue-300"
                />
              </div>
              <div>
                <Label htmlFor="course" className="text-gray-700 font-medium">Course/Program</Label>
                <Input 
                  id="course" 
                  placeholder="What do you study? (e.g., Computer Science)" 
                  value={formData.course}
                  onChange={(e) => handleInputChange('course', e.target.value)}
                  className="mt-2 h-12 border-gray-200 focus:border-blue-400 transition-all duration-300 hover:border-blue-300"
                />
              </div>
              <div>
                <Label htmlFor="year" className="text-gray-700 font-medium">Year of Study</Label>
                <Input 
                  id="year" 
                  placeholder="Which year are you in? (e.g., Year 2)" 
                  value={formData.year}
                  onChange={(e) => handleInputChange('year', e.target.value)}
                  className="mt-2 h-12 border-gray-200 focus:border-blue-400 transition-all duration-300 hover:border-blue-300"
                />
              </div>
            </div>

            {/* Action Buttons */}
            <div className="flex space-x-4">
              <Button 
                className="flex-1 h-12 bg-gradient-to-r from-blue-500 to-purple-500 hover:from-blue-600 hover:to-purple-600 transition-all duration-300 hover:scale-105" 
                onClick={handleSave}
                disabled={isLoading}
              >
                {isLoading ? 'Saving...' : 'Save Changes'}
              </Button>
              <Link to="/profile" className="flex-1">
                <Button variant="outline" className="w-full h-12 hover:bg-gray-50 transition-all duration-300 hover:scale-105">
                  Cancel
                </Button>
              </Link>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Crop Modal */}
      <ProfileImageCrop
        isOpen={isCropOpen}
        onClose={() => setIsCropOpen(false)}
        onSave={handleCroppedImage}
        imageUrl={selectedImage}
      />
    </div>
  );
};

export default EditProfile;
