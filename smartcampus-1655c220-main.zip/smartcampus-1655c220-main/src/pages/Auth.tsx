import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import * as z from 'zod';
import { useAuth } from '@/contexts/AuthContext';
import { useNavigate } from 'react-router-dom';
import { BookOpen, Eye, EyeOff, Sparkles, Star, Heart, TrendingUp, Zap } from 'lucide-react';
import { toast } from 'sonner';
const authSchema = z.object({
  email: z.string().email('Please enter a valid email address'),
  password: z.string().min(6, 'Password must be at least 6 characters')
});
const Auth = () => {
  const [isSignUp, setIsSignUp] = useState(false);
  const [showPassword, setShowPassword] = useState(false);
  const [currentMessageIndex, setCurrentMessageIndex] = useState(0);
  const [isLoading, setIsLoading] = useState(false);
  const [currentTipIndex, setCurrentTipIndex] = useState(0);
  const {
    signUp,
    signIn,
    signInWithGoogle,
    user,
    loading
  } = useAuth();
  const navigate = useNavigate();
  const welcomeMessages = [{
    text: 'Welcome to our family!',
    subtitle: 'This is your student home'
  }, {
    text: 'Join the UDSM Squad!',
    subtitle: 'Where legends are made'
  }, {
    text: 'We are together here!',
    subtitle: 'Community of success'
  }, {
    text: 'Welcome to the Vibe!',
    subtitle: 'Your digital campus companion'
  }, {
    text: 'This is home!',
    subtitle: 'Everything you need is here'
  }, {
    text: 'Karibu nyumbani!',
    subtitle: 'Tutafanya kazi pamoja!'
  }, {
    text: 'Join the family!',
    subtitle: 'Academic excellence awaits'
  }];
  const authTips = ["Join 1,200+ UDSM students already on the platform! 🎓", "Access 500+ study materials instantly after signup! 📚", "Find the best hostels near campus easily! 🏠", "Connect with your coursemates and study together! 🤝", "Share memes and have fun in our community! 😂", "Built by students, for students - we get it! ✨", "Your academic success journey starts here! 🚀", "Free forever - no hidden costs, just pure value! 💎"];
  useEffect(() => {
    if (user && !loading) {
      console.log('User authenticated, redirecting to home');
      navigate('/');
    }
  }, [user, loading, navigate]);
  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentMessageIndex(prev => (prev + 1) % welcomeMessages.length);
    }, 3000);
    return () => clearInterval(interval);
  }, []);

  // Animate tips
  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentTipIndex(prev => (prev + 1) % authTips.length);
    }, 4000);
    return () => clearInterval(interval);
  }, []);
  const form = useForm<z.infer<typeof authSchema>>({
    resolver: zodResolver(authSchema),
    defaultValues: {
      email: '',
      password: ''
    }
  });
  const onSubmit = async (values: z.infer<typeof authSchema>) => {
    setIsLoading(true);
    try {
      console.log(`Starting ${isSignUp ? 'signup' : 'signin'} process with email:`, values.email);
      let result;
      if (isSignUp) {
        result = await signUp(values.email, values.password);
      } else {
        result = await signIn(values.email, values.password);
      }
      if (result.error) {
        console.error('Auth error:', result.error);
        const errorMessage = result.error.message || result.error;

        // Handle specific error messages
        if (errorMessage.includes('User already registered') || errorMessage.includes('already exists')) {
          toast.error('This email is already in use! Try signing in instead.');
        } else if (errorMessage.includes('Invalid login credentials')) {
          toast.error('Email or password is incorrect! Please check your details.');
        } else if (errorMessage.includes('Invalid email')) {
          toast.error('This email doesn\'t work. Please check it!');
        } else if (errorMessage.includes('Password')) {
          toast.error('Password issue. Make it 6+ characters!');
        } else if (errorMessage.includes('too many requests') || errorMessage.includes('Too many requests')) {
          toast.error('Too many attempts. Please wait and try again!');
        } else if (errorMessage.includes('email confirmation') || errorMessage.includes('confirmation link')) {
          toast.success('Account created! Check your email for confirmation link.');
        } else if (errorMessage.includes('Email not confirmed')) {
          toast.error('Please confirm your email first!');
        } else {
          toast.error('Something went wrong. Please try again!');
        }
      } else {
        // Success
        if (isSignUp) {
          toast.success('Account created successfully! Welcome to the family!');
        } else {
          toast.success('Welcome back to UDSM Hub!');
        }
      }
    } catch (error) {
      console.error('Unexpected auth error:', error);
      toast.error('Something went wrong. Please refresh and try again!');
    } finally {
      setIsLoading(false);
    }
  };

  const handleGoogleSignIn = async () => {
    setIsLoading(true);
    try {
      console.log('Starting Google sign in');
      const result = await signInWithGoogle();
      
      if (result.error) {
        console.error('Google sign in error:', result.error);
        toast.error('Google sign in failed. Please try again!');
      }
      // Success will be handled by the auth state change
    } catch (error) {
      console.error('Unexpected Google sign in error:', error);
      toast.error('Something went wrong with Google sign in!');
    } finally {
      setIsLoading(false);
    }
  };
  if (loading) {
    return <div className="min-h-screen bg-gradient-to-br from-blue-900 via-purple-900 to-indigo-900 flex items-center justify-center relative overflow-hidden">
        {/* Enhanced animated background for loading */}
        <div className="absolute inset-0 overflow-hidden pointer-events-none">
          <div className="absolute top-10 left-10 w-20 h-20 bg-blue-200 rounded-full opacity-20 animate-pulse"></div>
          <div className="absolute top-32 right-20 w-16 h-16 bg-purple-200 rounded-full opacity-30 animate-bounce" style={{
          animationDelay: '1s'
        }}></div>
          <div className="absolute bottom-20 left-1/4 w-12 h-12 bg-green-200 rounded-full opacity-25 animate-ping" style={{
          animationDelay: '2s'
        }}></div>
          <Sparkles className="absolute top-1/4 left-1/3 w-6 h-6 text-purple-300 opacity-40 animate-spin" style={{
          animationDuration: '3s'
        }} />
          <Star className="absolute bottom-1/3 right-1/4 w-5 h-5 text-blue-300 opacity-30 animate-pulse" />
        </div>
        
        <div className="text-white text-center animate-scale-in">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-white mx-auto mb-4"></div>
          <p className="animate-fade-in">Loading your digital campus...</p>
        </div>
      </div>;
  }
  return <div className="min-h-screen bg-gradient-to-br from-blue-900 via-purple-900 to-indigo-900 relative overflow-hidden px-4 py-6">
      {/* Enhanced animated background elements - matching home page */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-10 left-10 w-20 h-20 md:w-32 md:h-32 bg-blue-500/20 rounded-full blur-3xl animate-pulse"></div>
        <div className="absolute top-32 right-10 w-32 h-32 md:w-48 md:h-48 bg-purple-500/20 rounded-full blur-3xl animate-pulse delay-1000"></div>
        <div className="absolute bottom-10 left-1/2 w-24 h-24 md:w-40 md:h-40 bg-indigo-500/20 rounded-full blur-3xl animate-pulse delay-2000"></div>
        <div className="absolute top-1/2 left-20 w-16 h-16 md:w-24 md:h-24 bg-pink-500/20 rounded-full blur-2xl animate-pulse delay-500"></div>
        <div className="absolute bottom-20 right-20 w-24 h-24 md:w-36 md:h-36 bg-cyan-500/20 rounded-full blur-3xl animate-pulse delay-1500"></div>
        
        {/* Additional floating elements matching home page */}
        <Sparkles className="absolute top-1/4 left-1/3 w-6 h-6 text-purple-300 opacity-40 animate-spin" style={{
        animationDuration: '3s'
      }} />
        <Star className="absolute bottom-1/3 right-1/4 w-5 h-5 text-blue-300 opacity-30 animate-pulse" />
        <Heart className="absolute top-2/3 left-1/5 w-4 h-4 text-pink-300 opacity-25 animate-bounce" style={{
        animationDelay: '1.5s'
      }} />
        <TrendingUp className="absolute top-1/5 right-1/3 w-5 h-5 text-green-300 opacity-30 animate-pulse" style={{
        animationDelay: '2.5s'
      }} />
        <Zap className="absolute bottom-1/5 left-2/3 w-4 h-4 text-yellow-300 opacity-35 animate-bounce" style={{
        animationDelay: '0.8s'
      }} />
      </div>

      <div className="relative z-10 flex flex-col items-center justify-start min-h-screen max-w-sm mx-auto">
        {/* Enhanced Header Section with more animations */}
        <div className="w-full text-center mb-6 pt-4 py-px">
          <div className="flex items-center justify-center space-x-3 mb-4 animate-scale-in">
            
            <div>
              <h1 className="text-2xl md:text-3xl font-bold bg-gradient-to-r from-blue-200 to-purple-200 bg-clip-text text-transparent animate-fade-in">
                UDSM Hub
              </h1>
              
            </div>
          </div>

          <div className="mb-6">
            <div className="h-14 md:h-16 flex flex-col items-center justify-center">
              <h2 className="text-lg md:text-xl font-bold text-white transition-all duration-700 ease-in-out px-4 text-center animate-scale-in">
                <span key={currentMessageIndex} className="inline-block transition-all duration-500 transform">
                  {welcomeMessages[currentMessageIndex].text}
                </span>
              </h2>
              <p className="text-xs md:text-sm text-blue-200 transition-all duration-700 ease-in-out animate-fade-in" style={{
              animationDelay: '0.3s'
            }}>
                <span key={currentMessageIndex} className="inline-block transition-all duration-500 transform">
                  {welcomeMessages[currentMessageIndex].subtitle}
                </span>
              </p>
            </div>
            
          </div>

          {/* Enhanced Tip Section matching home page style */}
          
        </div>

        {/* Enhanced Auth Card with glassmorphism */}
        <div className="w-full mb-6">
          <Card className="bg-white/10 backdrop-blur-xl border-white/20 shadow-2xl hover:shadow-3xl transition-all duration-500 animate-scale-in hover:bg-white/15" style={{
          animationDelay: '0.6s'
        }}>
            <CardHeader className="text-center space-y-3 pb-4">
              <CardTitle className="text-lg md:text-xl font-bold text-white animate-fade-in">
                {isSignUp ? 'Join the Squad! 🎓' : 'Welcome Back! ✨'}
              </CardTitle>
              <CardDescription className="text-blue-100 text-xs md:text-sm animate-fade-in" style={{
              animationDelay: '0.2s'
            }}>
                {isSignUp ? 'Enter your details quickly, no stress!' : "Sign in to return to our community!"}
              </CardDescription>
            </CardHeader>

            <CardContent className="space-y-4 px-4 pb-4">
              <Form {...form}>
                <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
                  <FormField control={form.control} name="email" render={({
                  field
                }) => <FormItem className="animate-fade-in" style={{
                  animationDelay: '0.3s'
                }}>
                        <FormLabel className="text-white text-sm">Email</FormLabel>
                        <FormControl>
                          <Input placeholder="your.email@example.com" type="email" {...field} className="bg-white/10 border-white/20 text-white placeholder:text-white/60 focus:border-blue-400 transition-all duration-300 h-10 md:h-11 text-sm hover:bg-white/15 focus:bg-white/20 hover:scale-105" disabled={isLoading} />
                        </FormControl>
                        <FormMessage className="text-red-300 text-xs" />
                      </FormItem>} />
                  <FormField control={form.control} name="password" render={({
                  field
                }) => <FormItem className="animate-fade-in" style={{
                  animationDelay: '0.4s'
                }}>
                        <FormLabel className="text-white text-sm">Password</FormLabel>
                        <FormControl>
                          <div className="relative">
                            <Input placeholder={isSignUp ? "At least 6 characters" : "Enter your password"} type={showPassword ? "text" : "password"} {...field} className="bg-white/10 border-white/20 text-white placeholder:text-white/60 focus:border-blue-400 transition-all duration-300 pr-10 md:pr-12 h-10 md:h-11 text-sm hover:bg-white/15 focus:bg-white/20 hover:scale-105" disabled={isLoading} />
                            <Button type="button" variant="ghost" size="sm" className="absolute right-0 top-0 h-full px-2 md:px-3 text-white/60 hover:text-white hover:bg-transparent hover:scale-110 transition-transform duration-200" onClick={() => setShowPassword(!showPassword)} disabled={isLoading}>
                              {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                            </Button>
                          </div>
                        </FormControl>
                        <FormMessage className="text-red-300 text-xs" />
                      </FormItem>} />
                  <Button type="submit" className="w-full bg-gradient-to-r from-blue-500 to-purple-500 hover:from-blue-600 hover:to-purple-600 text-white shadow-lg hover:shadow-xl transition-all duration-300 hover:scale-105 h-11 md:h-12 text-sm md:text-base font-semibold animate-fade-in transform" disabled={isLoading} style={{
                  animationDelay: '0.5s'
                }}>
                    {isLoading ? <div className="flex items-center space-x-2">
                          <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white"></div>
                          <span>{isSignUp ? 'Creating Account...' : 'Signing In...'}</span>
                        </div> : isSignUp ? 'Join the Squad 🚀' : 'Sign In ✨'}
                  </Button>
                </form>
              </Form>

              {/* Google Sign In Button */}
              <div className="relative animate-fade-in" style={{animationDelay: '0.55s'}}>
                <div className="absolute inset-0 flex items-center">
                  <span className="w-full border-t border-white/20" />
                </div>
                <div className="relative flex justify-center text-xs uppercase">
                  <span className="bg-transparent px-2 text-white/60">Or continue with</span>
                </div>
              </div>

              <Button
                type="button"
                variant="outline"
                onClick={handleGoogleSignIn}
                disabled={isLoading}
                className="w-full bg-white/10 border-white/20 text-white hover:bg-white/20 hover:text-white transition-all duration-300 hover:scale-105 h-11 md:h-12 text-sm md:text-base animate-fade-in"
                style={{animationDelay: '0.6s'}}
              >
                <svg className="w-5 h-5 mr-2" viewBox="0 0 24 24">
                  <path
                    fill="currentColor"
                    d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"
                  />
                  <path
                    fill="currentColor"
                    d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"
                  />
                  <path
                    fill="currentColor"
                    d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z"
                  />
                  <path
                    fill="currentColor"
                    d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z"
                  />
                </svg>
                {isLoading ? 'Signing in...' : 'Continue with Google'}
              </Button>

              <div className="text-center animate-fade-in" style={{
              animationDelay: '0.6s'
            }}>
                <Button variant="ghost" onClick={() => {
                setIsSignUp(!isSignUp);
                form.reset();
              }} className="text-blue-200 hover:text-white hover:bg-white/10 transition-all duration-300 text-xs md:text-sm hover:scale-105 transform" disabled={isLoading}>
                  {isSignUp ? 'Already have an account? Sign in' : "Don't have an account? Join now"}
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Enhanced Footer with animations */}
        <div className="w-full mt-6 text-center animate-scale-in" style={{
        animationDelay: '0.8s'
      }}>
          <div className="bg-white/5 backdrop-blur-sm rounded-lg p-3 md:p-4 border border-white/10 hover:bg-white/10 transition-all duration-300 hover:scale-105 transform">
            <div className="flex items-center justify-center space-x-2 mb-2">
              <Heart className="h-4 w-4 text-red-400 animate-pulse" />
              <p className="text-white/70 text-xs">
                Built with love by <span className="text-blue-300 font-semibold">Japhet Jr</span>
              </p>
            </div>
            <p className="text-white/50 text-xs mt-1">
              East Africa's Premier Student Platform 🌍
            </p>
          </div>
        </div>
      </div>
    </div>;
};
export default Auth;