import { Button } from "@/components/ui/button";
import { ArrowLeft, Gamepad2 } from "lucide-react";
import { Link } from "react-router-dom";
import { DailyGames } from "@/components/fun-zone/DailyGames";

const Hostels = () => {
  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 via-white to-pink-50">
      {/* Header */}
      <header className="bg-white/80 backdrop-blur-sm shadow-sm border-b sticky top-0 z-50 animate-fade-in">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center space-x-4">
              <Link to="/">
                <Button variant="outline" size="icon" className="hover:scale-110 transition-transform duration-200">
                  <ArrowLeft className="h-4 w-4" />
                </Button>
              </Link>
              <div className="flex items-center space-x-2">
                <div className="bg-gradient-to-r from-purple-600 to-pink-600 text-white p-2 rounded-lg animate-pulse">
                  <Gamepad2 className="h-6 w-6" />
                </div>
                <div>
                  <h1 className="text-lg sm:text-xl font-bold text-gray-900">Daily Games Hub</h1>
                  <p className="text-xs text-gray-600 hidden sm:block">Challenge yourself daily</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 sm:py-8 pb-6">
        <div className="text-center mb-6">
          <h2 className="text-2xl sm:text-3xl font-bold text-gray-800 mb-2 animate-fade-in">
            Daily Games Hub 🎮
          </h2>
          <p className="text-gray-600 animate-fade-in" style={{animationDelay: '0.2s'}}>
            Challenge yourself with fun daily games and earn points!
          </p>
        </div>

        <DailyGames />
      </main>
    </div>
  );
};

export default Hostels;