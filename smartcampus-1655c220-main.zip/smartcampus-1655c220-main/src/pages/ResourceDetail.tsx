
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { ArrowLeft, Download, Star, BookOpen, Eye, Heart, Share2 } from "lucide-react";
import { Link, useParams } from "react-router-dom";

const ResourceDetail = () => {
  const { id } = useParams();
  const [isDownloading, setIsDownloading] = useState(false);
  const [isFavorited, setIsFavorited] = useState(false);

  // Mock resource data
  const resource = {
    id: 1,
    title: "Calculus I - Final Exam 2023",
    type: "Past Paper",
    faculty: "Engineering",
    course: "MA 101",
    downloads: 245,
    rating: 4.8,
    uploadedBy: "John Mwanza",
    uploadDate: "2024-01-15",
    fileSize: "2.5 MB",
    pages: 12,
    description: "Comprehensive final exam for Calculus I covering limits, derivatives, and integrals. Includes detailed solutions and marking scheme. This exam paper follows the latest syllabus and is perfect for exam preparation.",
    tags: ["calculus", "mathematics", "final-exam", "derivatives", "integrals"],
    preview: "https://images.unsplash.com/photo-1635070041078-e363dbe005cb?w=400&h=500&fit=crop",
    relatedResources: [
      { title: "Calculus I - Midterm Exam", type: "Past Paper", rating: 4.6 },
      { title: "Calculus Practice Problems", type: "Notes", rating: 4.7 },
      { title: "Derivative Rules Cheat Sheet", type: "Reference", rating: 4.9 }
    ]
  };

  const handleDownload = async () => {
    setIsDownloading(true);
    // Simulate download
    setTimeout(() => {
      setIsDownloading(false);
      // In a real app, trigger actual file download
      console.log("Download started for:", resource.title);
    }, 2000);
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <Link to="/resources" className="flex items-center space-x-2 text-blue-600 hover:text-blue-700">
              <ArrowLeft className="h-5 w-5" />
              <span>Back to Resources</span>
            </Link>
            <div className="flex items-center space-x-2">
              <Button
                variant="outline"
                size="sm"
                onClick={() => setIsFavorited(!isFavorited)}
                className={isFavorited ? "text-red-600 border-red-200" : ""}
              >
                <Heart className={`h-4 w-4 mr-1 ${isFavorited ? 'fill-red-600' : ''}`} />
                {isFavorited ? 'Saved' : 'Save'}
              </Button>
              <Button variant="outline" size="sm">
                <Share2 className="h-4 w-4 mr-1" />
                Share
              </Button>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Main Content */}
          <div className="lg:col-span-2 space-y-6">
            {/* Resource Info */}
            <Card>
              <CardContent className="p-6">
                <div className="flex items-start justify-between mb-4">
                  <div className="flex space-x-2">
                    <Badge variant="secondary">{resource.type}</Badge>
                    <Badge className="bg-blue-100 text-blue-800">{resource.faculty}</Badge>
                  </div>
                  <div className="flex items-center space-x-1">
                    <Star className="h-4 w-4 fill-yellow-400 text-yellow-400" />
                    <span className="text-sm font-medium">{resource.rating}</span>
                  </div>
                </div>
                
                <h1 className="text-2xl font-bold text-gray-900 mb-2">{resource.title}</h1>
                <p className="text-lg text-gray-600 mb-4">{resource.course} • {resource.faculty}</p>
                
                <div className="flex items-center space-x-6 text-sm text-gray-600 mb-6">
                  <div className="flex items-center space-x-1">
                    <Download className="h-4 w-4" />
                    <span>{resource.downloads} downloads</span>
                  </div>
                  <div className="flex items-center space-x-1">
                    <BookOpen className="h-4 w-4" />
                    <span>{resource.pages} pages</span>
                  </div>
                  <div className="flex items-center space-x-1">
                    <Eye className="h-4 w-4" />
                    <span>{resource.fileSize}</span>
                  </div>
                </div>

                {/* Upload Info */}
                <div className="flex items-center space-x-3 mb-6">
                  <Avatar className="h-10 w-10">
                    <AvatarFallback className="bg-blue-100 text-blue-700">
                      {resource.uploadedBy.split(' ').map(n => n[0]).join('')}
                    </AvatarFallback>
                  </Avatar>
                  <div>
                    <p className="font-medium text-gray-900">{resource.uploadedBy}</p>
                    <p className="text-sm text-gray-600">Uploaded on {resource.uploadDate}</p>
                  </div>
                </div>

                {/* Description */}
                <div className="mb-6">
                  <h3 className="font-semibold text-gray-900 mb-2">Description</h3>
                  <p className="text-gray-700">{resource.description}</p>
                </div>

                {/* Tags */}
                <div className="mb-6">
                  <h3 className="font-semibold text-gray-900 mb-2">Tags</h3>
                  <div className="flex flex-wrap gap-2">
                    {resource.tags.map((tag, index) => (
                      <Badge key={index} variant="outline" className="text-xs">
                        {tag}
                      </Badge>
                    ))}
                  </div>
                </div>

                {/* Download Button */}
                <Button 
                  onClick={handleDownload}
                  disabled={isDownloading}
                  className="w-full bg-blue-600 hover:bg-blue-700"
                  size="lg"
                >
                  <Download className="h-5 w-5 mr-2" />
                  {isDownloading ? "Downloading..." : "Download Resource"}
                </Button>
              </CardContent>
            </Card>
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Preview */}
            <Card>
              <CardHeader>
                <CardTitle>Preview</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="aspect-[3/4] bg-gray-200 rounded-lg overflow-hidden mb-3">
                  <img 
                    src={resource.preview} 
                    alt="Resource preview"
                    className="w-full h-full object-cover"
                  />
                </div>
                <p className="text-sm text-gray-600 text-center">First page preview</p>
              </CardContent>
            </Card>

            {/* Related Resources */}
            <Card>
              <CardHeader>
                <CardTitle>Related Resources</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {resource.relatedResources.map((related, index) => (
                    <div key={index} className="p-3 bg-gray-50 rounded-lg hover:bg-gray-100 cursor-pointer">
                      <h4 className="font-medium text-sm text-gray-900 mb-1">{related.title}</h4>
                      <div className="flex items-center justify-between">
                        <Badge variant="outline" className="text-xs">{related.type}</Badge>
                        <div className="flex items-center space-x-1">
                          <Star className="h-3 w-3 fill-yellow-400 text-yellow-400" />
                          <span className="text-xs text-gray-600">{related.rating}</span>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Course Info */}
            <Card>
              <CardHeader>
                <CardTitle>Course Information</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-2 text-sm">
                  <div className="flex justify-between">
                    <span className="text-gray-600">Course:</span>
                    <span className="font-medium">{resource.course}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">Faculty:</span>
                    <span className="font-medium">{resource.faculty}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">Type:</span>
                    <span className="font-medium">{resource.type}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">File Size:</span>
                    <span className="font-medium">{resource.fileSize}</span>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>
    </div>
  );
};

export default ResourceDetail;
