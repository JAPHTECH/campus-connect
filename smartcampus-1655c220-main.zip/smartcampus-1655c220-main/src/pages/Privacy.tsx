
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { ArrowLeft, Shield, Lock, Eye, Database, Users } from "lucide-react";
import { Link } from "react-router-dom";
import { useToast } from "@/hooks/use-toast";

const Privacy = () => {
  const { toast } = useToast();
  const [privacySettings, setPrivacySettings] = useState({
    publicProfile: false,
    showEmail: false,
    showPhone: false,
    showActivity: true,
    analytics: true,
    personalization: true,
    marketing: false,
    directMessages: true,
    forumMentions: true,
    groupInvites: true,
    twoFactor: false,
    loginAlerts: true
  });

  const handleToggle = (setting: string) => {
    setPrivacySettings(prev => ({ ...prev, [setting]: !prev[setting as keyof typeof prev] }));
    toast({
      title: "Privacy setting updated",
      description: `${setting.replace(/([A-Z])/g, ' $1').toLowerCase()} has been ${!privacySettings[setting as keyof typeof privacySettings] ? 'enabled' : 'disabled'}.`,
    });
  };

  const handleViewLoginHistory = () => {
    toast({
      title: "Login History",
      description: "Login history feature will be available soon.",
    });
  };

  const handleDownloadData = () => {
    const userData = {
      profile: "User profile data",
      posts: "User posts and comments",
      messages: "User messages",
      settings: privacySettings
    };
    
    const dataStr = JSON.stringify(userData, null, 2);
    const dataBlob = new Blob([dataStr], { type: 'application/json' });
    const url = URL.createObjectURL(dataBlob);
    
    const link = document.createElement('a');
    link.href = url;
    link.download = 'my-data.json';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
    
    toast({
      title: "Data downloaded",
      description: "Your data has been downloaded successfully.",
    });
  };

  const handleRequestDeletion = () => {
    toast({
      title: "Data deletion requested",
      description: "Your data deletion request has been submitted. You'll receive confirmation via email.",
    });
  };

  const handleDeleteAccount = () => {
    toast({
      title: "Account deletion",
      description: "Please contact support to permanently delete your account.",
      variant: "destructive",
    });
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-indigo-100 pb-20">
      {/* Header */}
      <div className="bg-gradient-to-r from-blue-600 via-purple-600 to-indigo-600 text-white">
        <div className="max-w-4xl mx-auto px-4 py-6">
          <div className="flex items-center space-x-4">
            <Link to="/profile">
              <Button variant="ghost" size="sm" className="text-white hover:bg-white/20">
                <ArrowLeft className="h-4 w-4" />
              </Button>
            </Link>
            <h1 className="text-2xl font-bold">Privacy Settings</h1>
          </div>
        </div>
      </div>

      {/* Content */}
      <div className="max-w-2xl mx-auto px-4 -mt-8 space-y-4">
        {/* Profile Privacy */}
        <Card className="shadow-xl border-0 bg-white/80 backdrop-blur-sm">
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <Eye className="h-5 w-5" />
              <span>Profile Visibility</span>
            </CardTitle>
            <CardDescription>Control who can see your profile information</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center justify-between">
              <Label htmlFor="public-profile">Make Profile Public</Label>
              <Switch 
                id="public-profile" 
                checked={privacySettings.publicProfile}
                onCheckedChange={() => handleToggle('publicProfile')}
              />
            </div>
            <div className="flex items-center justify-between">
              <Label htmlFor="show-email">Show Email Address</Label>
              <Switch 
                id="show-email" 
                checked={privacySettings.showEmail}
                onCheckedChange={() => handleToggle('showEmail')}
              />
            </div>
            <div className="flex items-center justify-between">
              <Label htmlFor="show-phone">Show Phone Number</Label>
              <Switch 
                id="show-phone" 
                checked={privacySettings.showPhone}
                onCheckedChange={() => handleToggle('showPhone')}
              />
            </div>
            <div className="flex items-center justify-between">
              <Label htmlFor="show-activity">Show Activity Status</Label>
              <Switch 
                id="show-activity" 
                checked={privacySettings.showActivity}
                onCheckedChange={() => handleToggle('showActivity')}
              />
            </div>
          </CardContent>
        </Card>

        {/* Data Privacy */}
        <Card className="shadow-xl border-0 bg-white/80 backdrop-blur-sm">
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <Database className="h-5 w-5" />
              <span>Data Privacy</span>
            </CardTitle>
            <CardDescription>Manage how your data is used and shared</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center justify-between">
              <Label htmlFor="analytics">Allow Analytics</Label>
              <Switch 
                id="analytics" 
                checked={privacySettings.analytics}
                onCheckedChange={() => handleToggle('analytics')}
              />
            </div>
            <div className="flex items-center justify-between">
              <Label htmlFor="personalization">Personalized Content</Label>
              <Switch 
                id="personalization" 
                checked={privacySettings.personalization}
                onCheckedChange={() => handleToggle('personalization')}
              />
            </div>
            <div className="flex items-center justify-between">
              <Label htmlFor="marketing">Marketing Communications</Label>
              <Switch 
                id="marketing" 
                checked={privacySettings.marketing}
                onCheckedChange={() => handleToggle('marketing')}
              />
            </div>
          </CardContent>
        </Card>

        {/* Communication Privacy */}
        <Card className="shadow-xl border-0 bg-white/80 backdrop-blur-sm">
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <Users className="h-5 w-5" />
              <span>Communication</span>
            </CardTitle>
            <CardDescription>Control who can contact you</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center justify-between">
              <Label htmlFor="direct-messages">Allow Direct Messages</Label>
              <Switch 
                id="direct-messages" 
                checked={privacySettings.directMessages}
                onCheckedChange={() => handleToggle('directMessages')}
              />
            </div>
            <div className="flex items-center justify-between">
              <Label htmlFor="forum-mentions">Forum Mentions</Label>
              <Switch 
                id="forum-mentions" 
                checked={privacySettings.forumMentions}
                onCheckedChange={() => handleToggle('forumMentions')}
              />
            </div>
            <div className="flex items-center justify-between">
              <Label htmlFor="group-invites">Study Group Invites</Label>
              <Switch 
                id="group-invites" 
                checked={privacySettings.groupInvites}
                onCheckedChange={() => handleToggle('groupInvites')}
              />
            </div>
          </CardContent>
        </Card>

        {/* Security */}
        <Card className="shadow-xl border-0 bg-white/80 backdrop-blur-sm">
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <Lock className="h-5 w-5" />
              <span>Security</span>
            </CardTitle>
            <CardDescription>Additional security measures</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center justify-between">
              <Label htmlFor="two-factor">Two-Factor Authentication</Label>
              <Switch 
                id="two-factor" 
                checked={privacySettings.twoFactor}
                onCheckedChange={() => handleToggle('twoFactor')}
              />
            </div>
            <div className="flex items-center justify-between">
              <Label htmlFor="login-alerts">Login Alerts</Label>
              <Switch 
                id="login-alerts" 
                checked={privacySettings.loginAlerts}
                onCheckedChange={() => handleToggle('loginAlerts')}
              />
            </div>
            <Button variant="outline" className="w-full justify-start" onClick={handleViewLoginHistory}>
              View Login History
            </Button>
          </CardContent>
        </Card>

        {/* Data Export */}
        <Card className="shadow-xl border-0 bg-white/80 backdrop-blur-sm">
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <Shield className="h-5 w-5" />
              <span>Data Rights</span>
            </CardTitle>
            <CardDescription>Manage your data and account</CardDescription>
          </CardHeader>
          <CardContent className="space-y-3">
            <Button variant="outline" className="w-full justify-start" onClick={handleDownloadData}>
              Download My Data
            </Button>
            <Button variant="outline" className="w-full justify-start" onClick={handleRequestDeletion}>
              Request Data Deletion
            </Button>
            <Button variant="destructive" className="w-full justify-start" onClick={handleDeleteAccount}>
              Delete Account
            </Button>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default Privacy;
