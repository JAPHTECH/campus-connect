
import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import * as z from 'zod';
import { ArrowLeft, Home, MapPin, Phone, Plus, X } from 'lucide-react';
import { Link } from 'react-router-dom';
import { toast } from 'sonner';

const listHostelSchema = z.object({
  name: z.string().min(1, 'Jina la hostel linahitajika (Hostel name is required)'),
  address: z.string().min(1, 'Anuani inahitajika (Address is required)'),
  pricePerMonth: z.string().min(1, 'Bei kwa mwezi inahitajika (Price per month is required)'),
  availableRooms: z.string().min(1, 'Idadi ya vyumba vya kupatikana inahitajika (Available rooms is required)'),
  description: z.string().min(10, 'Maelezo yawe na angalau herufi 10 (Description must be at least 10 characters)'),
  contactPhone: z.string().min(1, 'Nambari ya simu inahitajika (Phone number is required)'),
  contactEmail: z.string().email('Weka barua pepe sahihi (Please enter a valid email)').optional().or(z.literal('')),
});

const ListHostel = () => {
  const [amenities, setAmenities] = useState<string[]>(['WiFi', 'Maji safi (Clean water)']);
  const [newAmenity, setNewAmenity] = useState('');

  const form = useForm<z.infer<typeof listHostelSchema>>({
    resolver: zodResolver(listHostelSchema),
    defaultValues: {
      name: '',
      address: '',
      pricePerMonth: '',
      availableRooms: '',
      description: '',
      contactPhone: '',
      contactEmail: '',
    },
  });

  const onSubmit = async (values: z.infer<typeof listHostelSchema>) => {
    try {
      console.log('Hostel listing data:', { ...values, amenities });
      // Here you would typically send data to your backend/Supabase
      toast.success('Hostel imeorodheshwa kikamilifu! (Hostel listed successfully!)');
      form.reset();
      setAmenities(['WiFi', 'Maji safi (Clean water)']);
    } catch (error) {
      console.error('Error listing hostel:', error);
      toast.error('Kosa limejitokeza wakati wa kuorodhesha hostel (Error occurred while listing hostel)');
    }
  };

  const addAmenity = () => {
    if (newAmenity.trim() && !amenities.includes(newAmenity.trim())) {
      setAmenities([...amenities, newAmenity.trim()]);
      setNewAmenity('');
    }
  };

  const removeAmenity = (amenity: string) => {
    setAmenities(amenities.filter(a => a !== amenity));
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center h-16">
            <Link to="/hostels" className="flex items-center space-x-2 text-blue-600 hover:text-blue-700">
              <ArrowLeft className="h-5 w-5" />
              <span>Rudi kwa Hostels (Back to Hostels)</span>
            </Link>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-2xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
        <Card className="bg-white shadow-lg">
          <CardHeader className="text-center">
            <div className="mx-auto bg-blue-100 p-3 rounded-full w-fit mb-4">
              <Home className="h-8 w-8 text-blue-600" />
            </div>
            <CardTitle className="text-2xl font-bold text-gray-900">
              Orodhesha Hostel Yako (List Your Hostel)
            </CardTitle>
            <p className="text-gray-600 mt-2">
              Ongeza hostel yako katika orodha ya UDSM na upate wanafunzi
              (Add your hostel to the UDSM list and get students)
            </p>
          </CardHeader>

          <CardContent className="space-y-6">
            <Form {...form}>
              <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
                <FormField
                  control={form.control}
                  name="name"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Jina la Hostel (Hostel Name)</FormLabel>
                      <FormControl>
                        <Input 
                          placeholder="Mfano: Green Valley Hostel"
                          {...field} 
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="address"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel className="flex items-center gap-2">
                        <MapPin className="h-4 w-4" />
                        Anuani (Address)
                      </FormLabel>
                      <FormControl>
                        <Input 
                          placeholder="Mfano: Kijitonyama, Barabara ya Kimara"
                          {...field} 
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <div className="grid grid-cols-2 gap-4">
                  <FormField
                    control={form.control}
                    name="pricePerMonth"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Bei kwa Mwezi (TSH)</FormLabel>
                        <FormControl>
                          <Input 
                            placeholder="150,000"
                            {...field} 
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="availableRooms"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Vyumba Vinavyopatikana</FormLabel>
                        <FormControl>
                          <Input 
                            placeholder="5"
                            type="number"
                            {...field} 
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>

                <FormField
                  control={form.control}
                  name="description"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Maelezo ya Hostel (Hostel Description)</FormLabel>
                      <FormControl>
                        <Textarea 
                          placeholder="Elezea vipengele vya hostel yako, mazingira, na kila kitu kingine kinachovutia..."
                          className="min-h-[100px]"
                          {...field} 
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                {/* Amenities Section */}
                <div className="space-y-3">
                  <FormLabel>Huduma na Vifaa (Amenities)</FormLabel>
                  <div className="flex flex-wrap gap-2 mb-3">
                    {amenities.map((amenity, index) => (
                      <div key={index} className="flex items-center gap-1 bg-blue-100 text-blue-800 px-3 py-1 rounded-full text-sm">
                        {amenity}
                        <Button
                          type="button"
                          variant="ghost"
                          size="sm"
                          className="h-4 w-4 p-0 hover:bg-blue-200"
                          onClick={() => removeAmenity(amenity)}
                        >
                          <X className="h-3 w-3" />
                        </Button>
                      </div>
                    ))}
                  </div>
                  <div className="flex gap-2">
                    <Input
                      placeholder="Ongeza huduma (e.g., Parking, Security)"
                      value={newAmenity}
                      onChange={(e) => setNewAmenity(e.target.value)}
                      onKeyPress={(e) => e.key === 'Enter' && (e.preventDefault(), addAmenity())}
                    />
                    <Button type="button" onClick={addAmenity} variant="outline">
                      <Plus className="h-4 w-4" />
                    </Button>
                  </div>
                </div>

                {/* Contact Information */}
                <div className="space-y-4 border-t pt-4">
                  <h3 className="font-semibold text-gray-900">Maelezo ya Mawasiliano (Contact Information)</h3>
                  
                  <FormField
                    control={form.control}
                    name="contactPhone"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel className="flex items-center gap-2">
                          <Phone className="h-4 w-4" />
                          Nambari ya Simu (Phone Number)
                        </FormLabel>
                        <FormControl>
                          <Input 
                            placeholder="+255 XXX XXX XXX"
                            {...field} 
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="contactEmail"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Barua Pepe (Email) - Si lazima</FormLabel>
                        <FormControl>
                          <Input 
                            placeholder="email@example.com"
                            type="email"
                            {...field} 
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>

                <Button 
                  type="submit" 
                  className="w-full bg-blue-600 hover:bg-blue-700 text-white py-3"
                >
                  Orodhesha Hostel (List Hostel)
                </Button>
              </form>
            </Form>
          </CardContent>
        </Card>
      </main>
    </div>
  );
};

export default ListHostel;
