
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Progress } from "@/components/ui/progress";
import { ArrowLeft, Upload, FileText, BookOpen, CheckCircle, Sparkles, Star } from "lucide-react";
import { Link, useNavigate } from "react-router-dom";
import { useForm } from "react-hook-form";
import { useAuth } from "@/contexts/AuthContext";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";

const UploadResource = () => {
  const navigate = useNavigate();
  const { user } = useAuth();
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [uploadProgress, setUploadProgress] = useState(0);
  const [isUploading, setIsUploading] = useState(false);
  const [uploadSuccess, setUploadSuccess] = useState(false);
  
  const form = useForm({
    defaultValues: {
      title: "",
      description: "",
      course: "",
      subject: "",
      type: "",
      year: "",
    }
  });

  const resourceTypes = ["Notes", "Past Paper", "Lab Manual", "Assignment", "Project", "Presentation", "Other"];
  const subjects = ["Mathematics", "Physics", "Chemistry", "Biology", "Computer Science", "Engineering", "Business", "Economics", "Literature", "History", "Other"];
  const years = ["2024", "2023", "2022", "2021", "2020", "2019"];

  const handleFileUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      // Check file size (max 10MB)
      if (file.size > 10 * 1024 * 1024) {
        toast.error("File size must be less than 10MB");
        return;
      }
      setSelectedFile(file);
      // Add some fun celebration when file is selected
      toast.success("File selected! 🎉");
    }
  };

  const uploadFileToStorage = async (file: File): Promise<string | null> => {
    if (!user) return null;

    const fileExt = file.name.split('.').pop();
    const fileName = `${user.id}/${Date.now()}.${fileExt}`;

    try {
      console.log('Starting file upload to resources_files bucket...');
      
      // Simulate upload progress with more dynamic updates
      const progressInterval = setInterval(() => {
        setUploadProgress(prev => {
          const newProgress = Math.min(prev + Math.random() * 15 + 5, 90);
          return newProgress;
        });
      }, 200);

      const { data, error } = await supabase.storage
        .from('resources_files')
        .upload(fileName, file);

      clearInterval(progressInterval);
      setUploadProgress(100);

      if (error) {
        console.error('Storage upload error:', error);
        // Show bucket-specific error message if relevant
        if (
          typeof error.message === "string" &&
          error.message.toLowerCase().includes("bucket")
        ) {
          toast.error("Upload bucket is missing. Please contact support.");
        } else {
          toast.error('Failed to upload file: ' + error.message);
        }
        return null;
      }
      
      if (!data || !data.path) {
        toast.error("File uploaded but file path missing. Please try again.");
        return null;
      }

      console.log('File uploaded successfully:', data);
      return data.path;
    } catch (error) {
      console.error('File upload error:', error);
      toast.error('Failed to upload file: ' + (error as Error).message);
      return null;
    }
  };

  const onSubmit = async (data: any) => {
    if (!user) {
      toast.error("Please log in to upload resources");
      return;
    }

    if (!selectedFile) {
      toast.error("Please select a file to upload");
      return;
    }

    if (!data.title.trim()) {
      toast.error("Please enter a resource title");
      return;
    }

    if (!data.subject) {
      toast.error("Please select a subject");
      return;
    }

    if (!data.type) {
      toast.error("Please select a resource type");
      return;
    }

    setIsUploading(true);
    setUploadProgress(0);

    try {
      console.log('Starting upload process...');
      
      // Upload file to storage
      const filePath = await uploadFileToStorage(selectedFile);
      if (!filePath) {
        setIsUploading(false);
        return;
      }

      console.log('File uploaded to storage, now saving to database...');

      // Save resource data to database
      const { error } = await supabase
        .from('resources')
        .insert({
          title: data.title,
          description: data.description || null,
          course_code: data.course || null,
          subject: data.subject,
          type: data.type,
          year: data.year ? parseInt(data.year) : null,
          file_url: filePath,
          file_type: selectedFile.type,
          user_id: user.id,
        });

      if (error) {
        console.error('Database insert error:', error);
        throw error;
      }

      console.log('Resource saved to database successfully!');
      
      // Success animation
      setUploadSuccess(true);
      toast.success("🎉 Resource uploaded successfully! You're awesome!");
      
      // Clear form
      form.reset();
      setSelectedFile(null);
      setUploadProgress(0);
      
      // Navigate back to resources after celebration
      setTimeout(() => navigate("/resources"), 2000);

    } catch (error) {
      console.error('Upload error:', error);
      toast.error('Failed to upload resource: ' + (error as Error).message);
    } finally {
      setIsUploading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 via-blue-50 to-green-50 relative overflow-hidden">
      {/* Animated background elements */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-10 left-10 w-20 h-20 bg-blue-200 rounded-full opacity-20 animate-pulse"></div>
        <div className="absolute top-32 right-20 w-16 h-16 bg-purple-200 rounded-full opacity-30 animate-bounce" style={{animationDelay: '1s'}}></div>
        <div className="absolute bottom-20 left-1/4 w-12 h-12 bg-green-200 rounded-full opacity-25 animate-ping" style={{animationDelay: '2s'}}></div>
        <div className="absolute bottom-40 right-1/3 w-8 h-8 bg-yellow-200 rounded-full opacity-20 animate-pulse" style={{animationDelay: '0.5s'}}></div>
        <Sparkles className="absolute top-1/4 left-1/3 w-6 h-6 text-purple-300 opacity-40 animate-spin" style={{animationDuration: '3s'}} />
        <Star className="absolute bottom-1/3 right-1/4 w-5 h-5 text-blue-300 opacity-30 animate-pulse" />
      </div>

      {/* Header */}
      <header className="bg-white/80 backdrop-blur-sm shadow-sm border-b relative z-10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center h-16">
            <Link to="/resources" className="flex items-center space-x-2 text-blue-600 hover:text-blue-700 transition-colors hover:scale-105 transform duration-200">
              <ArrowLeft className="h-5 w-5" />
              <span>Back to Resources</span>
            </Link>
          </div>
        </div>
      </header>

      {/* Success Overlay */}
      {uploadSuccess && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 animate-fade-in">
          <div className="bg-white rounded-lg p-8 text-center animate-scale-in">
            <CheckCircle className="h-16 w-16 text-green-500 mx-auto mb-4 animate-bounce" />
            <h2 className="text-2xl font-bold text-gray-900 mb-2">🎉 Success!</h2>
            <p className="text-gray-600">Your resource has been uploaded successfully!</p>
          </div>
        </div>
      )}

      {/* Main Content */}
      <main className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8 relative z-10">
        <div className="mb-8 text-center">
          <h1 className="text-4xl font-bold text-gray-900 mb-2 animate-fade-in">
            Upload Study Resource ✨
          </h1>
          <p className="text-gray-600 text-lg animate-fade-in" style={{animationDelay: '0.2s'}}>
            Share your knowledge and help fellow students succeed! 🚀
          </p>
        </div>

        <Card className="shadow-2xl border-0 bg-white/90 backdrop-blur-sm animate-fade-in hover:shadow-3xl transition-all duration-300" style={{animationDelay: '0.4s'}}>
          <CardHeader className="text-center">
            <CardTitle className="flex items-center justify-center space-x-2 text-2xl">
              <BookOpen className="h-6 w-6 text-blue-600 animate-pulse" />
              <span className="bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
                Resource Details
              </span>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <Form {...form}>
              <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                {/* File Upload */}
                <div className="space-y-4">
                  <label className="block text-sm font-medium text-gray-700">Upload File *</label>
                  <div className="border-2 border-dashed border-blue-300 rounded-lg p-8 text-center hover:border-blue-400 transition-all duration-300 hover:bg-blue-50/50 hover:scale-105 transform">
                    <input
                      type="file"
                      accept=".pdf,.doc,.docx,.ppt,.pptx,.txt,.jpg,.jpeg,.png"
                      onChange={handleFileUpload}
                      className="hidden"
                      id="file-upload"
                      disabled={isUploading}
                    />
                    <label htmlFor="file-upload" className={`cursor-pointer ${isUploading ? 'pointer-events-none' : ''}`}>
                      {isUploading ? (
                        <CheckCircle className="h-16 w-16 text-green-500 mx-auto mb-4 animate-bounce" />
                      ) : (
                        <FileText className="h-16 w-16 text-blue-400 mx-auto mb-4 hover:text-blue-500 transition-colors animate-pulse" />
                      )}
                      <p className="text-gray-600 text-lg font-medium">
                        {isUploading ? '🚀 Uploading your awesome content...' : '📁 Click to upload your file'}
                      </p>
                      <p className="text-sm text-gray-500 mt-2">
                        PDF, DOC, DOCX, PPT, PPTX, TXT, JPG, PNG up to 10MB
                      </p>
                    </label>
                  </div>
                  
                  {selectedFile && (
                    <div className="bg-gradient-to-r from-blue-50 to-purple-50 border border-blue-200 rounded-lg p-4 animate-scale-in">
                      <div className="flex items-center space-x-3">
                        <FileText className="h-10 w-10 text-blue-600 animate-pulse" />
                        <div className="flex-1">
                          <p className="font-medium text-blue-900 text-lg">{selectedFile.name}</p>
                          <p className="text-sm text-blue-600">{(selectedFile.size / 1024 / 1024).toFixed(2)} MB</p>
                        </div>
                        {!isUploading && (
                          <button
                            type="button"
                            onClick={() => setSelectedFile(null)}
                            className="ml-auto text-red-600 hover:text-red-700 hover:scale-110 transform transition-all duration-200"
                          >
                            ✕ Remove
                          </button>
                        )}
                      </div>
                      
                      {isUploading && uploadProgress > 0 && (
                        <div className="mt-4">
                          <Progress value={uploadProgress} className="w-full h-3" />
                          <p className="text-sm text-blue-600 mt-2 font-medium animate-pulse">
                            {Math.round(uploadProgress)}% uploaded - Almost there! 🎯
                          </p>
                        </div>
                      )}
                    </div>
                  )}
                </div>

                <FormField
                  control={form.control}
                  name="title"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel className="text-lg font-medium">Resource Title *</FormLabel>
                      <FormControl>
                        <Input 
                          placeholder="e.g., Calculus I - Final Exam 2023 📚" 
                          {...field} 
                          disabled={isUploading}
                          className="text-lg p-4 border-2 focus:border-blue-400 transition-all duration-200 hover:border-blue-300"
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="description"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel className="text-lg font-medium">Description</FormLabel>
                      <FormControl>
                        <Textarea
                          placeholder="Describe the content, topics covered, and any helpful information... ✍️"
                          className="min-h-[120px] text-lg p-4 border-2 focus:border-blue-400 transition-all duration-200 hover:border-blue-300"
                          {...field}
                          disabled={isUploading}
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <FormField
                    control={form.control}
                    name="course"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel className="text-lg font-medium">Course Code</FormLabel>
                        <FormControl>
                          <Input 
                            placeholder="e.g., MA 101 🎓" 
                            {...field} 
                            disabled={isUploading}
                            className="text-lg p-4 border-2 focus:border-blue-400 transition-all duration-200 hover:border-blue-300"
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="subject"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel className="text-lg font-medium">Subject *</FormLabel>
                        <FormControl>
                          <select
                            {...field}
                            disabled={isUploading}
                            className="w-full px-4 py-4 text-lg border-2 border-gray-300 rounded-md focus:outline-none focus:border-blue-400 transition-all duration-200 hover:border-blue-300 bg-white"
                          >
                            <option value="">📖 Select subject</option>
                            {subjects.map(subject => (
                              <option key={subject} value={subject}>{subject}</option>
                            ))}
                          </select>
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <FormField
                    control={form.control}
                    name="type"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel className="text-lg font-medium">Resource Type *</FormLabel>
                        <FormControl>
                          <select
                            {...field}
                            disabled={isUploading}
                            className="w-full px-4 py-4 text-lg border-2 border-gray-300 rounded-md focus:outline-none focus:border-blue-400 transition-all duration-200 hover:border-blue-300 bg-white"
                          >
                            <option value="">📝 Select type</option>
                            {resourceTypes.map(type => (
                              <option key={type} value={type}>{type}</option>
                            ))}
                          </select>
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="year"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel className="text-lg font-medium">Academic Year</FormLabel>
                        <FormControl>
                          <select
                            {...field}
                            disabled={isUploading}
                            className="w-full px-4 py-4 text-lg border-2 border-gray-300 rounded-md focus:outline-none focus:border-blue-400 transition-all duration-200 hover:border-blue-300 bg-white"
                          >
                            <option value="">📅 Select year</option>
                            {years.map(year => (
                              <option key={year} value={year}>{year}</option>
                            ))}
                          </select>
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>

                <div className="flex space-x-4 pt-6">
                  <Button
                    type="button"
                    variant="outline"
                    onClick={() => navigate("/resources")}
                    disabled={isUploading}
                    className="flex-1 py-4 text-lg border-2 hover:scale-105 transform transition-all duration-200"
                  >
                    Cancel
                  </Button>
                  <Button
                    type="submit"
                    disabled={isUploading || !selectedFile}
                    className="flex-1 py-4 text-lg bg-gradient-to-r from-blue-600 to-purple-600 text-white disabled:opacity-50 hover:scale-105 transform transition-all duration-200 hover:shadow-lg"
                  >
                    <Upload className="h-5 w-5 mr-2" />
                    {isUploading ? '🚀 Uploading...' : '📤 Upload Resource'}
                  </Button>
                </div>
              </form>
            </Form>
          </CardContent>
        </Card>
      </main>
    </div>
  );
};

export default UploadResource;
