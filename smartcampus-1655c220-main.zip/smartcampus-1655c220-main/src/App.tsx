
import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import { AuthProvider } from "@/contexts/AuthContext";
import Index from "./pages/Index";
import Auth from "./pages/Auth";
import Resources from "./pages/Resources";
import UploadResource from "./pages/UploadResource";
import ResourceDetail from "./pages/ResourceDetail";
import Hostels from "./pages/Hostels";
import HostelDetail from "./pages/HostelDetail";
import ListHostel from "./pages/ListHostel";
import Marketplace from "./pages/Marketplace";
import ItemDetail from "./pages/ItemDetail";
import SellItem from "./pages/SellItem";
import FunZone from "./pages/FunZone";
import Timetable from "./pages/Timetable";
import Profile from "./pages/Profile";
import EditProfile from "./pages/EditProfile";
import Settings from "./pages/Settings";
import Notifications from "./pages/Notifications";
import Privacy from "./pages/Privacy";
import NotFound from "./pages/NotFound";

const queryClient = new QueryClient();

const App = () => (
  <QueryClientProvider client={queryClient}>
    <AuthProvider>
      <TooltipProvider>
        <Toaster />
        <Sonner />
        <BrowserRouter>
          <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-indigo-100">
            <Routes>
              <Route path="/" element={<Index />} />
              <Route path="/auth" element={<Auth />} />
              <Route path="/resources" element={<Resources />} />
              <Route path="/resources/upload" element={<UploadResource />} />
              <Route path="/resources/:id" element={<ResourceDetail />} />
              <Route path="/hostels" element={<Hostels />} />
              <Route path="/hostels/:id" element={<HostelDetail />} />
              <Route path="/hostels/list" element={<ListHostel />} />
              <Route path="/marketplace" element={<Marketplace />} />
              <Route path="/marketplace/item/:id" element={<ItemDetail />} />
              <Route path="/marketplace/sell" element={<SellItem />} />
              <Route path="/fun-zone" element={<FunZone />} />
              <Route path="/timetable" element={<Timetable />} />
              <Route path="/profile" element={<Profile />} />
              <Route path="/edit-profile" element={<EditProfile />} />
              <Route path="/settings" element={<Settings />} />
              <Route path="/notifications" element={<Notifications />} />
              <Route path="/privacy" element={<Privacy />} />
              {/* ADD ALL CUSTOM ROUTES ABOVE THE CATCH-ALL "*" ROUTE */}
              <Route path="*" element={<NotFound />} />
            </Routes>
          </div>
        </BrowserRouter>
      </TooltipProvider>
    </AuthProvider>
  </QueryClientProvider>
);

export default App;
