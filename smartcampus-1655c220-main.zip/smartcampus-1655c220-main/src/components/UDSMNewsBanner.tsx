import { useState, useEffect } from "react";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Newspaper, ExternalLink, Sparkles, RefreshCw } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { toast } from 'sonner';

interface NewsItem {
  id: string;
  title: string;
  url?: string;
  published_date: string;
  created_at: string;
}

export const UDSMNewsBanner = () => {
  const [news, setNews] = useState<NewsItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);

  const fetchNews = async () => {
    try {
      const { data, error } = await supabase
        .from('udsm_news')
        .select('*')
        .order('created_at', { ascending: false })
        .limit(3);

      if (error) {
        console.error('Error fetching news:', error);
        return;
      }

      setNews(data || []);
    } catch (error) {
      console.error('Error:', error);
    } finally {
      setLoading(false);
    }
  };

  const refreshNews = async () => {
    setRefreshing(true);
    try {
      console.log('Triggering news refresh...');
      const { error } = await supabase.functions.invoke('udsm-news-fetcher');
      
      if (error) {
        console.error('Error refreshing news:', error);
        toast.error('Failed to refresh news');
        return;
      }
      
      // Wait a moment then fetch updated news
      setTimeout(fetchNews, 2000);
      toast.success('Habari mpya zimejazwa! 🇹🇿');
    } catch (error) {
      console.error('Error:', error);
      toast.error('Failed to refresh news');
    } finally {
      setRefreshing(false);
    }
  };

  useEffect(() => {
    fetchNews();
    // Auto-refresh every 30 minutes
    const interval = setInterval(refreshNews, 30 * 60 * 1000);
    return () => clearInterval(interval);
  }, []);

  if (loading) {
    return (
      <Card className="mb-4 bg-gradient-to-r from-green-50/80 to-yellow-50/80 backdrop-blur-sm border border-green-200/50 shadow-lg animate-pulse">
        <div className="p-4">
          <div className="h-6 bg-green-200 rounded mb-2"></div>
          <div className="h-4 bg-green-100 rounded w-3/4"></div>
        </div>
      </Card>
    );
  }

  return (
    <Card className="mb-4 bg-gradient-to-r from-green-50/80 to-yellow-50/80 backdrop-blur-sm border border-green-200/50 shadow-lg hover:shadow-xl transition-all duration-300 animate-fade-in">
      <div className="p-4">
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center gap-2">
            <div className="p-2 bg-gradient-to-r from-green-500 to-yellow-500 rounded-lg animate-pulse">
              <Newspaper className="h-5 w-5 text-white" />
            </div>
            <div>
              <h3 className="font-bold text-green-800 flex items-center gap-1">
                Habari za Chuo leo 🇹🇿
                <Sparkles className="h-4 w-4 text-yellow-500 animate-spin" style={{animationDuration: '3s'}} />
              </h3>
              <p className="text-sm text-green-600">Breaking news kutoka UDSM – angalia hapa kwa updates!</p>
            </div>
          </div>
          <Button
            variant="ghost"
            size="sm"
            onClick={refreshNews}
            disabled={refreshing}
            className="text-green-700 hover:text-green-800 hover:bg-green-100"
          >
            <RefreshCw className={`h-4 w-4 ${refreshing ? 'animate-spin' : ''}`} />
          </Button>
        </div>

        {news.length > 0 ? (
          <div className="space-y-2">
            {news.map((item, index) => (
              <div
                key={item.id}
                className="flex items-start gap-2 p-2 bg-white/60 rounded-lg border border-green-100 hover:bg-white/80 transition-all duration-200 animate-scale-in"
                style={{animationDelay: `${index * 0.1}s`}}
              >
                <Badge className="bg-gradient-to-r from-green-500 to-yellow-500 text-white text-xs px-2 py-0.5 animate-pulse">
                  Mpya
                </Badge>
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium text-green-800 line-clamp-2">
                    {item.title}
                  </p>
                  <p className="text-xs text-green-600 mt-1">
                    {new Date(item.created_at).toLocaleDateString('sw-TZ')}
                  </p>
                </div>
                {item.url && (
                  <Button
                    variant="ghost"
                    size="sm"
                    className="p-1 h-auto text-green-600 hover:text-green-800"
                    onClick={() => window.open(item.url, '_blank')}
                  >
                    <ExternalLink className="h-3 w-3" />
                  </Button>
                )}
              </div>
            ))}
          </div>
        ) : (
          <div className="text-center py-4">
            <p className="text-green-600 text-sm">Hakuna habari mpya kwa sasa...</p>
            <Button
              variant="outline"
              size="sm"
              onClick={refreshNews}
              className="mt-2 border-green-300 text-green-700 hover:bg-green-50"
            >
              Jaribu tena
            </Button>
          </div>
        )}
      </div>
    </Card>
  );
};