
import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { 
  FileText, 
  Image, 
  Video, 
  Music, 
  Archive, 
  File,
  Folder,
  Download,
  Eye
} from "lucide-react";
import FileViewer from "./FileViewer";

interface DriveFile {
  id: string;
  name: string;
  mimeType: string;
  createdTime: string;
  modifiedTime: string;
  size?: string;
  webViewLink: string;
  webContentLink?: string;
  owners?: Array<{
    displayName: string;
    photoLink?: string;
    emailAddress: string;
  }>;
  description?: string;
}

interface DriveFileCardProps {
  file: DriveFile;
  onFolderClick?: (folderId: string) => void;
}

const DriveFileCard = ({ file, onFolderClick }: DriveFileCardProps) => {
  const [isViewerOpen, setIsViewerOpen] = useState(false);

  const getFileIcon = (mimeType: string) => {
    const iconClass = "h-5 w-5"; // Smaller icons for mobile
    
    if (mimeType === 'application/vnd.google-apps.folder') {
      return <Folder className={`${iconClass} text-blue-500`} />;
    }
    
    if (mimeType.startsWith('image/')) {
      return <Image className={`${iconClass} text-green-500`} />;
    }
    
    if (mimeType.startsWith('video/')) {
      return <Video className={`${iconClass} text-red-500`} />;
    }
    
    if (mimeType.startsWith('audio/')) {
      return <Music className={`${iconClass} text-purple-500`} />;
    }
    
    if (mimeType.includes('pdf')) {
      return <FileText className={`${iconClass} text-red-600`} />;
    }
    
    if (mimeType.includes('document') || mimeType.includes('word')) {
      return <FileText className={`${iconClass} text-blue-600`} />;
    }
    
    if (mimeType.includes('spreadsheet') || mimeType.includes('excel')) {
      return <FileText className={`${iconClass} text-green-600`} />;
    }
    
    if (mimeType.includes('presentation') || mimeType.includes('powerpoint')) {
      return <FileText className={`${iconClass} text-orange-600`} />;
    }
    
    if (mimeType.includes('zip') || mimeType.includes('rar') || mimeType.includes('archive')) {
      return <Archive className={`${iconClass} text-yellow-600`} />;
    }
    
    return <File className={`${iconClass} text-gray-500`} />;
  };

  const getFileTypeLabel = (mimeType: string) => {
    if (mimeType === 'application/vnd.google-apps.folder') return 'Folder';
    if (mimeType.includes('pdf')) return 'PDF';
    if (mimeType.includes('document')) return 'Document';
    if (mimeType.includes('spreadsheet')) return 'Spreadsheet';
    if (mimeType.includes('presentation')) return 'Presentation';
    if (mimeType.startsWith('image/')) return 'Image';
    if (mimeType.startsWith('video/')) return 'Video';
    if (mimeType.startsWith('audio/')) return 'Audio';
    return 'File';
  };

  const formatFileSize = (sizeString?: string) => {
    if (!sizeString) return null;
    
    const size = parseInt(sizeString);
    if (size < 1024) return `${size} B`;
    if (size < 1024 * 1024) return `${(size / 1024).toFixed(1)} KB`;
    if (size < 1024 * 1024 * 1024) return `${(size / (1024 * 1024)).toFixed(1)} MB`;
    return `${(size / (1024 * 1024 * 1024)).toFixed(1)} GB`;
  };

  const handleCardClick = () => {
    if (file.mimeType === 'application/vnd.google-apps.folder' && onFolderClick) {
      onFolderClick(file.id);
    } else {
      setIsViewerOpen(true);
    }
  };

  const handleDownload = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (file.webContentLink) {
      window.open(file.webContentLink, '_blank');
    } else {
      // Fallback to view link for download
      window.open(file.webViewLink, '_blank');
    }
  };

  return (
    <>
      <Card 
        className="hover:shadow-md transition-all duration-300 cursor-pointer hover:scale-102 bg-white/90 backdrop-blur-sm border border-gray-200 h-full"
        onClick={handleCardClick}
      >
        <CardHeader className="pb-2 p-3">
          <div className="flex items-start justify-between gap-2">
            <div className="flex-1 min-w-0">
              <CardTitle className="text-sm font-medium text-gray-900 line-clamp-2 break-words leading-tight">
                {file.name}
              </CardTitle>
              <div className="flex items-center space-x-1 mt-1">
                <Badge variant="secondary" className="text-xs px-1 py-0">
                  {getFileTypeLabel(file.mimeType)}
                </Badge>
              </div>
            </div>
            <div className="flex-shrink-0">
              {getFileIcon(file.mimeType)}
            </div>
          </div>
        </CardHeader>

        <CardContent className="pt-0 p-3">
          <div className="flex items-center justify-between">
            <div className="flex flex-col gap-1">
              {file.size && (
                <span className="text-xs text-gray-500">
                  {formatFileSize(file.size)}
                </span>
              )}
            </div>
            
            <div className="flex items-center gap-1">
              {file.mimeType !== 'application/vnd.google-apps.folder' && (
                <Button
                  onClick={handleDownload}
                  variant="outline"
                  size="sm"
                  className="h-7 w-7 p-0"
                >
                  <Download className="h-3 w-3" />
                </Button>
              )}
              <Button
                variant="outline"
                size="sm"
                className="h-7 px-2"
                onClick={(e) => {
                  e.stopPropagation();
                  handleCardClick();
                }}
              >
                {file.mimeType === 'application/vnd.google-apps.folder' ? (
                  <Folder className="h-3 w-3" />
                ) : (
                  <Eye className="h-3 w-3" />
                )}
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      {file.mimeType !== 'application/vnd.google-apps.folder' && (
        <FileViewer
          file={file}
          isOpen={isViewerOpen}
          onClose={() => setIsViewerOpen(false)}
        />
      )}
    </>
  );
};

export default DriveFileCard;
