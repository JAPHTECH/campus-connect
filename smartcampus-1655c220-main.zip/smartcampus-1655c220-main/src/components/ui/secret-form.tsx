import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { toast } from "sonner";

interface SecretFormProps {
  secretName: string;
  onClose: () => void;
}

export function SecretForm({ secretName, onClose }: SecretFormProps) {
  const [value, setValue] = useState("");
  const [isLoading, setIsLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!value.trim()) return;

    setIsLoading(true);
    try {
      // In a real implementation, this would save to Supabase secrets
      console.log(`Secret ${secretName} saved:`, value);
      toast.success(`${secretName} has been saved successfully`);
      onClose();
    } catch (error) {
      console.error("Error saving secret:", error);
      toast.error("Failed to save secret");
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <Dialog open onOpenChange={onClose}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>Configure {secretName}</DialogTitle>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor={secretName}>Enter your {secretName}</Label>
            <Input
              id={secretName}
              type="password"
              value={value}
              onChange={(e) => setValue(e.target.value)}
              placeholder={`Enter ${secretName}...`}
              required
            />
          </div>
          <div className="flex justify-end space-x-2">
            <Button type="button" variant="outline" onClick={onClose}>
              Cancel
            </Button>
            <Button type="submit" disabled={isLoading || !value.trim()}>
              {isLoading ? "Saving..." : "Save"}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}