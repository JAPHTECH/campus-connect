
interface NotificationBadgeProps {
  count: number;
  children: React.ReactNode;
}

export const NotificationBadge = ({ count, children }: NotificationBadgeProps) => {
  return (
    <div className="relative">
      {children}
      {count > 0 && (
        <div className="absolute -top-1 -right-1 bg-red-500 text-white text-xs rounded-full h-4 w-4 flex items-center justify-center animate-pulse">
          {count > 9 ? '9+' : count}
        </div>
      )}
    </div>
  );
};
