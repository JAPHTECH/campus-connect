import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { AlertCircle, RefreshCw, Search, Filter, Cloud, Link, ExternalLink, ArrowLeft } from "lucide-react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import DriveFileCard from "./DriveFileCard";

interface DriveFile {
  id: string;
  name: string;
  mimeType: string;
  createdTime: string;
  modifiedTime: string;
  size?: string;
  webViewLink: string;
  webContentLink?: string;
  owners?: Array<{
    displayName: string;
    photoLink?: string;
    emailAddress: string;
  }>;
  description?: string;
}

const DriveIntegration = () => {
  const [files, setFiles] = useState<DriveFile[]>([]);
  const [filteredFiles, setFilteredFiles] = useState<DriveFile[]>([]);
  const [loading, setLoading] = useState(false);
  const [searchLoading, setSearchLoading] = useState(false);
  const [connected, setConnected] = useState(false);
  const [folderId, setFolderId] = useState("1kCwdnA6PhtTaWITcsn42f01T8nBm1RVp");
  const [currentFolderId, setCurrentFolderId] = useState("1kCwdnA6PhtTaWITcsn42f01T8nBm1RVp");
  const [folderHistory, setFolderHistory] = useState<Array<{id: string, name: string}>>([]);
  const [searchTerm, setSearchTerm] = useState("");
  const [fileTypeFilter, setFileTypeFilter] = useState("");
  const [isSearchMode, setIsSearchMode] = useState(false);

  const fileTypes = [
    { value: "", label: "All Files" },
    { value: "application/pdf", label: "PDF" },
    { value: "application/vnd.google-apps.document", label: "Google Docs" },
    { value: "application/vnd.openxmlformats-officedocument.wordprocessingml.document", label: "Word" },
    { value: "application/vnd.google-apps.spreadsheet", label: "Sheets" },
    { value: "application/vnd.google-apps.presentation", label: "Slides" },
    { value: "image/", label: "Images" },
    { value: "video/", label: "Videos" }
  ];

  useEffect(() => {
    if (currentFolderId) {
      fetchDriveFiles(currentFolderId);
    }
  }, []);

  const fetchDriveFiles = async (targetFolderId?: string) => {
    const folderToFetch = targetFolderId || currentFolderId;
    if (!folderToFetch) {
      toast.error("Please enter a Google Drive folder ID");
      return;
    }

    setLoading(true);
    try {
      console.log('Calling Google Drive function with folder ID:', folderToFetch);
      
      const { data, error } = await supabase.functions.invoke('google-drive', {
        body: { folderId: folderToFetch }
      });

      if (error) {
        console.error('Supabase function error:', error);
        throw error;
      }

      console.log('Google Drive function response:', data);

      if (data.error) {
        throw new Error(data.error);
      }

      const driveFiles = data.files || [];
      setFiles(driveFiles);
      setFilteredFiles(driveFiles);
      setConnected(true);
      setCurrentFolderId(folderToFetch);
      setIsSearchMode(false);
      
      if (driveFiles.length > 0) {
        toast.success(`Successfully loaded ${driveFiles.length} files from Google Drive!`);
      } else {
        toast.info("No files found in the specified folder");
      }
    } catch (error) {
      console.error('Error fetching files:', error);
      toast.error('Failed to fetch files from Google Drive. Please check your folder ID and API configuration.');
      setConnected(false);
    } finally {
      setLoading(false);
    }
  };

  const performSearch = async (query: string) => {
    if (!query.trim()) {
      // If search is empty, go back to folder view
      setIsSearchMode(false);
      setFilteredFiles(files);
      return;
    }

    setSearchLoading(true);
    setIsSearchMode(true);
    
    try {
      console.log('Performing search with query:', query);
      
      const { data, error } = await supabase.functions.invoke('google-drive', {
        body: { 
          searchQuery: query,
          searchInFolder: currentFolderId 
        }
      });

      if (error) {
        console.error('Search error:', error);
        throw error;
      }

      console.log('Search results:', data);

      if (data.error) {
        throw new Error(data.error);
      }

      const searchResults = data.files || [];
      setFilteredFiles(searchResults);
      
      if (searchResults.length > 0) {
        toast.success(`Found ${searchResults.length} files matching "${query}"`);
      } else {
        toast.info(`No files found matching "${query}"`);
      }
    } catch (error) {
      console.error('Search failed:', error);
      toast.error('Search failed. Please try again.');
      // Fall back to local filtering
      const localResults = files.filter(file =>
        file.name.toLowerCase().includes(query.toLowerCase()) ||
        (file.description && file.description.toLowerCase().includes(query.toLowerCase()))
      );
      setFilteredFiles(localResults);
    } finally {
      setSearchLoading(false);
    }
  };

  const handleSearchChange = (value: string) => {
    setSearchTerm(value);
    // Debounce search to avoid too many API calls
    const timeoutId = setTimeout(() => {
      performSearch(value);
    }, 500);

    return () => clearTimeout(timeoutId);
  };

  const clearSearch = () => {
    setSearchTerm("");
    setIsSearchMode(false);
    setFilteredFiles(files);
  };

  const handleFolderClick = (clickedFolderId: string) => {
    // Clear search when navigating to folder
    setSearchTerm("");
    setIsSearchMode(false);
    
    // Find the folder name from current files
    const folderFile = files.find(f => f.id === clickedFolderId);
    const folderName = folderFile?.name || 'Unknown Folder';
    
    // Handle specific folder mappings
    let targetFolderId = clickedFolderId;
    
    // Map specific folder names to their correct IDs
    if (folderName.toLowerCase().includes('first year')) {
      targetFolderId = '1H6gciojVfPiork98XP12NWzpS66hqncb';
    } else if (folderName.toLowerCase().includes('second year')) {
      targetFolderId = '1E5iVgnUT_PyGTIqpwU-viZJVt4PHbQdQ';
    }
    
    // Add current folder to history
    setFolderHistory(prev => [...prev, { id: currentFolderId, name: folderName }]);
    
    // Fetch the new folder contents
    fetchDriveFiles(targetFolderId);
  };

  const handleBackClick = () => {
    if (folderHistory.length > 0) {
      const previousFolder = folderHistory[folderHistory.length - 1];
      setFolderHistory(prev => prev.slice(0, -1));
      setSearchTerm("");
      setIsSearchMode(false);
      fetchDriveFiles(previousFolder.id);
    }
  };

  // Apply file type filter to current results
  useEffect(() => {
    let filtered = isSearchMode ? filteredFiles : files;

    if (fileTypeFilter && filtered.length > 0) {
      filtered = filtered.filter(file =>
        file.mimeType.includes(fileTypeFilter)
      );
      setFilteredFiles(filtered);
    } else if (!isSearchMode) {
      setFilteredFiles(files);
    }
  }, [files, fileTypeFilter, isSearchMode]);

  return (
    <div className="space-y-4">
      {/* Simple Loading Animation */}
      {loading && (
        <div className="flex items-center justify-center py-8">
          <div className="text-center space-y-3">
            <div className="flex justify-center items-center space-x-3">
              <span className="text-2xl text-green-600 animate-pulse">√</span>
              <span className="text-2xl text-red-600 animate-pulse" style={{animationDelay: '0.4s'}}>+</span>
              <span className="text-2xl text-yellow-600 animate-pulse" style={{animationDelay: '0.8s'}}>÷</span>
              <span className="text-2xl text-pink-600 animate-pulse" style={{animationDelay: '1.2s'}}>×</span>
            </div>
            <p className="text-gray-600 animate-fade-in text-sm">Loading files...</p>
          </div>
        </div>
      )}

      {/* Connection Setup - Only show if not connected or no files loaded */}
      {(!connected || files.length === 0) && !loading && (
        <Card className="bg-gradient-to-r from-blue-50 to-purple-50 border-0 shadow-lg max-w-xl mx-auto">
          <CardHeader className="pb-3">
            <CardTitle className="flex items-center space-x-2 text-lg">
              <Cloud className="h-5 w-5 text-blue-600" />
              <span>Mathematics and Statistics Integration</span>
              {connected && <Badge className="bg-green-100 text-green-700 text-xs">Connected</Badge>}
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <div className="flex flex-col sm:flex-row items-center space-y-2 sm:space-y-0 sm:space-x-2">
              <Input
                placeholder="Enter Google Drive folder ID"
                value={folderId}
                onChange={(e) => setFolderId(e.target.value)}
                className="flex-1 text-sm"
              />
              <Button 
                onClick={() => fetchDriveFiles(folderId)} 
                disabled={loading}
                className="bg-blue-600 hover:bg-blue-700 w-full sm:w-auto"
                size="sm"
              >
                {loading ? (
                  <RefreshCw className="h-4 w-4 animate-spin mr-2" />
                ) : (
                  <Cloud className="h-4 w-4 mr-2" />
                )}
                {loading ? 'Loading...' : 'Fetch Files'}
              </Button>
            </div>
            
            <div className="flex items-center space-x-2 text-xs text-blue-700 bg-blue-50 p-2 rounded-lg">
              <AlertCircle className="h-3 w-3" />
              <span>Need help getting a folder ID? Check Google Drive documentation</span>
            </div>
          </CardContent>
        </Card>
      )}

      {folderHistory.length > 0 && !isSearchMode && (
        <Card className="bg-white/80 backdrop-blur-sm max-w-xs">
          <CardContent className="pt-4">
            <div className="flex items-center space-x-2">
              <Button
                onClick={handleBackClick}
                variant="outline"
                size="sm"
                className="flex items-center space-x-1"
              >
                <ArrowLeft className="h-3 w-3" />
                <span className="text-sm">Back</span>
              </Button>
              <span className="text-xs text-gray-600">
                Navigate back to previous folder
              </span>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Search and Filters */}
      {files.length > 0 && (
        <Card className="bg-white/80 backdrop-blur-sm max-w-sm mx-auto">
          <CardContent className="pt-4">
            <div className="flex flex-col gap-3">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
                <Input
                  placeholder="Search files..."
                  value={searchTerm}
                  onChange={(e) => handleSearchChange(e.target.value)}
                  className="pl-10 pr-10 text-sm"
                  disabled={searchLoading}
                />
                {(searchTerm || searchLoading) && (
                  <button
                    onClick={clearSearch}
                    disabled={searchLoading}
                    className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400 hover:text-gray-600"
                  >
                    {searchLoading ? (
                      <RefreshCw className="h-4 w-4 animate-spin" />
                    ) : (
                      <span className="text-lg">×</span>
                    )}
                  </button>
                )}
              </div>
              
              <div className="flex items-center justify-between">
                <div className="text-xs text-gray-600">
                  {filteredFiles.length} file{filteredFiles.length !== 1 ? 's' : ''}
                  {isSearchMode && searchTerm && (
                    <span className="ml-1 text-blue-600">
                      • "{searchTerm}"
                    </span>
                  )}
                </div>
                {isSearchMode && (
                  <Button
                    onClick={clearSearch}
                    variant="outline"
                    size="sm"
                    className="text-xs"
                  >
                    Clear
                  </Button>
                )}
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Files Grid - Optimized for mobile */}
      {filteredFiles.length > 0 ? (
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-3">
          {filteredFiles.map((file, index) => (
            <div 
              key={file.id} 
              className="animate-fade-in" 
              style={{animationDelay: `${index * 0.05}s`}}
            >
              <DriveFileCard file={file} onFolderClick={handleFolderClick} />
            </div>
          ))}
        </div>
      ) : files.length > 0 ? (
        <div className="text-center py-8">
          <Search className="h-12 w-12 text-gray-300 mx-auto mb-3" />
          <h3 className="text-base font-semibold text-gray-600 mb-2">
            {isSearchMode ? 'No search results found' : 'No files match your filters'}
          </h3>
          <p className="text-gray-500 text-sm">
            {isSearchMode 
              ? `Try different search terms or clear the search`
              : 'Try adjusting your filters'
            }
          </p>
        </div>
      ) : null}
    </div>
  );
};

export default DriveIntegration;
