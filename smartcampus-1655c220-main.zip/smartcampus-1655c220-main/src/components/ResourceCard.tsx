
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Download, FileText, Star, User, Calendar, Eye } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { useState } from "react";
import { ResourceDetailModal } from "./ResourceDetailModal";

interface ResourceCardProps {
  resource: {
    id: string;
    title: string;
    description: string | null;
    subject: string | null;
    type: string;
    file_url: string | null;
    file_type: string | null;
    created_at: string;
    downloads: number | null;
    rating: number | null;
    user_id: string;
    course_code: string | null;
    year: number | null;
  };
  uploader?: {
    full_name: string | null;
    avatar_url: string | null;
  };
}

const ResourceCard = ({ resource, uploader }: ResourceCardProps) => {
  const [downloading, setDownloading] = useState(false);
  const [showDetailModal, setShowDetailModal] = useState(false);

  const handleDownload = async () => {
    if (!resource.file_url) return;
    
    setDownloading(true);
    try {
      const { data, error } = await supabase.storage
        .from('resources_files')
        .download(resource.file_url);

      if (error) throw error;

      // Create download link
      const url = URL.createObjectURL(data);
      const a = document.createElement('a');
      a.href = url;
      a.download = resource.title;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);

      // Update download count
      await supabase
        .from('resources')
        .update({ downloads: (resource.downloads || 0) + 1 })
        .eq('id', resource.id);

      toast.success('Download started!');
    } catch (error) {
      console.error('Download error:', error);
      toast.error('Failed to download file');
    } finally {
      setDownloading(false);
    }
  };

  const formatTimeAgo = (date: string) => {
    const now = new Date();
    const past = new Date(date);
    const diffInSeconds = Math.floor((now.getTime() - past.getTime()) / 1000);

    if (diffInSeconds < 60) return 'Just now';
    if (diffInSeconds < 3600) return `${Math.floor(diffInSeconds / 60)}m ago`;
    if (diffInSeconds < 86400) return `${Math.floor(diffInSeconds / 3600)}h ago`;
    if (diffInSeconds < 604800) return `${Math.floor(diffInSeconds / 86400)}d ago`;
    return past.toLocaleDateString();
  };

  return (
    <>
      <Card 
        className="hover:shadow-lg transition-shadow duration-300 cursor-pointer"
        onClick={() => setShowDetailModal(true)}
      >
        <CardHeader className="pb-3">
          <div className="flex items-start justify-between">
            <div className="flex-1">
              <CardTitle className="text-lg font-semibold text-gray-900 line-clamp-2">
                {resource.title}
              </CardTitle>
            <div className="flex items-center space-x-2 mt-2">
              <Badge variant="secondary" className="text-xs">
                {resource.type}
              </Badge>
              {resource.subject && (
                <Badge variant="outline" className="text-xs">
                  {resource.subject}
                </Badge>
              )}
              {resource.course_code && (
                <Badge variant="outline" className="text-xs">
                  {resource.course_code}
                </Badge>
              )}
            </div>
          </div>
          <FileText className="h-8 w-8 text-blue-500" />
        </div>
      </CardHeader>

      <CardContent className="pb-3">
        {resource.description && (
          <p className="text-gray-600 text-sm line-clamp-2 mb-3">
            {resource.description}
          </p>
        )}

        <div className="flex items-center justify-between text-sm text-gray-500">
          <div className="flex items-center space-x-4">
            <div className="flex items-center space-x-1">
              <Download className="h-4 w-4" />
              <span>{resource.downloads || 0}</span>
            </div>
            <div className="flex items-center space-x-1">
              <Star className="h-4 w-4" />
              <span>{resource.rating?.toFixed(1) || 'N/A'}</span>
            </div>
          </div>
          <div className="flex items-center space-x-1">
            <Calendar className="h-4 w-4" />
            <span>{formatTimeAgo(resource.created_at)}</span>
          </div>
        </div>
      </CardContent>

      <CardFooter className="pt-3 border-t">
        <div className="flex items-center justify-between w-full">
          <div className="flex items-center space-x-2">
            <Avatar className="h-6 w-6">
              <AvatarImage src={uploader?.avatar_url || "/placeholder.svg"} />
              <AvatarFallback className="text-xs">
                {uploader?.full_name?.charAt(0) || 'U'}
              </AvatarFallback>
            </Avatar>
            <span className="text-sm text-gray-600">
              {uploader?.full_name || 'Anonymous'}
            </span>
          </div>
          
          <Button
            onClick={(e) => {
              e.stopPropagation();
              setShowDetailModal(true);
            }}
            size="sm"
            className="bg-blue-600 hover:bg-blue-700"
          >
            <Eye className="h-4 w-4 mr-1" />
            View Details
          </Button>
        </div>
      </CardFooter>
    </Card>

    {/* Resource Detail Modal */}
    <ResourceDetailModal
      isOpen={showDetailModal}
      onClose={() => setShowDetailModal(false)}
      resource={resource}
      uploader={uploader}
    />
  </>
  );
};

export default ResourceCard;
