
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { LogOut, X } from "lucide-react";

interface SignOutConfirmDialogProps {
  isOpen: boolean;
  onClose: () => void;
  onConfirm: () => void;
}

export const SignOutConfirmDialog = ({ isOpen, onClose, onConfirm }: SignOutConfirmDialogProps) => {
  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-sm mx-auto bg-white/95 backdrop-blur-sm">
        <DialogHeader>
          <DialogTitle className="flex items-center space-x-2 text-gray-800">
            <LogOut className="h-5 w-5 text-red-500" />
            <span>Sign Out</span>
          </DialogTitle>
          <DialogDescription className="text-gray-600">
            Are you sure you want to sign out of your account?
          </DialogDescription>
        </DialogHeader>
        
        <div className="flex space-x-3 mt-4">
          <Button
            variant="outline"
            onClick={onClose}
            className="flex-1 transition-all duration-300"
          >
            <X className="h-4 w-4 mr-2" />
            Cancel
          </Button>
          <Button
            onClick={onConfirm}
            className="flex-1 bg-red-500 hover:bg-red-600 text-white transition-all duration-300"
          >
            <LogOut className="h-4 w-4 mr-2" />
            Sign Out
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
};
