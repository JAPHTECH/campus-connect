import React, { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Download, FileText, Star, Calendar, BookmarkPlus, BookmarkCheck, Play, Eye } from 'lucide-react';
import { toast } from 'sonner';
import { supabase } from '@/integrations/supabase/client';
import { VideoPlayer } from './VideoPlayer';
import FileViewer from './FileViewer';

interface ResourceDetailModalProps {
  isOpen: boolean;
  onClose: () => void;
  resource: {
    id: string;
    title: string;
    description: string | null;
    subject: string | null;
    type: string;
    file_url: string | null;
    file_type: string | null;
    created_at: string;
    downloads: number | null;
    rating: number | null;
    user_id: string;
    course_code: string | null;
    year: number | null;
  };
  uploader?: {
    full_name: string | null;
    avatar_url: string | null;
  };
}

export const ResourceDetailModal: React.FC<ResourceDetailModalProps> = ({ 
  isOpen, 
  onClose, 
  resource, 
  uploader 
}) => {
  const [downloading, setDownloading] = useState(false);
  const [isSaved, setIsSaved] = useState(false);
  const [showVideoPlayer, setShowVideoPlayer] = useState(false);
  const [showFileViewer, setShowFileViewer] = useState(false);

  const handleDownload = async () => {
    if (!resource.file_url) return;
    
    setDownloading(true);
    try {
      const { data, error } = await supabase.storage
        .from('resources_files')
        .download(resource.file_url);

      if (error) throw error;

      // Create download link
      const url = URL.createObjectURL(data);
      const a = document.createElement('a');
      a.href = url;
      a.download = resource.title;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);

      // Update download count
      await supabase
        .from('resources')
        .update({ downloads: (resource.downloads || 0) + 1 })
        .eq('id', resource.id);

      toast.success('Download started!');
    } catch (error) {
      console.error('Download error:', error);
      toast.error('Failed to download file');
    } finally {
      setDownloading(false);
    }
  };

  const handleSave = async () => {
    try {
      if (isSaved) {
        // Remove from saved (implement unsave logic)
        setIsSaved(false);
        toast.success('Removed from saved resources');
      } else {
        // Add to saved (implement save logic)
        setIsSaved(true);
        toast.success('Resource saved successfully!');
      }
    } catch (error) {
      toast.error('Failed to save resource');
    }
  };

  const handleView = () => {
    if (resource.file_type?.includes('video')) {
      setShowVideoPlayer(true);
    } else {
      setShowFileViewer(true);
    }
  };

  const formatTimeAgo = (date: string) => {
    const now = new Date();
    const past = new Date(date);
    const diffInSeconds = Math.floor((now.getTime() - past.getTime()) / 1000);

    if (diffInSeconds < 60) return 'Just now';
    if (diffInSeconds < 3600) return `${Math.floor(diffInSeconds / 60)}m ago`;
    if (diffInSeconds < 86400) return `${Math.floor(diffInSeconds / 3600)}h ago`;
    if (diffInSeconds < 604800) return `${Math.floor(diffInSeconds / 86400)}d ago`;
    return past.toLocaleDateString();
  };

  const getFileIcon = () => {
    if (resource.file_type?.includes('video')) return Play;
    return FileText;
  };

  const FileIcon = getFileIcon();

  return (
    <>
      <Dialog open={isOpen} onOpenChange={onClose}>
        <DialogContent className="max-w-2xl w-full max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="text-xl font-bold flex items-start space-x-3">
              <FileIcon className="h-6 w-6 text-blue-500 mt-1 flex-shrink-0" />
              <span className="line-clamp-2">{resource.title}</span>
            </DialogTitle>
          </DialogHeader>

          <div className="space-y-6">
            {/* Badges */}
            <div className="flex flex-wrap gap-2">
              <Badge variant="secondary">{resource.type}</Badge>
              {resource.subject && (
                <Badge variant="outline">{resource.subject}</Badge>
              )}
              {resource.course_code && (
                <Badge variant="outline">{resource.course_code}</Badge>
              )}
              {resource.year && (
                <Badge variant="outline">Year {resource.year}</Badge>
              )}
            </div>

            {/* Description */}
            {resource.description && (
              <div>
                <h3 className="font-semibold mb-2">Description</h3>
                <p className="text-gray-600 leading-relaxed">{resource.description}</p>
              </div>
            )}

            {/* Stats */}
            <div className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
              <div className="flex items-center space-x-6">
                <div className="flex items-center space-x-2">
                  <Download className="h-4 w-4 text-gray-500" />
                  <span className="text-sm text-gray-600">{resource.downloads || 0} downloads</span>
                </div>
                <div className="flex items-center space-x-2">
                  <Star className="h-4 w-4 text-gray-500" />
                  <span className="text-sm text-gray-600">{resource.rating?.toFixed(1) || 'No rating'}</span>
                </div>
                <div className="flex items-center space-x-2">
                  <Calendar className="h-4 w-4 text-gray-500" />
                  <span className="text-sm text-gray-600">{formatTimeAgo(resource.created_at)}</span>
                </div>
              </div>
            </div>

            {/* Uploader Info */}
            <div className="flex items-center space-x-3 p-4 bg-blue-50 rounded-lg">
              <Avatar className="h-10 w-10">
                <AvatarImage src={uploader?.avatar_url || "/placeholder.svg"} />
                <AvatarFallback>
                  {uploader?.full_name?.charAt(0) || 'U'}
                </AvatarFallback>
              </Avatar>
              <div>
                <p className="font-medium">{uploader?.full_name || 'Anonymous'}</p>
                <p className="text-sm text-gray-600">Uploader</p>
              </div>
            </div>

            {/* Action Buttons */}
            <div className="flex flex-col sm:flex-row gap-3">
              <Button
                onClick={handleView}
                className="flex-1 bg-blue-600 hover:bg-blue-700"
                disabled={!resource.file_url}
              >
                <Eye className="h-4 w-4 mr-2" />
                View Resource
              </Button>
              
              <Button
                onClick={handleDownload}
                disabled={downloading || !resource.file_url}
                variant="outline"
                className="flex-1"
              >
                <Download className="h-4 w-4 mr-2" />
                {downloading ? 'Downloading...' : 'Download'}
              </Button>
              
              <Button
                onClick={handleSave}
                variant="outline"
                className="flex-1"
              >
                {isSaved ? (
                  <>
                    <BookmarkCheck className="h-4 w-4 mr-2" />
                    Saved
                  </>
                ) : (
                  <>
                    <BookmarkPlus className="h-4 w-4 mr-2" />
                    Save
                  </>
                )}
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Video Player Modal */}
      {showVideoPlayer && resource.file_url && (
        <VideoPlayer
          isOpen={showVideoPlayer}
          onClose={() => setShowVideoPlayer(false)}
          videoUrl={resource.file_url}
          title={resource.title}
        />
      )}

      {/* File Viewer Modal */}
      {showFileViewer && resource.file_url && (
        <FileViewer
          isOpen={showFileViewer}
          onClose={() => setShowFileViewer(false)}
          file={{
            id: resource.id,
            name: resource.title,
            mimeType: resource.file_type || 'application/octet-stream',
            webViewLink: resource.file_url,
            webContentLink: resource.file_url
          }}
        />
      )}
    </>
  );
};