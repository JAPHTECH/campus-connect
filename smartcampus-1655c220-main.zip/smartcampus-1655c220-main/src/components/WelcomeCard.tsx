
import React, { useState, useEffect } from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { X, Heart, Sparkles, Star, TrendingUp } from 'lucide-react';

interface WelcomeCardProps {
  userName: string;
  onDismiss: () => void;
}

export const WelcomeCard: React.FC<WelcomeCardProps> = ({ userName, onDismiss }) => {
  const [currentMessageIndex, setCurrentMessageIndex] = useState(0);
  const [isVisible, setIsVisible] = useState(true);

  const welcomeMessages = [
    {
      title: "Karibu sana, " + userName + "! 🎉",
      message: "Umefika kwenye familia yetu ya UDSM! We ni sharp sana! ✨",
      subtitle: "Ready ku-explore vitu vyote? Tutakuonyesha kila kitu!"
    },
    {
      title: "Poa kichizi! " + userName + " 🔥",
      message: "Sasa we ni member wa UDSM Hub officially! Mambo ni fresh! 💫",
      subtitle: "Time ya kusoma, ku-network na ku-enjoy - everything is here!"
    },
    {
      title: "Niaje " + userName + "! 🚀",
      message: "Welcome kwenye digital campus yetu! Vitu ni za maana hapa! ⚡",
      subtitle: "Academic excellence meets modern vibes - you'll love it here!"
    }
  ];

  // Rotate messages every 4 seconds
  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentMessageIndex((prev) => (prev + 1) % welcomeMessages.length);
    }, 4000);
    return () => clearInterval(interval);
  }, []);

  const handleDismiss = () => {
    setIsVisible(false);
    setTimeout(() => {
      onDismiss();
    }, 300);
  };

  if (!isVisible) {
    return null;
  }

  return (
    <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4 animate-fade-in">
      {/* Animated background elements */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-20 left-20 w-16 h-16 bg-blue-400/30 rounded-full animate-pulse"></div>
        <div className="absolute top-40 right-16 w-12 h-12 bg-purple-400/30 rounded-full animate-bounce" style={{animationDelay: '1s'}}></div>
        <div className="absolute bottom-32 left-1/3 w-8 h-8 bg-green-400/30 rounded-full animate-ping" style={{animationDelay: '2s'}}></div>
        <Sparkles className="absolute top-1/3 right-1/4 w-6 h-6 text-yellow-300 opacity-40 animate-spin" style={{animationDuration: '3s'}} />
        <Star className="absolute bottom-1/4 left-1/4 w-5 h-5 text-blue-300 opacity-30 animate-pulse" />
        <TrendingUp className="absolute top-1/4 left-1/3 w-5 h-5 text-green-300 opacity-30 animate-bounce" style={{animationDelay: '1.5s'}} />
      </div>

      <Card className="w-full max-w-md bg-gradient-to-br from-white/95 to-blue-50/95 backdrop-blur-xl border-white/20 shadow-2xl animate-scale-in hover:shadow-3xl transition-all duration-500 relative overflow-hidden">
        {/* Close button */}
        <Button 
          variant="ghost" 
          size="sm" 
          onClick={handleDismiss}
          className="absolute top-3 right-3 z-10 hover:bg-white/20 text-gray-600 hover:text-gray-800 transition-all duration-200 hover:scale-110"
        >
          <X className="h-4 w-4" />
        </Button>

        {/* Animated gradient overlay */}
        <div className="absolute inset-0 bg-gradient-to-r from-blue-400/10 via-purple-400/10 to-pink-400/10 animate-pulse"></div>

        <CardContent className="p-6 text-center relative z-10">
          {/* Welcome emoji with animation */}
          <div className="text-6xl mb-4 animate-bounce">
            🎊
          </div>

          {/* Dynamic welcome messages */}
          <div className="mb-6 min-h-[120px] flex flex-col justify-center">
            <h2 className="text-2xl font-bold text-gray-800 mb-3 transition-all duration-700 ease-in-out animate-fade-in">
              <span key={currentMessageIndex} className="inline-block transition-all duration-500 transform animate-scale-in">
                {welcomeMessages[currentMessageIndex].title}
              </span>
            </h2>
            <p className="text-gray-700 mb-2 transition-all duration-700 ease-in-out animate-fade-in" style={{animationDelay: '0.2s'}}>
              <span key={currentMessageIndex} className="inline-block transition-all duration-500 transform">
                {welcomeMessages[currentMessageIndex].message}
              </span>
            </p>
            <p className="text-sm text-gray-600 transition-all duration-700 ease-in-out animate-fade-in" style={{animationDelay: '0.4s'}}>
              <span key={currentMessageIndex} className="inline-block transition-all duration-500 transform">
                {welcomeMessages[currentMessageIndex].subtitle}
              </span>
            </p>
          </div>

          {/* Action button */}
          <Button 
            onClick={handleDismiss}
            className="w-full bg-gradient-to-r from-blue-500 to-purple-500 hover:from-blue-600 hover:to-purple-600 text-white shadow-lg hover:shadow-xl transition-all duration-300 hover:scale-105 h-12 font-semibold animate-fade-in transform mb-4"
            style={{animationDelay: '0.6s'}}
          >
            Sawa! Let's explore! 🚀
          </Button>

          {/* Built with love tag */}
          <div className="bg-white/60 backdrop-blur-sm rounded-lg p-3 border border-white/20 animate-scale-in hover:bg-white/70 transition-all duration-300" style={{animationDelay: '0.8s'}}>
            <div className="flex items-center justify-center space-x-2">
              <Heart className="h-4 w-4 text-red-500 animate-pulse" />
              <span className="text-gray-600 text-sm">
                Built with love by <span className="text-blue-600 font-semibold">Japhet Jr</span>
              </span>
              <Sparkles className="h-4 w-4 text-yellow-500 animate-pulse" style={{animationDelay: '0.5s'}} />
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};
