
import { useState, useRef, useCallback } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Slider } from '@/components/ui/slider';
import { RotateCcw, Check, X } from 'lucide-react';

interface ProfileImageCropProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (croppedImage: string) => void;
  imageUrl: string;
}

export const ProfileImageCrop = ({ isOpen, onClose, onSave, imageUrl }: ProfileImageCropProps) => {
  const [scale, setScale] = useState([1]);
  const [position, setPosition] = useState({ x: 0, y: 0 });
  const [isDragging, setIsDragging] = useState(false);
  const [dragStart, setDragStart] = useState({ x: 0, y: 0 });
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const imageRef = useRef<HTMLImageElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);

  const handleMouseDown = useCallback((e: React.MouseEvent) => {
    setIsDragging(true);
    setDragStart({ x: e.clientX - position.x, y: e.clientY - position.y });
  }, [position]);

  const handleMouseMove = useCallback((e: React.MouseEvent) => {
    if (!isDragging) return;
    
    const newX = e.clientX - dragStart.x;
    const newY = e.clientY - dragStart.y;
    
    // Limit movement within bounds
    const container = containerRef.current;
    if (container) {
      const maxX = 50;
      const maxY = 50;
      setPosition({
        x: Math.max(-maxX, Math.min(maxX, newX)),
        y: Math.max(-maxY, Math.min(maxY, newY))
      });
    }
  }, [isDragging, dragStart]);

  const handleMouseUp = useCallback(() => {
    setIsDragging(false);
  }, []);

  const resetPosition = () => {
    setPosition({ x: 0, y: 0 });
    setScale([1]);
  };

  const handleSave = async () => {
    const canvas = canvasRef.current;
    const image = imageRef.current;
    const container = containerRef.current;
    
    if (!canvas || !image || !container) return;
    
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    
    // Wait for image to load completely
    if (!image.complete) {
      image.onload = () => handleSave();
      return;
    }
    
    // Set canvas size to 200x200 for profile pictures
    const outputSize = 200;
    canvas.width = outputSize;
    canvas.height = outputSize;
    
    // Container dimensions (crop area)
    const containerSize = 192; // 48 * 4 (w-48 h-48 in the crop overlay)
    const cropRadius = containerSize / 2;
    
    // Calculate the actual image dimensions and scaling
    const imageRect = image.getBoundingClientRect();
    const containerRect = container.getBoundingClientRect();
    
    // Calculate the center of the crop area
    const centerX = containerSize / 2;
    const centerY = containerSize / 2;
    
    // Apply the current transformations
    const scaledImageSize = containerSize * scale[0];
    const imageX = centerX - scaledImageSize / 2 + position.x;
    const imageY = centerY - scaledImageSize / 2 + position.y;
    
    // Create circular clipping path
    ctx.beginPath();
    ctx.arc(outputSize / 2, outputSize / 2, outputSize / 2, 0, 2 * Math.PI);
    ctx.clip();
    
    // Clear the canvas with white background
    ctx.fillStyle = '#ffffff';
    ctx.fillRect(0, 0, outputSize, outputSize);
    
    // Calculate scaling factor from crop area to output size
    const scale_factor = outputSize / containerSize;
    
    // Draw the image with proper scaling and positioning
    ctx.drawImage(
      image,
      imageX * scale_factor,
      imageY * scale_factor,
      scaledImageSize * scale_factor,
      scaledImageSize * scale_factor
    );
    
    // Convert to base64 with high quality
    const croppedImage = canvas.toDataURL('image/jpeg', 0.95);
    onSave(croppedImage);
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-md mx-auto">
        <DialogHeader>
          <DialogTitle>Crop Profile Picture</DialogTitle>
        </DialogHeader>
        
        <div className="space-y-4">
          {/* Crop Area */}
          <div 
            ref={containerRef}
            className="relative w-64 h-64 mx-auto bg-gray-100 rounded-lg overflow-hidden border-2 border-dashed border-gray-300"
            onMouseMove={handleMouseMove}
            onMouseUp={handleMouseUp}
            onMouseLeave={handleMouseUp}
          >
            <div
              className="absolute inset-0 cursor-move"
              style={{
                transform: `translate(${position.x}px, ${position.y}px) scale(${scale[0]})`,
                transformOrigin: 'center'
              }}
              onMouseDown={handleMouseDown}
            >
              <img
                ref={imageRef}
                src={imageUrl}
                alt="Crop preview"
                className="w-full h-full object-cover"
                draggable={false}
              />
            </div>
            
            {/* Crop overlay */}
            <div className="absolute inset-0 pointer-events-none">
              <div className="absolute inset-0 bg-black bg-opacity-50"></div>
              <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-48 h-48 border-2 border-white rounded-full bg-transparent"></div>
            </div>
          </div>
          
          {/* Controls */}
          <div className="space-y-3">
            <div>
              <label className="text-sm font-medium text-gray-700 mb-2 block">
                Zoom: {scale[0].toFixed(1)}x
              </label>
              <Slider
                value={scale}
                onValueChange={setScale}
                min={0.5}
                max={3}
                step={0.1}
                className="w-full"
              />
            </div>
            
            <Button
              variant="outline"
              onClick={resetPosition}
              className="w-full"
            >
              <RotateCcw className="h-4 w-4 mr-2" />
              Reset Position
            </Button>
          </div>
          
          {/* Action Buttons */}
          <div className="flex space-x-2">
            <Button
              variant="outline"
              onClick={onClose}
              className="flex-1"
            >
              <X className="h-4 w-4 mr-2" />
              Cancel
            </Button>
            <Button
              onClick={handleSave}
              className="flex-1 bg-gradient-to-r from-blue-500 to-purple-500 hover:from-blue-600 hover:to-purple-600"
            >
              <Check className="h-4 w-4 mr-2" />
              Save
            </Button>
          </div>
        </div>
        
        {/* Hidden canvas for cropping */}
        <canvas ref={canvasRef} className="hidden" />
      </DialogContent>
    </Dialog>
  );
};
