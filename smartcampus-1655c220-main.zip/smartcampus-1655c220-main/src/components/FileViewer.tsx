
import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { X, ExternalLink, Download } from "lucide-react";
import { toast } from "sonner";

interface FileViewerProps {
  file: {
    id: string;
    name: string;
    mimeType: string;
    webViewLink: string;
    webContentLink?: string;
  };
  isOpen: boolean;
  onClose: () => void;
}

const FileViewer = ({ file, isOpen, onClose }: FileViewerProps) => {
  const [loading, setLoading] = useState(true);
  const [downloading, setDownloading] = useState(false);

  const getEmbedUrl = (webViewLink: string, mimeType: string) => {
    const fileId = webViewLink.split('/')[5];
    
    // For Google Docs, Sheets, and Slides, use the embed URL
    if (mimeType.includes('document') || mimeType.includes('spreadsheet') || mimeType.includes('presentation')) {
      return `https://docs.google.com/document/d/${fileId}/edit?usp=sharing&embedded=true`;
    }
    
    // For PDFs and other files, use the preview URL
    return `https://drive.google.com/file/d/${fileId}/preview`;
  };

  const canPreview = (mimeType: string) => {
    return (
      mimeType.includes('pdf') ||
      mimeType.includes('image') ||
      mimeType.includes('document') ||
      mimeType.includes('spreadsheet') ||
      mimeType.includes('presentation') ||
      mimeType.includes('text')
    );
  };

  const handleDownload = async () => {
    setDownloading(true);
    try {
      if (file.webContentLink) {
        // Direct download link available
        const link = document.createElement('a');
        link.href = file.webContentLink;
        link.download = file.name;
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
        toast.success('Download started!');
      } else {
        // Fallback to opening in new tab
        window.open(file.webViewLink, '_blank');
        toast.info('File opened in new tab for download');
      }
    } catch (error) {
      console.error('Download failed:', error);
      toast.error('Download failed. Please try again.');
    } finally {
      setDownloading(false);
    }
  };

  const renderFileContent = () => {
    if (!canPreview(file.mimeType)) {
      return (
        <div className="flex flex-col items-center justify-center h-64 sm:h-96 bg-gray-50 rounded-lg">
          <div className="text-4xl sm:text-6xl mb-4">📄</div>
          <h3 className="text-base sm:text-lg font-semibold mb-2">Preview not available</h3>
          <p className="text-gray-600 mb-4 text-center text-sm">
            This file type cannot be previewed in the browser
          </p>
          <div className="flex gap-2">
            <Button
              onClick={() => window.open(file.webViewLink, '_blank')}
              variant="outline"
              size="sm"
            >
              <ExternalLink className="h-4 w-4 mr-2" />
              Open in Drive
            </Button>
            <Button
              onClick={handleDownload}
              disabled={downloading}
              size="sm"
            >
              <Download className="h-4 w-4 mr-2" />
              {downloading ? 'Downloading...' : 'Download'}
            </Button>
          </div>
        </div>
      );
    }

    return (
      <div className="relative">
        {loading && (
          <div className="absolute inset-0 flex items-center justify-center bg-gray-50 rounded-lg">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
          </div>
        )}
        <iframe
          src={getEmbedUrl(file.webViewLink, file.mimeType)}
          className="w-full h-64 sm:h-96 border-0 rounded-lg"
          onLoad={() => setLoading(false)}
          title={file.name}
        />
      </div>
    );
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-hidden">
        <DialogHeader className="flex flex-row items-center justify-between">
          <DialogTitle className="text-base sm:text-lg font-semibold truncate pr-4">
            {file.name}
          </DialogTitle>
          <div className="flex items-center gap-2">
            <Button
              onClick={handleDownload}
              disabled={downloading}
              variant="outline"
              size="sm"
            >
              <Download className="h-4 w-4 mr-1" />
              {downloading ? 'Downloading...' : 'Download'}
            </Button>
            <Button
              onClick={() => window.open(file.webViewLink, '_blank')}
              variant="outline"
              size="sm"
            >
              <ExternalLink className="h-4 w-4 mr-1" />
              Open in Drive
            </Button>
            <Button
              onClick={onClose}
              variant="ghost"
              size="sm"
              className="h-8 w-8 p-0"
            >
              <X className="h-4 w-4" />
            </Button>
          </div>
        </DialogHeader>
        <div className="mt-4">
          {renderFileContent()}
        </div>
      </DialogContent>
    </Dialog>
  );
};

export default FileViewer;
