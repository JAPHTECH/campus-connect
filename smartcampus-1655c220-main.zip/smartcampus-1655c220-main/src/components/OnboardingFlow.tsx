
import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { ArrowRight, ArrowLeft, Star, Bell, User, CheckCircle } from "lucide-react";

interface OnboardingFlowProps {
  onComplete: () => void;
}

export const OnboardingFlow = ({ onComplete }: OnboardingFlowProps) => {
  const [currentStep, setCurrentStep] = useState(0);

  const steps = [
    {
      title: "Welcome to UDSM Hub!",
      description: "Your digital campus companion for academic excellence",
      icon: CheckCircle,
      content: "This platform connects UDSM students with study materials, hostels, marketplace, and more!"
    },
    {
      title: "Daily Study Tips",
      description: "Get personalized tips for academic success",
      icon: Star,
      content: "Check the 'Tip ya Leo' section daily for UDSM-specific study advice and campus updates!"
    },
    {
      title: "Your Profile",
      description: "Manage your account and preferences",
      icon: User,
      content: "Complete your profile to connect with other students and access personalized features."
    },
    {
      title: "Stay Notified",
      description: "Never miss important updates",
      icon: Bell,
      content: "Enable notifications to get alerts about new study materials, messages, and campus news."
    }
  ];

  const nextStep = () => {
    if (currentStep < steps.length - 1) {
      setCurrentStep(currentStep + 1);
    } else {
      onComplete();
      localStorage.setItem('onboarding_completed', 'true');
    }
  };

  const prevStep = () => {
    if (currentStep > 0) {
      setCurrentStep(currentStep - 1);
    }
  };

  const skipOnboarding = () => {
    onComplete();
    localStorage.setItem('onboarding_completed', 'true');
  };

  const step = steps[currentStep];

  return (
    <Dialog open={true} onOpenChange={onComplete}>
      <DialogContent className="max-w-md mx-auto bg-white/95 backdrop-blur-sm">
        <DialogHeader>
          <DialogTitle className="text-center text-2xl font-bold text-gray-800">
            Getting Started
          </DialogTitle>
        </DialogHeader>
        
        <div className="space-y-6">
          {/* Progress indicator */}
          <div className="flex justify-center space-x-2">
            {steps.map((_, index) => (
              <div
                key={index}
                className={`w-2 h-2 rounded-full transition-all duration-300 ${
                  index <= currentStep ? 'bg-blue-500' : 'bg-gray-300'
                }`}
              />
            ))}
          </div>

          {/* Step content */}
          <Card className="border-0 shadow-lg bg-gradient-to-br from-blue-50 to-purple-50">
            <CardContent className="p-6 text-center">
              <div className="bg-gradient-to-r from-blue-500 to-purple-500 text-white p-3 rounded-full w-fit mx-auto mb-4">
                <step.icon className="h-6 w-6" />
              </div>
              <h3 className="text-xl font-bold text-gray-800 mb-2">{step.title}</h3>
              <p className="text-sm text-gray-600 mb-4">{step.description}</p>
              <p className="text-gray-700">{step.content}</p>
            </CardContent>
          </Card>

          {/* Navigation buttons */}
          <div className="flex justify-between items-center">
            <Button
              variant="ghost"
              onClick={prevStep}
              disabled={currentStep === 0}
              className="transition-all duration-300"
            >
              <ArrowLeft className="h-4 w-4 mr-2" />
              Back
            </Button>

            <Button
              variant="ghost"
              onClick={skipOnboarding}
              className="text-gray-500 hover:text-gray-700 transition-colors duration-300"
            >
              Skip
            </Button>

            <Button
              onClick={nextStep}
              className="bg-gradient-to-r from-blue-500 to-purple-500 hover:from-blue-600 hover:to-purple-600 transition-all duration-300"
            >
              {currentStep === steps.length - 1 ? 'Get Started' : 'Next'}
              <ArrowRight className="h-4 w-4 ml-2" />
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
};
