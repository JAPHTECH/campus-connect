
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Search, Filter, X } from "lucide-react";
import { useState } from "react";

interface ResourceFiltersProps {
  onFiltersChange: (filters: {
    search: string;
    type: string;
    subject: string;
    year: string;
  }) => void;
  totalResults: number;
}

const ResourceFilters = ({ onFiltersChange, totalResults }: ResourceFiltersProps) => {
  const [search, setSearch] = useState("");
  const [type, setType] = useState("");
  const [subject, setSubject] = useState("");
  const [year, setYear] = useState("");
  const [showFilters, setShowFilters] = useState(false);

  const resourceTypes = ["Notes", "Past Paper", "Lab Manual", "Assignment", "Project", "Presentation", "Other"];
  const subjects = ["Mathematics", "Physics", "Chemistry", "Biology", "Computer Science", "Engineering", "Business", "Economics", "Literature", "History", "Other"];
  const years = ["2024", "2023", "2022", "2021", "2020", "2019"];

  const handleSearchChange = (value: string) => {
    setSearch(value);
    onFiltersChange({ search: value, type, subject, year });
  };

  const handleFilterChange = (filterType: string, value: string) => {
    const newFilters = { search, type, subject, year };
    
    switch (filterType) {
      case 'type':
        setType(value);
        newFilters.type = value;
        break;
      case 'subject':
        setSubject(value);
        newFilters.subject = value;
        break;
      case 'year':
        setYear(value);
        newFilters.year = value;
        break;
    }
    
    onFiltersChange(newFilters);
  };

  const clearAllFilters = () => {
    setSearch("");
    setType("");
    setSubject("");
    setYear("");
    onFiltersChange({ search: "", type: "", subject: "", year: "" });
  };

  const hasActiveFilters = search || type || subject || year;

  return (
    <div className="space-y-4">
      {/* Search Bar */}
      <div className="relative">
        <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
        <Input
          placeholder="Search resources by title, description, or uploader..."
          value={search}
          onChange={(e) => handleSearchChange(e.target.value)}
          className="pl-10 pr-10"
        />
        {search && (
          <button
            onClick={() => handleSearchChange("")}
            className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400 hover:text-gray-600"
          >
            <X className="h-4 w-4" />
          </button>
        )}
      </div>

      {/* Filter Toggle */}
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-2">
          <Button
            variant="outline"
            size="sm"
            onClick={() => setShowFilters(!showFilters)}
            className="flex items-center space-x-2"
          >
            <Filter className="h-4 w-4" />
            <span>Filters</span>
          </Button>
          
          {hasActiveFilters && (
            <Button
              variant="ghost"
              size="sm"
              onClick={clearAllFilters}
              className="text-red-600 hover:text-red-700"
            >
              Clear All
            </Button>
          )}
        </div>
        
        <p className="text-sm text-gray-600">
          {totalResults} resource{totalResults !== 1 ? 's' : ''} found
        </p>
      </div>

      {/* Filter Options */}
      {showFilters && (
        <Card>
          <CardContent className="pt-6">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Resource Type
                </label>
                <select
                  value={type}
                  onChange={(e) => handleFilterChange('type', e.target.value)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                >
                  <option value="">All Types</option>
                  {resourceTypes.map(resourceType => (
                    <option key={resourceType} value={resourceType}>
                      {resourceType}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Subject
                </label>
                <select
                  value={subject}
                  onChange={(e) => handleFilterChange('subject', e.target.value)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                >
                  <option value="">All Subjects</option>
                  {subjects.map(subjectOption => (
                    <option key={subjectOption} value={subjectOption}>
                      {subjectOption}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Academic Year
                </label>
                <select
                  value={year}
                  onChange={(e) => handleFilterChange('year', e.target.value)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                >
                  <option value="">All Years</option>
                  {years.map(yearOption => (
                    <option key={yearOption} value={yearOption}>
                      {yearOption}
                    </option>
                  ))}
                </select>
              </div>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
};

export default ResourceFilters;
