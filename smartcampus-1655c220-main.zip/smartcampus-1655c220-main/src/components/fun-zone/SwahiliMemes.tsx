import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Laugh, RefreshCw, Share, Heart, MessageCircle } from "lucide-react";
import { toast } from "sonner";

interface Meme {
  id: string;
  title: string;
  imageUrl: string;
  caption: string;
  category: string;
  likes: number;
  comments: number;
  trending: boolean;
}

const swahiliMemes: Meme[] = [
  {
    id: "meme-1",
    title: "Exam Period Vibes",
    imageUrl: "/placeholder.svg",
    caption: "Wakati wa mitihani: 'Nimesoma sana leo' vs Reality: 'Nimelala sana leo' 😂",
    category: "Student Life",
    likes: 245,
    comments: 89,
    trending: true
  },
  {
    id: "meme-2", 
    title: "Campus WiFi Struggle",
    imageUrl: "/placeholder.svg",
    caption: "WiFi ya campus: 'Connecting...' since 2019 🤣 But we still have hope!",
    category: "Campus",
    likes: 189,
    comments: 67,
    trending: false
  },
  {
    id: "meme-3",
    title: "Hostel Food Chronicles",
    imageUrl: "/placeholder.svg",
    caption: "Chakula cha hostel: 'Hii ni nini?' 'Ni chakula' 'Lakini ni nini?' 'Ni chakula' 🍽️",
    category: "Hostel Life",
    likes: 312,
    comments: 156,
    trending: true
  },
  {
    id: "meme-4",
    title: "Lecturer vs Student",
    imageUrl: "/placeholder.svg", 
    caption: "Lecturer: 'Kuna maswali?' Students: *silence* Later in group chat: 'Sikuelewa kitu' 😅",
    category: "Lectures",
    likes: 567,
    comments: 234,
    trending: true
  },
  {
    id: "meme-5",
    title: "HELB Money Hits",
    imageUrl: "/placeholder.svg",
    caption: "HELB ikifika: 'I'm rich!' After 3 days: 'Nimalizwa na pesa' 💸",
    category: "Student Finance",
    likes: 445,
    comments: 178,
    trending: false
  },
  {
    id: "meme-6",
    title: "Group Assignment Drama",
    imageUrl: "/placeholder.svg",
    caption: "Group assignment: 5 watu, mmoja anafanya kazi, wengine ni 'moral support' 🎭",
    category: "Teamwork",
    likes: 289,
    comments: 92,
    trending: false
  }
];

export const SwahiliMemes = () => {
  const [currentMemes, setCurrentMemes] = useState<Meme[]>([]);
  const [likedMemes, setLikedMemes] = useState<string[]>([]);

  useEffect(() => {
    // Shuffle and show random memes
    const shuffled = [...swahiliMemes].sort(() => Math.random() - 0.5);
    setCurrentMemes(shuffled.slice(0, 4));
  }, []);

  const handleLike = (memeId: string) => {
    if (likedMemes.includes(memeId)) {
      setLikedMemes(prev => prev.filter(id => id !== memeId));
      toast.info("Like imeondolewa! But why though? 😢");
    } else {
      setLikedMemes(prev => [...prev, memeId]);
      toast.success("Haha! Nice taste in memes, jamani! 😂");
    }
  };

  const handleShare = (meme: Meme) => {
    if (navigator.share) {
      navigator.share({
        title: meme.title,
        text: meme.caption,
        url: window.location.href
      });
    } else {
      navigator.clipboard.writeText(`${meme.title}: ${meme.caption}`);
      toast.success("Meme imekopiwa! Share na marafiki wako! 📋");
    }
  };

  const refreshMemes = () => {
    const shuffled = [...swahiliMemes].sort(() => Math.random() - 0.5);
    setCurrentMemes(shuffled.slice(0, 4));
    toast.success("Fresh memes loaded! Ready for more laughs! 🔄");
  };

  return (
    <Card className="bg-gradient-to-br from-yellow-50 to-orange-50 border-0 shadow-xl">
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle className="flex items-center space-x-2 text-lg">
            <Laugh className="h-6 w-6 text-orange-600" />
            <span>Swahili Memes Collection 😂</span>
          </CardTitle>
          <Button
            size="sm"
            variant="outline"
            onClick={refreshMemes}
            className="hover:bg-orange-50"
          >
            <RefreshCw className="h-4 w-4 mr-1" />
            Refresh
          </Button>
        </div>
      </CardHeader>
      <CardContent>
        <div className="grid gap-4">
          {currentMemes.map((meme, index) => (
            <div 
              key={meme.id}
              className="bg-white/80 backdrop-blur-sm rounded-lg p-4 border border-white/50 hover:shadow-md transition-all duration-300 animate-fade-in"
              style={{ animationDelay: `${index * 0.1}s` }}
            >
              <div className="flex items-start justify-between mb-3">
                <div className="flex-1">
                  <div className="flex items-center space-x-2 mb-2">
                    <h3 className="font-semibold text-gray-800 text-sm">{meme.title}</h3>
                    {meme.trending && (
                      <Badge className="bg-red-100 text-red-800 text-xs px-2 py-1">
                        🔥 Trending
                      </Badge>
                    )}
                  </div>
                  <p className="text-sm text-gray-700 leading-relaxed mb-3">{meme.caption}</p>
                  <Badge variant="outline" className="text-xs">
                    {meme.category}
                  </Badge>
                </div>
              </div>
              
              <div className="flex items-center justify-between pt-3 border-t border-gray-200">
                <div className="flex items-center space-x-4 text-xs text-gray-600">
                  <span className="flex items-center space-x-1">
                    <Heart className="h-3 w-3" />
                    <span>{meme.likes}</span>
                  </span>
                  <span className="flex items-center space-x-1">
                    <MessageCircle className="h-3 w-3" />
                    <span>{meme.comments}</span>
                  </span>
                </div>
                
                <div className="flex items-center space-x-2">
                  <Button
                    size="sm"
                    variant={likedMemes.includes(meme.id) ? "default" : "outline"}
                    onClick={() => handleLike(meme.id)}
                    className={`text-xs ${
                      likedMemes.includes(meme.id)
                        ? "bg-red-500 hover:bg-red-600 text-white"
                        : "hover:bg-red-50"
                    }`}
                  >
                    <Heart className={`h-3 w-3 mr-1 ${likedMemes.includes(meme.id) ? 'fill-current' : ''}`} />
                    Like
                  </Button>
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={() => handleShare(meme)}
                    className="text-xs hover:bg-blue-50"
                  >
                    <Share className="h-3 w-3 mr-1" />
                    Share
                  </Button>
                </div>
              </div>
            </div>
          ))}
        </div>
        
        <div className="mt-4 text-center">
          <p className="text-xs text-gray-600">
            Memes zingine zinakuja! Keep checking for daily dose of laughter! 🤣
          </p>
        </div>
      </CardContent>
    </Card>
  );
};