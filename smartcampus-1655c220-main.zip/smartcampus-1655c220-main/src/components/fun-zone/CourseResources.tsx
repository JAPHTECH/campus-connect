import { useState, useCallback } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { BookOpen, Video, FileText, Download, ExternalLink, Search, Globe, Sparkles, Play } from "lucide-react";
import { VideoPlayer } from "../VideoPlayer";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { toast } from "sonner";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";

interface Resource {
  id: string;
  title: string;
  type: 'video' | 'book' | 'notes' | 'paper';
  description: string;
  url: string;
  provider: string;
}

interface Course {
  code: string;
  name: string;
  semester: string;
  resources: Resource[];
}

const coursesData: Course[] = [
  {
    code: "MT 357",
    name: "Abstract Algebra",
    semester: "First Semester",
    resources: [
      {
        id: "mt357-1",
        title: "Abstract Algebra by David S. Dummit",
        type: "book",
        description: "Comprehensive textbook on abstract algebra covering groups, rings, and fields.",
        url: "https://www.math.colostate.edu/~renzo/teaching/Algebra10/book.pdf",
        provider: "Colorado State University"
      },
      {
        id: "mt357-2", 
        title: "Group Theory - Visual Group Theory",
        type: "video",
        description: "Complete course on group theory with visual explanations.",
        url: "https://www.youtube.com/watch?v=g7L_r6zw4-c&list=PLwV-9DG53NDxU337smpTwm6sef4x-SCLv",
        provider: "YouTube - MathTheBeautiful"
      },
      {
        id: "mt357-3",
        title: "Abstract Algebra Lecture Notes",
        type: "notes",
        description: "Detailed lecture notes on abstract algebra from Harvard University.",
        url: "https://people.math.harvard.edu/~elkies/M55a.10/index.html",
        provider: "Harvard University"
      },
      {
        id: "mt357-4",
        title: "Past Papers Collection",
        type: "paper",
        description: "Collection of past examination papers for abstract algebra.",
        url: "https://www.docdroid.net/jZMGqrr/abstract-algebra-past-papers-pdf",
        provider: "University Archives"
      }
    ]
  },
  {
    code: "ST 310",
    name: "Statistical Inference II",
    semester: "First Semester",
    resources: [
      {
        id: "st310-1",
        title: "Statistical Inference by Casella & Berger",
        type: "book",
        description: "Classic textbook on statistical inference and hypothesis testing.",
        url: "https://fsalamri.files.wordpress.com/2015/02/casella_berger_statistical_inference1.pdf",
        provider: "Academic Publishing"
      },
      {
        id: "st310-2",
        title: "Hypothesis Testing Course",
        type: "video",
        description: "Complete course on statistical inference and hypothesis testing.",
        url: "https://www.youtube.com/watch?v=0oc49DyA3hU&list=PLvxOuBpazmsOti3g2x0j_Hxsg_HkP_R0f",
        provider: "YouTube - StatQuest"
      },
      {
        id: "st310-3",
        title: "MIT Statistical Inference Notes",
        type: "notes",
        description: "Comprehensive notes on statistical inference from MIT.",
        url: "https://ocw.mit.edu/courses/mathematics/18-05-introduction-to-probability-and-statistics-spring-2014/readings/",
        provider: "MIT OpenCourseWare"
      }
    ]
  },
  {
    code: "MT 340",
    name: "Real Analysis",
    semester: "First Semester", 
    resources: [
      {
        id: "mt340-1",
        title: "Real Analysis by Walter Rudin",
        type: "book",
        description: "Principles of Mathematical Analysis - the classic real analysis textbook.",
        url: "https://web.math.ucsb.edu/~agboola/teaching/2021/winter/122A/rudin.pdf",
        provider: "Academic Classic"
      },
      {
        id: "mt340-2",
        title: "Real Analysis Course - Francis Su",
        type: "video", 
        description: "Complete real analysis course from Harvey Mudd College.",
        url: "https://www.youtube.com/watch?v=sqEyWLGvvdw&list=PL0E754696F72137EC",
        provider: "YouTube - Harvey Mudd College"
      },
      {
        id: "mt340-3",
        title: "Measure Theory and Real Analysis",
        type: "notes",
        description: "Advanced notes on measure theory and real analysis.",
        url: "https://terrytao.files.wordpress.com/2012/12/gsm-126-tao5-measure-book.pdf",
        provider: "Terence Tao"
      }
    ]
  },
  {
    code: "MT 310", 
    name: "Complex Analysis",
    semester: "First Semester",
    resources: [
      {
        id: "mt310-1",
        title: "Complex Analysis by Lars Ahlfors",
        type: "book",
        description: "Classic textbook on complex analysis and complex variables.",
        url: "https://www.maths.ed.ac.uk/~v1ranick/papers/ahlfors.pdf",
        provider: "Academic Publishing"
      },
      {
        id: "mt310-2",
        title: "Complex Analysis Visualized",
        type: "video",
        description: "Visual approach to complex analysis with 3Blue1Brown style explanations.",
        url: "https://www.youtube.com/watch?v=sD0NjbwqlYw&list=PLiaHhY2iBX9g6KIvZ_703G3KJXapKkNaF",
        provider: "YouTube - Welch Labs"
      }
    ]
  },
  {
    code: "ST 319",
    name: "Design of Experiments", 
    semester: "First Semester",
    resources: [
      {
        id: "st319-1",
        title: "Design and Analysis of Experiments by Montgomery",
        type: "book",
        description: "Comprehensive guide to experimental design and ANOVA.",
        url: "https://faculty.business.utsa.edu/manderso/STA4723/readings/Douglas-C.-Montgomery-Design-and-Analysis-of-Experiments-Wiley-2012.pdf",
        provider: "Wiley Publishing"
      },
      {
        id: "st319-2",
        title: "Experimental Design Course",
        type: "video",
        description: "Complete course on design of experiments and statistical analysis.",
        url: "https://www.youtube.com/watch?v=It9Ge_Z_kEs&list=PLvxOuBpazmsNIHP5cz37oOPZx0JOjm6Gh",
        provider: "YouTube - Brandon Foltz"
      }
    ]
  },
  {
    code: "ST 318",
    name: "Sampling Theory",
    semester: "Second Semester",
    resources: [
      {
        id: "st318-1", 
        title: "Sampling Techniques by William Cochran",
        type: "book",
        description: "Classic textbook on sampling theory and survey methodology.",
        url: "https://notendur.hi.is/olafur/cochra_s.pdf",
        provider: "Wiley Classic"
      },
      {
        id: "st318-2",
        title: "Survey Sampling Methods",
        type: "video", 
        description: "Comprehensive course on sampling techniques and survey design.",
        url: "https://www.youtube.com/watch?v=Zbr9vWaejlI&list=PLvxOuBpazmsOHEOWx4gGqvpxEjgdq7fqh",
        provider: "YouTube - Dr. Grande"
      }
    ]
  },
  {
    code: "ST 321",
    name: "Regression Analysis",
    semester: "Second Semester", 
    resources: [
      {
        id: "st321-1",
        title: "Applied Linear Regression by Weisberg",
        type: "book",
        description: "Practical approach to linear regression analysis.",
        url: "https://users.stat.umn.edu/~sandy/alr4ed/",
        provider: "University of Minnesota"
      },
      {
        id: "st321-2",
        title: "Regression Analysis in R",
        type: "video",
        description: "Complete regression analysis course using R programming.",
        url: "https://www.youtube.com/watch?v=66z_MRwtFJM&list=PLvxOuBpazmsNHxjk_UCoOzeLjH1D5q6_C",
        provider: "YouTube - MarinStatsLectures"
      }
    ]
  },
  {
    code: "MT 360",
    name: "Functional Analysis", 
    semester: "Second Semester",
    resources: [
      {
        id: "mt360-1",
        title: "Functional Analysis by Walter Rudin",
        type: "book",
        description: "Advanced textbook on functional analysis and operator theory.",
        url: "https://59clc.files.wordpress.com/2011/01/functional-analysis-rudin.pdf",
        provider: "McGraw-Hill"
      },
      {
        id: "mt360-2",
        title: "Functional Analysis Lectures",
        type: "video",
        description: "Graduate level course on functional analysis.",
        url: "https://www.youtube.com/watch?v=yDdxFBcvSGw&list=PLAvgI3H-gclZa-DVTMyUIAxM-X8NSikwu",
        provider: "YouTube - ICTP Mathematics"
      }
    ]
  }
];

export const CourseResources = () => {
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedCourse, setSelectedCourse] = useState("all");
  const [selectedType, setSelectedType] = useState("all");
  const [aiResources, setAiResources] = useState<any>(null);
  const [loadingAI, setLoadingAI] = useState(false);
  const [showAIDialog, setShowAIDialog] = useState(false);
  const [showVideoPlayer, setShowVideoPlayer] = useState(false);
  const [selectedVideo, setSelectedVideo] = useState<{ url: string; title: string } | null>(null);

  // Get resources based on selection
  const getDisplayResources = () => {
    if (selectedCourse === "all") {
      // Show all resources from all courses
      return coursesData.flatMap(course => 
        course.resources.map(resource => ({
          ...resource,
          courseName: course.name,
          courseCode: course.code,
          semester: course.semester
        }))
      );
    } else {
      // Show resources for selected course only
      const course = coursesData.find(c => c.code === selectedCourse);
      return course ? course.resources.map(resource => ({
        ...resource,
        courseName: course.name,
        courseCode: course.code,
        semester: course.semester
      })) : [];
    }
  };

  const displayResources = getDisplayResources();

  const filteredResources = displayResources.filter(resource => {
    const matchesSearch = resource.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         resource.courseCode.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         resource.courseName.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         resource.description.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesType = selectedType === "all" || resource.type === selectedType;
    
    return matchesSearch && matchesType;
  });

  const getTypeIcon = (type: string) => {
    switch (type) {
      case 'video': return Video;
      case 'book': return BookOpen;
      case 'notes': return FileText;
      case 'paper': return FileText;
      default: return BookOpen;
    }
  };

  const getTypeColor = (type: string) => {
    switch (type) {
      case 'video': return "bg-red-100 text-red-800";
      case 'book': return "bg-blue-100 text-blue-800";
      case 'notes': return "bg-green-100 text-green-800";
      case 'paper': return "bg-purple-100 text-purple-800";
      default: return "bg-gray-100 text-gray-800";
    }
  };

  const generateAIResources = useCallback(async (topic: string) => {
    setLoadingAI(true);
    try {
      const response = await fetch('https://jonaokelbczvhqkrslel.supabase.co/functions/v1/deepseek-ai', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          prompt: `Generate study resources for: ${topic}`,
          gameType: 'generate-resources',
        }),
      });

      if (!response.ok) throw new Error('Failed to generate resources');
      
      const data = await response.json();
      setAiResources(data.result);
      setShowAIDialog(true);
      toast.success("🤖 AI resources generated!");
    } catch (error) {
      console.error('Error generating AI resources:', error);
      toast.error("Failed to generate AI resources. Please try again.");
    }
    setLoadingAI(false);
  }, []);

  const handleViewOnline = (resource: Resource & { courseCode: string; courseName: string; semester: string }) => {
    if (resource.type === 'video' || resource.url.includes('youtube.com')) {
      // Use internal video player for videos
      setSelectedVideo({ url: resource.url, title: resource.title });
      setShowVideoPlayer(true);
      toast.success(`📺 Playing video: ${resource.title}`);
    } else {
      window.open(resource.url, '_blank', 'noopener,noreferrer');
      toast.success(`🔗 Opening ${resource.title}. Happy studying!`);
    }
  };

  const extractYouTubeVideoId = (url: string): string | null => {
    const regex = /(?:youtube\.com\/(?:[^\/]+\/.+\/|(?:v|e(?:mbed)?)\/|.*[?&]v=)|youtu\.be\/)([^"&?\/\s]{11})/;
    const match = url.match(regex);
    return match ? match[1] : null;
  };

  const handleDownload = (resource: Resource & { courseCode: string; courseName: string; semester: string }) => {
    if (resource.type === 'video' || resource.url.includes('youtube.com')) {
      handleViewOnline(resource);
    } else {
      // For non-video resources, try to open in new tab
      window.open(resource.url, '_blank', 'noopener,noreferrer');
      toast.success(`📚 Opening: ${resource.title}`);
    }
  };

  return (
    <Card className="bg-gradient-to-br from-green-50 to-blue-50 border-0 shadow-xl">
      <CardHeader className="pb-3">
        <CardTitle className="flex flex-col sm:flex-row sm:items-center space-y-1.5 sm:space-y-0 sm:space-x-2 text-sm sm:text-base">
          <div className="flex items-center space-x-1.5">
            <BookOpen className="h-4 w-4 sm:h-5 sm:w-5 text-green-600" />
            <span className="text-sm sm:text-base">Third Year Course Resources 📚</span>
          </div>
          <Badge className="bg-green-100 text-green-800 text-xs w-fit px-2 py-0.5">
            Math & Stats
          </Badge>
        </CardTitle>
      </CardHeader>
      <CardContent className="pt-0">
        {/* Search and Filters */}
        <div className="mb-3 space-y-2">
          <div className="flex space-x-1.5">
            <div className="relative flex-1">
              <Search className="absolute left-2.5 top-1/2 transform -translate-y-1/2 text-gray-400 h-3 w-3" />
              <Input
                placeholder="Search resources, courses..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-8 text-xs h-8"
              />
            </div>
            <Button
              onClick={() => generateAIResources(searchTerm || "mathematics and statistics")}
              disabled={loadingAI}
              size="sm"
              className="bg-gradient-to-r from-blue-500 to-purple-500 hover:from-blue-600 hover:to-purple-600 text-white text-xs h-8 px-2"
            >
              {loadingAI ? (
                <div className="animate-spin rounded-full h-2.5 w-2.5 border-b-2 border-white mr-1"></div>
              ) : (
                <Sparkles className="h-2.5 w-2.5 mr-1" />
              )}
              AI Help
            </Button>
          </div>
          
          <div className="flex space-x-1.5">
            <Select value={selectedCourse} onValueChange={setSelectedCourse}>
              <SelectTrigger className="w-full text-xs h-8">
                <SelectValue placeholder="All Courses" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Courses</SelectItem>
                {coursesData.map(course => (
                  <SelectItem key={course.code} value={course.code}>
                    {course.code} - {course.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            
            <Select value={selectedType} onValueChange={setSelectedType}>
              <SelectTrigger className="w-full text-xs h-8">
                <SelectValue placeholder="All Types" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Types</SelectItem>
                <SelectItem value="video">Videos</SelectItem>
                <SelectItem value="book">Books</SelectItem>
                <SelectItem value="notes">Notes</SelectItem>
                <SelectItem value="paper">Past Papers</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>

        {/* Resources List */}
        <div className="space-y-2 max-h-[60vh] sm:max-h-80 overflow-y-auto">
          {filteredResources.map((resource, index) => {
            const TypeIcon = getTypeIcon(resource.type);
            return (
              <div 
                key={resource.id}
                className="bg-white/80 backdrop-blur-sm rounded-lg p-2.5 border border-white/50 hover:shadow-md transition-all duration-300 animate-fade-in"
                style={{ animationDelay: `${index * 0.05}s` }}
              >
                <div className="flex flex-col space-y-2">
                  <div className="flex items-start space-x-2">
                    <TypeIcon className="h-3 w-3 text-gray-600 mt-0.5 flex-shrink-0" />
                    <div className="flex-1 min-w-0">
                      <h3 className="font-semibold text-gray-800 text-xs leading-tight break-words">{resource.title}</h3>
                      <p className="text-xs text-gray-600 mt-0.5 line-clamp-2">{resource.description}</p>
                    </div>
                  </div>
                  
                  <div className="flex flex-wrap items-center gap-1.5">
                    <Badge className="bg-indigo-100 text-indigo-800 text-xs px-1.5 py-0.5">
                      {resource.courseCode}
                    </Badge>
                    <Badge className={`text-xs ${getTypeColor(resource.type)}`}>
                      {resource.type}
                    </Badge>
                    <span className="text-xs text-gray-500">{resource.semester}</span>
                  </div>
                  
                  <div className="flex justify-between text-xs text-gray-600">
                    <span className="flex items-center truncate">👨‍🏫 {resource.provider}</span>
                    <span className="flex items-center">📚 {resource.courseName}</span>
                  </div>
                  
                  <div className="flex items-center space-x-2 pt-2 border-t border-gray-200">
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => handleViewOnline(resource)}
                      className="text-xs hover:bg-blue-50 flex-1 sm:flex-none"
                    >
                      {resource.type === 'video' ? (
                        <Play className="h-3 w-3 mr-1" />
                      ) : (
                        <ExternalLink className="h-3 w-3 mr-1" />
                      )}
                      <span className="hidden sm:inline">{resource.type === 'video' ? 'Watch' : 'View'}</span>
                      <span className="sm:hidden">Open</span>
                    </Button>
                    <Button
                      size="sm"
                      onClick={() => handleDownload(resource)}
                      className="text-xs bg-green-600 hover:bg-green-700 text-white flex-1 sm:flex-none"
                    >
                      <Download className="h-3 w-3 mr-1" />
                      <span className="hidden sm:inline">Download</span>
                      <span className="sm:hidden">Save</span>
                    </Button>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
        
        {filteredResources.length === 0 && (
          <div className="text-center py-8">
            <BookOpen className="h-12 w-12 text-gray-300 mx-auto mb-3" />
            <h3 className="text-base font-semibold text-gray-600 mb-2">No resources found</h3>
            <p className="text-gray-500 text-sm">Try adjusting your search or filters</p>
          </div>
        )}
        
        <div className="mt-4 text-center px-2">
          <p className="text-xs text-gray-600">
            Resources for BSc Mathematics and Statistics - Third Year curriculum 🎓
          </p>
        </div>
      </CardContent>

      {/* AI Resources Dialog */}
      <Dialog open={showAIDialog} onOpenChange={setShowAIDialog}>
        <DialogContent className="max-w-3xl max-h-[80vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="flex items-center space-x-2">
              <Sparkles className="h-5 w-5 text-blue-500" />
              <span>AI-Generated Study Resources</span>
            </DialogTitle>
          </DialogHeader>
          
          {aiResources && (
            <div className="space-y-4">
              {/* YouTube Videos */}
              {aiResources.videos && (
                <div>
                  <h3 className="font-semibold text-sm mb-2 flex items-center">
                    <Video className="h-4 w-4 mr-2 text-red-500" />
                    Recommended Videos
                  </h3>
                  <div className="space-y-2">
                    {aiResources.videos.map((video: any, index: number) => (
                      <div key={index} className="p-3 border rounded-lg bg-red-50">
                        <h4 className="font-medium text-sm">{video.title || video}</h4>
                        {video.creator && <p className="text-xs text-gray-600">by {video.creator}</p>}
                        <Button 
                          size="sm" 
                          className="mt-2 text-xs bg-red-500 hover:bg-red-600"
                          onClick={() => window.open(`https://youtube.com/results?search_query=${encodeURIComponent(video.title || video)}`, '_blank')}
                        >
                          <Play className="h-3 w-3 mr-1" />
                          Search YouTube
                        </Button>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Books */}
              {aiResources.books && (
                <div>
                  <h3 className="font-semibold text-sm mb-2 flex items-center">
                    <BookOpen className="h-4 w-4 mr-2 text-blue-500" />
                    Recommended Books
                  </h3>
                  <div className="space-y-2">
                    {aiResources.books.map((book: any, index: number) => (
                      <div key={index} className="p-3 border rounded-lg bg-blue-50">
                        <h4 className="font-medium text-sm">{book.title || book}</h4>
                        {book.author && <p className="text-xs text-gray-600">by {book.author}</p>}
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Online Courses */}
              {aiResources.courses && (
                <div>
                  <h3 className="font-semibold text-sm mb-2 flex items-center">
                    <Globe className="h-4 w-4 mr-2 text-green-500" />
                    Online Courses
                  </h3>
                  <div className="space-y-2">
                    {aiResources.courses.map((course: any, index: number) => (
                      <div key={index} className="p-3 border rounded-lg bg-green-50">
                        <h4 className="font-medium text-sm">{course.title || course}</h4>
                        {course.platform && <p className="text-xs text-gray-600">on {course.platform}</p>}
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Practice Exercises */}
              {aiResources.exercises && (
                <div>
                  <h3 className="font-semibold text-sm mb-2 flex items-center">
                    <FileText className="h-4 w-4 mr-2 text-purple-500" />
                    Practice Exercises
                  </h3>
                  <div className="space-y-2">
                    {aiResources.exercises.map((exercise: any, index: number) => (
                      <div key={index} className="p-3 border rounded-lg bg-purple-50">
                        <h4 className="font-medium text-sm">{exercise.title || exercise}</h4>
                        {exercise.description && <p className="text-xs text-gray-600">{exercise.description}</p>}
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          )}
        </DialogContent>
      </Dialog>

      {/* Video Player Modal */}
      {showVideoPlayer && selectedVideo && (
        <VideoPlayer
          isOpen={showVideoPlayer}
          onClose={() => {
            setShowVideoPlayer(false);
            setSelectedVideo(null);
          }}
          videoUrl={selectedVideo.url}
          title={selectedVideo.title}
        />
      )}
    </Card>
  );
};