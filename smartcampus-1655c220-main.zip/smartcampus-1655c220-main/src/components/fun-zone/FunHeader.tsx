
import { Button } from "@/components/ui/button";
import { Camera, ArrowLeft, Laugh } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { useIsMobile } from "@/hooks/use-mobile";

interface FunHeaderProps {
  onUploadMeme: () => void;
}

export const FunHeader = ({ onUploadMeme }: FunHeaderProps) => {
  const navigate = useNavigate();
  const isMobile = useIsMobile();

  const handleBackClick = () => {
    navigate("/");
  };

  return (
    <header className="bg-white/60 backdrop-blur-xl shadow-sm border-b border-white/20 sticky top-0 z-50">
      <div className="max-w-6xl mx-auto px-3 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-14 sm:h-16">
          <div className="flex items-center space-x-2 sm:space-x-4">
            <Button
              variant="ghost"
              size={isMobile ? "sm" : "default"}
              onClick={handleBackClick}
              className="p-2 hover:bg-white/20 transition-colors"
            >
              <ArrowLeft className="h-5 w-5 sm:h-6 sm:w-6" />
            </Button>
            <div className="flex items-center space-x-1 sm:space-x-2">
              <div className="bg-gradient-to-r from-purple-600 to-pink-600 text-white p-1.5 sm:p-2 rounded-lg animate-pulse">
                <Laugh className="h-5 w-5 sm:h-6 sm:w-6" />
              </div>
              <span className="text-lg sm:text-xl font-bold bg-gradient-to-r from-purple-600 to-pink-600 bg-clip-text text-transparent">
                {isMobile ? "Fun Zone" : "Fun Zone 🎉 - Vibes za Tanzania!"}
              </span>
            </div>
          </div>
          <div className="flex space-x-2">
            <Button 
              size={isMobile ? "sm" : "default"}
              onClick={onUploadMeme}
              className="bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 text-white shadow-lg hover:shadow-xl transition-all duration-300 hover:scale-105 transform text-xs sm:text-sm"
            >
              <Camera className="h-3 w-3 sm:h-4 sm:w-4 mr-1 sm:mr-2" />
              {isMobile ? "Upload" : "Pakia Meme"}
            </Button>
          </div>
        </div>
      </div>
    </header>
  );
};
