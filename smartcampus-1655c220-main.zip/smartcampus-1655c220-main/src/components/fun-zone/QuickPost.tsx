import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Textarea } from "@/components/ui/textarea";
import { Camera, Trophy } from "lucide-react";
import { useIsMobile } from "@/hooks/use-mobile";
interface QuickPostProps {
  newPost: string;
  setNewPost: (value: string) => void;
  onNewPost: () => void;
  onPhotoUpload: () => void;
  onCreatePoll: () => void;
}
export const QuickPost = ({
  newPost,
  setNewPost,
  onNewPost,
  onPhotoUpload,
  onCreatePoll
}: QuickPostProps) => {
  const isMobile = useIsMobile();
  return <div className="flex justify-center w-full">
      <Card className="mb-4 sm:mb-6 bg-white/60 backdrop-blur-xl border-0 shadow-lg hover:bg-white/70 transition-all duration-300 animate-scale-in w-full max-w-2xl mx-auto">
        <CardContent className="p-3 sm:p-4">
          <div className="flex space-x-2 sm:space-x-3 justify-center">
            
            <div className="flex-1 space-y-2 sm:space-y-3 min-w-0">
              <Textarea placeholder="unawaza nini leo" value={newPost} onChange={e => setNewPost(e.target.value)} className="bg-white/80 backdrop-blur-sm border-white/20 focus:bg-white transition-all duration-300 text-sm sm:text-base min-h-[60px] sm:min-h-[80px] resize-none text-center sm:text-left" rows={isMobile ? 2 : 3} />
              <div className="flex flex-col sm:flex-row justify-between items-stretch sm:items-center space-y-2 sm:space-y-0">
                <div className="flex space-x-2 justify-center sm:justify-start">
                  <Button variant="outline" size="sm" onClick={onPhotoUpload} className="bg-white/60 backdrop-blur-sm border-white/20 text-xs flex-1 sm:flex-none hover:bg-white/80 transition-all duration-300">
                    <Camera className="h-3 w-3 sm:h-4 sm:w-4 mr-1" />
                    Picha
                  </Button>
                  <Button variant="outline" size="sm" onClick={onCreatePoll} className="bg-white/60 backdrop-blur-sm border-white/20 text-xs flex-1 sm:flex-none hover:bg-white/80 transition-all duration-300">
                    <Trophy className="h-3 w-3 sm:h-4 sm:w-4 mr-1" />
                    Poll
                  </Button>
                </div>
                <Button onClick={onNewPost} size={isMobile ? "sm" : "default"} className="bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 text-white shadow-lg hover:shadow-xl transition-all duration-300 hover:scale-105 transform text-xs sm:text-sm w-full sm:w-auto" disabled={!newPost.trim()}>
                  Share Vibes! 🎉 Twende pamoja!
                </Button>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>;
};