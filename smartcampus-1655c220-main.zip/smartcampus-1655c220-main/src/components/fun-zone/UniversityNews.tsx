import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Newspaper, ExternalLink, Clock, MapPin, GraduationCap, RefreshCw } from "lucide-react";
import { toast } from "sonner";

interface NewsItem {
  id: string;
  title: string;
  summary: string;
  source: string;
  category: string;
  timeAgo: string;
  url: string;
  urgent: boolean;
  location?: string;
}

const universityNews: NewsItem[] = [
  {
    id: "news-1",
    title: "UDSM Announces New Academic Calendar for 2024/2025",
    summary: "The University has released the official academic calendar with key dates for registration, examinations, and semester breaks.",
    source: "UDSM Official",
    category: "Academic",
    timeAgo: "2 hours ago",
    url: "#",
    urgent: true,
    location: "Dar es Salaam"
  },
  {
    id: "news-2",
    title: "Engineering Faculty Opens New Computer Lab",
    summary: "State-of-the-art computer laboratory with 100 workstations now available for students in the College of Engineering.",
    source: "Engineering Faculty",
    category: "Infrastructure",
    timeAgo: "6 hours ago",
    url: "#",
    urgent: false,
    location: "CoET Campus"
  },
  {
    id: "news-3",
    title: "HELB Application Deadline Extended",
    summary: "Higher Education Loans Board extends application deadline for student loans. New deadline: December 15th, 2024.",
    source: "HELB Tanzania",
    category: "Financial Aid",
    timeAgo: "1 day ago",
    url: "#",
    urgent: true
  },
  {
    id: "news-4",
    title: "Research Conference: Innovation in East Africa",
    summary: "Annual research conference featuring presentations from students and faculty across East African universities.",
    source: "Research Department",
    category: "Research",
    timeAgo: "2 days ago",
    url: "#",
    urgent: false,
    location: "Main Campus"
  },
  {
    id: "news-5",
    title: "New Hostels Construction Update",
    summary: "Progress update on the construction of 4 new hostels that will accommodate 2,000 additional students.",
    source: "Infrastructure Department",
    category: "Housing",
    timeAgo: "3 days ago",
    url: "#",
    urgent: false,
    location: "Mlimani Campus"
  },
  {
    id: "news-6",
    title: "Inter-University Sports Championship",
    summary: "UDSM teams preparing for the East African University Sports Championships scheduled for January 2025.",
    source: "Sports Department",
    category: "Sports",
    timeAgo: "1 week ago",
    url: "#",
    urgent: false
  }
];

export const UniversityNews = () => {
  const [displayedNews, setDisplayedNews] = useState<NewsItem[]>([]);
  const [isRefreshing, setIsRefreshing] = useState(false);

  useEffect(() => {
    // Show latest news items
    setDisplayedNews(universityNews.slice(0, 4));
  }, []);

  const getCategoryColor = (category: string) => {
    switch (category) {
      case "Academic": return "bg-blue-100 text-blue-800";
      case "Infrastructure": return "bg-green-100 text-green-800";
      case "Financial Aid": return "bg-purple-100 text-purple-800";
      case "Research": return "bg-orange-100 text-orange-800";
      case "Housing": return "bg-yellow-100 text-yellow-800";
      case "Sports": return "bg-red-100 text-red-800";
      default: return "bg-gray-100 text-gray-800";
    }
  };

  const handleRefresh = () => {
    setIsRefreshing(true);
    // Simulate fetching new news
    setTimeout(() => {
      const shuffled = [...universityNews].sort(() => Math.random() - 0.5);
      setDisplayedNews(shuffled.slice(0, 4));
      setIsRefreshing(false);
      toast.success("News updated! Fresh information from universities! 📰");
    }, 1500);
  };

  const handleReadMore = (newsItem: NewsItem) => {
    toast.info(`Opening ${newsItem.title}... Stay informed, jamani!`);
    // In a real app, this would open the actual news article
  };

  return (
    <Card className="bg-gradient-to-br from-blue-50 to-indigo-50 border-0 shadow-xl">
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle className="flex items-center space-x-2 text-lg">
            <Newspaper className="h-6 w-6 text-blue-600" />
            <span>Tanzania University News 🇹🇿</span>
          </CardTitle>
          <Button
            size="sm"
            variant="outline"
            onClick={handleRefresh}
            disabled={isRefreshing}
            className="hover:bg-blue-50"
          >
            <RefreshCw className={`h-4 w-4 mr-1 ${isRefreshing ? 'animate-spin' : ''}`} />
            {isRefreshing ? 'Loading...' : 'Refresh'}
          </Button>
        </div>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {displayedNews.map((news, index) => (
            <div 
              key={news.id}
              className="bg-white/80 backdrop-blur-sm rounded-lg p-4 border border-white/50 hover:shadow-md transition-all duration-300 animate-fade-in"
              style={{ animationDelay: `${index * 0.1}s` }}
            >
              <div className="flex items-start justify-between mb-3">
                <div className="flex-1">
                  <div className="flex items-center space-x-2 mb-2">
                    <h3 className="font-semibold text-gray-800 text-sm leading-tight">{news.title}</h3>
                    {news.urgent && (
                      <Badge className="bg-red-100 text-red-800 text-xs px-2 py-1">
                        🚨 Urgent
                      </Badge>
                    )}
                  </div>
                  <p className="text-sm text-gray-700 leading-relaxed mb-3">{news.summary}</p>
                  
                  <div className="flex flex-wrap items-center gap-2 mb-2">
                    <Badge className={`text-xs ${getCategoryColor(news.category)}`}>
                      {news.category}
                    </Badge>
                    <div className="flex items-center space-x-1 text-xs text-gray-600">
                      <Clock className="h-3 w-3" />
                      <span>{news.timeAgo}</span>
                    </div>
                    {news.location && (
                      <div className="flex items-center space-x-1 text-xs text-gray-600">
                        <MapPin className="h-3 w-3" />
                        <span>{news.location}</span>
                      </div>
                    )}
                  </div>
                  
                  <div className="flex items-center space-x-1 text-xs text-gray-600">
                    <GraduationCap className="h-3 w-3" />
                    <span>{news.source}</span>
                  </div>
                </div>
              </div>
              
              <div className="flex items-center justify-end pt-3 border-t border-gray-200">
                <Button
                  size="sm"
                  variant="outline"
                  onClick={() => handleReadMore(news)}
                  className="text-xs hover:bg-blue-50"
                >
                  <ExternalLink className="h-3 w-3 mr-1" />
                  Read More
                </Button>
              </div>
            </div>
          ))}
        </div>
        
        <div className="mt-4 text-center">
          <p className="text-xs text-gray-600">
            Stay updated with the latest news from Tanzania universities! 🎓
          </p>
        </div>
      </CardContent>
    </Card>
  );
};