export const WelcomeBanner = () => {
  return <div className="text-center mb-4 sm:mb-6 animate-fade-in">
      <h1 className="text-2xl sm:text-3xl md:text-4xl font-bold bg-gradient-to-r from-purple-600 to-pink-600 bg-clip-text text-transparent mb-2 text-center">Karibu Fun Zone! 🎈Vibes!</h1>
      <p className="text-gray-600 text-sm sm:text-lg mb-4 px-2 text-center">Share memes, siri, Lets laugh Ya'll! </p>
    </div>;
};