import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Gamepad2, Trophy, Star, Clock, Zap } from "lucide-react";
import { toast } from "sonner";
import { GameModal } from "./GameModal";

interface Game {
  id: string;
  title: string;
  description: string;
  difficulty: string;
  points: number;
  timeLimit: string;
  category: string;
  emoji: string;
}

const dailyGames: Game[] = [
  {
    id: "word-challenge",
    title: "Swahili Word Challenge",
    description: "Tumia maneno ya Kiswahili kuunda sentensi moja ya maana!",
    difficulty: "Easy",
    points: 50,
    timeLimit: "2 min",
    category: "Language",
    emoji: "📝"
  },
  {
    id: "math-puzzle",
    title: "Quick Math Puzzle",
    description: "Solve this calculus problem faster than your classmates!",
    difficulty: "Medium",
    points: 100,
    timeLimit: "5 min",
    category: "Mathematics",
    emoji: "🧮"
  },
  {
    id: "trivia-tanzania",
    title: "Tanzania Trivia",
    description: "Test your knowledge about our beautiful country!",
    difficulty: "Easy",
    points: 75,
    timeLimit: "3 min",
    category: "Culture",
    emoji: "🇹🇿"
  },
  {
    id: "campus-quiz",
    title: "UDSM Campus Quiz",
    description: "How well do you know your campus? Let's find out!",
    difficulty: "Hard",
    points: 150,
    timeLimit: "10 min",
    category: "University",
    emoji: "🏛️"
  }
];

export const DailyGames = () => {
  const [playedGames, setPlayedGames] = useState<string[]>([]);
  const [currentGame, setCurrentGame] = useState<Game | null>(null);
  const [totalPoints, setTotalPoints] = useState(0);

  const getDifficultyColor = (difficulty: string) => {
    switch (difficulty) {
      case "Easy": return "bg-green-100 text-green-800";
      case "Medium": return "bg-yellow-100 text-yellow-800";
      case "Hard": return "bg-red-100 text-red-800";
      default: return "bg-gray-100 text-gray-800";
    }
  };

  const handlePlayGame = (game: Game) => {
    if (playedGames.includes(game.id)) {
      toast.info("Game hululu! You've already played this game today. Come back tomorrow for new challenges!");
      return;
    }

    setCurrentGame(game);
    toast.success(`${game.emoji} Starting ${game.title}! Good luck, mkuu!`);
  };

  const handleGameComplete = (points: number) => {
    if (currentGame) {
      setPlayedGames(prev => [...prev, currentGame.id]);
      setTotalPoints(prev => prev + points);
      toast.success(`🎉 Game completed! You earned ${points} points! Total: ${totalPoints + points}`);
      setCurrentGame(null);
    }
  };

  return (
    <Card className="bg-gradient-to-br from-purple-50 to-pink-50 border-0 shadow-xl">
      <CardHeader className="pb-3">
        <CardTitle className="flex items-center justify-between text-base sm:text-lg">
          <div className="flex items-center space-x-1.5">
            <Gamepad2 className="h-4 w-4 sm:h-5 sm:w-5 text-purple-600" />
            <span className="text-sm sm:text-base">Daily Games Hub 🎮</span>
            <Badge className="bg-purple-100 text-purple-800 text-xs px-2 py-0.5">
              New Today!
            </Badge>
          </div>
          {totalPoints > 0 && (
            <Badge className="bg-yellow-100 text-yellow-800 text-xs">
              🏆 {totalPoints} pts
            </Badge>
          )}
        </CardTitle>
      </CardHeader>
      <CardContent className="pt-0">
        <div className="grid gap-2.5">
          {dailyGames.map((game, index) => (
            <div 
              key={game.id}
              className="bg-white/80 backdrop-blur-sm rounded-lg p-3 border border-white/50 hover:shadow-md transition-all duration-300 animate-fade-in"
              style={{ animationDelay: `${index * 0.1}s` }}
            >
              <div className="flex items-start justify-between mb-2.5">
                <div className="flex items-start space-x-2 flex-1 min-w-0">
                  <span className="text-lg sm:text-xl flex-shrink-0">{game.emoji}</span>
                  <div className="min-w-0 flex-1">
                    <h3 className="font-semibold text-gray-800 text-xs sm:text-sm leading-tight">{game.title}</h3>
                    <p className="text-xs text-gray-600 leading-relaxed line-clamp-2">{game.description}</p>
                  </div>
                </div>
                <Badge className={`text-xs px-1.5 py-0.5 flex-shrink-0 ml-2 ${getDifficultyColor(game.difficulty)}`}>
                  {game.difficulty}
                </Badge>
              </div>
              
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-2 sm:space-x-3 text-xs text-gray-600">
                  <div className="flex items-center space-x-1">
                    <Star className="h-3 w-3 text-yellow-500" />
                    <span>{game.points} pts</span>
                  </div>
                  <div className="flex items-center space-x-1">
                    <Clock className="h-3 w-3 text-blue-500" />
                    <span>{game.timeLimit}</span>
                  </div>
                </div>
                
                <Button
                  size="sm"
                  onClick={() => handlePlayGame(game)}
                  disabled={playedGames.includes(game.id)}
                  className={`text-xs h-7 px-2 ${
                    playedGames.includes(game.id)
                      ? "bg-gray-300 text-gray-500 cursor-not-allowed"
                      : "bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600 text-white"
                  }`}
                >
                  {playedGames.includes(game.id) ? (
                    <>
                      <Trophy className="h-3 w-3 mr-1" />
                      Played
                    </>
                  ) : (
                    <>
                      <Zap className="h-3 w-3 mr-1" />
                      Play Now
                    </>
                  )}
                </Button>
              </div>
            </div>
          ))}
        </div>
        
        <div className="mt-3 text-center">
          <p className="text-xs text-gray-600">
            New games every day! Come back tomorrow for fresh challenges! 🚀
          </p>
        </div>
      </CardContent>
      
      {currentGame && (
        <GameModal
          isOpen={!!currentGame}
          onClose={() => setCurrentGame(null)}
          game={currentGame}
          onComplete={handleGameComplete}
        />
      )}
    </Card>
  );
};