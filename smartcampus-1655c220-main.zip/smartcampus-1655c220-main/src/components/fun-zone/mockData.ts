
export const funContent = [
  {
    id: 1,
    type: "meme",
    title: "Wakati mwalimu anasema 'hii itakuwa exam' 😭 Sasa ni nini hii jamani?",
    author: "MemeKing_UDSM",
    avatar: "MK",
    timeAgo: "masaa 2 yaliyopita",
    image: "photo-1582562124811-c09040d0a901",
    reactions: { laugh: 156, fire: 89, heart: 45, brain: 23 },
    comments: 34,
    category: "Memes"
  },
  {
    id: 2,
    type: "confession",
    title: "Hot Take: WiFi ya campus ni poa... amesema nani? 💀 Hakuna mtu kamwe!",
    author: "Anonymous_Confessor",
    avatar: "AC",
    timeAgo: "masaa 4 yaliyopita",
    content: "Nimekuwa hapa miaka 3 na naapa WiFi inazidi kuwa mbaya kila semester. Kuna mtu mwingine anafeel tunalipa fees za premium lakini tunapata internet ya dial-up? 😤 Achana nayo tu, bana!",
    reactions: { laugh: 234, fire: 167, heart: 12, brain: 89 },
    comments: 67,
    category: "Hot Takes"
  },
  {
    id: 3,
    type: "poll",
    title: "Chakula gani cha campus ni baya zaidi kuliko zote?",
    author: "FoodCritic_2024",
    avatar: "FC",
    timeAgo: "masaa 6 yaliyopita",
    poll: {
      question: "Ni chakula gani cha cafeteria kinafanya ukimbie mbio?",
      options: [
        { text: "Cafeteria A Rice & Beans - haiwezi kabisa!", votes: 45 },
        { text: "Cafeteria B Ugali Special - aki hapana", votes: 78 },
        { text: "Library Canteen Chips - zimekauka sana", votes: 23 },
        { text: "Zote hapo juu 💀 - tumeumia sana", votes: 134 }
      ],
      totalVotes: 280
    },
    reactions: { laugh: 89, fire: 45, heart: 12, brain: 67 },
    comments: 23,
    category: "Polls"
  },
  {
    id: 4,
    type: "screenshot",
    title: "Prof amesema hii leo darasani 📸 Achana nayo tu!",
    author: "ScreenshotMaster",
    avatar: "SM",
    timeAgo: "masaa 8 yaliyopita",
    image: "photo-1535268647677-300dbf3d78d1",
    content: "Wakati prof wako anakubali kuwa haelewi assignment yao wenyewe 😂 Je, hautashangaa namna gani!",
    reactions: { laugh: 345, fire: 123, heart: 67, brain: 89 },
    comments: 78,
    category: "Screenshots"
  }
];
