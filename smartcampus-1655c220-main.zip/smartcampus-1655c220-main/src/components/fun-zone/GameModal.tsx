import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Progress } from "@/components/ui/progress";
import { Clock, Trophy, Zap, CheckCircle, XCircle } from "lucide-react";
import { toast } from "sonner";

interface GameData {
  question: string;
  choices: string[];
  correctAnswer: string;
  explanation?: string;
  funFact?: string;
  solution?: string;
  tip?: string;
  facts?: string;
  importance?: string;
  info?: string;
  campusTip?: string;
}

interface GameModalProps {
  isOpen: boolean;
  onClose: () => void;
  game: {
    id: string;
    title: string;
    description: string;
    difficulty: string;
    points: number;
    timeLimit: string;
    category: string;
    emoji: string;
  };
  onComplete: (points: number) => void;
}

export const GameModal = ({ isOpen, onClose, game, onComplete }: GameModalProps) => {
  // Early return if game is null to prevent any property access errors
  if (!game) return null;
  
  const [gameData, setGameData] = useState<GameData | null>(null);
  const [loading, setLoading] = useState(false);
  const [selectedAnswer, setSelectedAnswer] = useState<string>("");
  const [answered, setAnswered] = useState(false);
  const [timeLeft, setTimeLeft] = useState(0);
  const [timerActive, setTimerActive] = useState(false);
  const [score, setScore] = useState(0);

  const getGameType = (gameId: string) => {
    switch (gameId) {
      case "word-challenge": return "swahili-word";
      case "math-puzzle": return "math-puzzle";
      case "trivia-tanzania": return "tanzania-trivia";
      case "campus-quiz": return "campus-quiz";
      default: return "general";
    }
  };

  const parseTimeLimit = (timeLimit: string): number => {
    const match = timeLimit.match(/(\d+)/);
    return match ? parseInt(match[1]) * 60 : 120; // Convert minutes to seconds
  };

  const generateGame = async () => {
    if (!game) return;
    
    setLoading(true);
    try {
      const gameType = getGameType(game.id);
      const prompt = `Generate a ${game.difficulty.toLowerCase()} level ${game.category.toLowerCase()} challenge.`;
      
      const response = await fetch('https://jonaokelbczvhqkrslel.supabase.co/functions/v1/deepseek-ai', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          prompt,
          gameType,
          difficulty: game.difficulty.toLowerCase()
        }),
      });

      if (!response.ok) throw new Error('Failed to generate game');
      
      const data = await response.json();
      setGameData(data.result);
      
      // Start timer
      const duration = parseTimeLimit(game.timeLimit);
      setTimeLeft(duration);
      setTimerActive(true);
    } catch (error) {
      console.error('Error generating game:', error);
      // Fallback to static content
      generateFallbackGame();
    }
    setLoading(false);
  };

  const generateFallbackGame = () => {
    if (!game) return;
    
    const fallbackGames = {
      "word-challenge": {
        question: "Andika sentensi moja kwa kutumia neno 'elimu':",
        choices: [
          "Elimu ni msingi wa maisha",
          "Elimu ni chakula",
          "Elimu ni gari",
          "Elimu ni mti"
        ],
        correctAnswer: "Elimu ni msingi wa maisha",
        explanation: "Elimu ni msingi wa maisha - hii ni sentensi sahihi kwa sababu elimu ni muhimu katika maisha ya kila mtu.",
        funFact: "Neno 'elimu' linatoka kutoka kiarabu na linamaanisha 'kupata ujuzi'."
      },
      "math-puzzle": {
        question: "Tatua: ∫(2x + 3)dx = ?",
        choices: [
          "x² + 3x + C",
          "2x² + 3x + C", 
          "x² + 3 + C",
          "2x + 3x + C"
        ],
        correctAnswer: "x² + 3x + C",
        solution: "∫(2x + 3)dx = ∫2x dx + ∫3 dx = x² + 3x + C",
        tip: "Kumbuka: ∫ax^n dx = (a/(n+1))x^(n+1) + C"
      },
      "trivia-tanzania": {
        question: "Mlima gani ni mrefu zaidi nchini Tanzania?",
        choices: [
          "Kilimanjaro",
          "Meru",
          "Hanang",
          "Rungwe"
        ],
        correctAnswer: "Kilimanjaro",
        facts: "Kilimanjaro ni mlima mrefu zaidi Afrika na una urefu wa mita 5,895.",
        importance: "Kilimanjaro ni ishara ya kiburi la kitaifa na ni muhimu kwa utalii."
      },
      "campus-quiz": {
        question: "UDSM ilianzishwa mwaka gani?",
        choices: [
          "1961",
          "1970", 
          "1964",
          "1975"
        ],
        correctAnswer: "1961",
        info: "Chuo Kikuu cha Dar es Salaam kilianzishwa mwaka 1961 kama kitengo cha Chuo Kikuu cha Afrika Mashariki.",
        campusTip: "UDSM ni chuo kikuu kikuu nchini Tanzania na kina historia ndefu ya elimu ya juu."
      }
    };

    setGameData(fallbackGames[game.id as keyof typeof fallbackGames] || fallbackGames["word-challenge"]);
    
    const duration = parseTimeLimit(game.timeLimit);
    setTimeLeft(duration);
    setTimerActive(true);
  };

  useEffect(() => {
    if (isOpen && !gameData) {
      generateGame();
    }
  }, [isOpen]);

  useEffect(() => {
    let interval: NodeJS.Timeout;
    if (timerActive && timeLeft > 0) {
      interval = setInterval(() => {
        setTimeLeft(prev => {
          if (prev <= 1) {
            setTimerActive(false);
            if (!answered) {
              toast.error("Time's up! ⏰");
              handleTimeUp();
            }
            return 0;
          }
          return prev - 1;
        });
      }, 1000);
    }
    return () => clearInterval(interval);
  }, [timerActive, timeLeft, answered]);

  const handleTimeUp = () => {
    if (!game) return;
    setAnswered(true);
    setTimerActive(false);
    const timeBonus = timeLeft > 0 ? Math.floor(timeLeft / 10) : 0;
    const finalScore = Math.floor(game.points * 0.3) + timeBonus; // Partial points for time up
    setScore(finalScore);
  };

  const handleAnswerSubmit = () => {
    if (!selectedAnswer || !gameData || !game) return;
    
    setAnswered(true);
    setTimerActive(false);
    
    const isCorrect = selectedAnswer === gameData.correctAnswer;
    const timeBonus = timeLeft > 0 ? Math.floor(timeLeft / 10) : 0;
    const basePoints = isCorrect ? game.points : Math.floor(game.points * 0.2);
    const finalScore = basePoints + timeBonus;
    
    setScore(finalScore);
    
    if (isCorrect) {
      toast.success(`🎉 Correct! +${finalScore} points!`);
    } else {
      toast.error(`❌ Wrong answer. +${finalScore} points for trying!`);
    }
  };

  const handleComplete = () => {
    onComplete(score);
    onClose();
    resetGame();
  };

  const resetGame = () => {
    setGameData(null);
    setSelectedAnswer("");
    setAnswered(false);
    setTimeLeft(0);
    setTimerActive(false);
    setScore(0);
  };

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  const progressPercentage = timeLeft > 0 ? (timeLeft / parseTimeLimit(game.timeLimit)) * 100 : 0;

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center space-x-2">
            <span className="text-2xl">{game.emoji}</span>
            <span>{game.title}</span>
            <Badge className={`text-xs ${
              game.difficulty === "Easy" ? "bg-green-100 text-green-800" :
              game.difficulty === "Medium" ? "bg-yellow-100 text-yellow-800" :
              "bg-red-100 text-red-800"
            }`}>
              {game.difficulty}
            </Badge>
          </DialogTitle>
        </DialogHeader>

        {loading ? (
          <div className="text-center py-8">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary mx-auto mb-4"></div>
            <p>Generating your challenge...</p>
          </div>
        ) : gameData ? (
          <div className="space-y-4">
            {/* Timer and Progress */}
            <div className="space-y-2">
              <div className="flex items-center justify-between text-sm">
                <span className="flex items-center space-x-1">
                  <Clock className="h-4 w-4" />
                  <span>Time: {formatTime(timeLeft)}</span>
                </span>
                <span className="flex items-center space-x-1">
                  <Trophy className="h-4 w-4" />
                  <span>Max Points: {game.points}</span>
                </span>
              </div>
              <Progress value={progressPercentage} className="h-2" />
            </div>

            {/* Question */}
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">{gameData.question}</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {gameData.choices.map((choice, index) => (
                    <Button
                      key={index}
                      variant={answered ? 
                        (choice === gameData.correctAnswer ? "default" :
                         choice === selectedAnswer ? "destructive" : "outline") :
                        (selectedAnswer === choice ? "default" : "outline")
                      }
                      className={`w-full text-left justify-start p-4 h-auto ${
                        answered && choice === gameData.correctAnswer ? "bg-green-500 hover:bg-green-600" :
                        answered && choice === selectedAnswer && choice !== gameData.correctAnswer ? "bg-red-500 hover:bg-red-600" : ""
                      }`}
                      onClick={() => !answered && setSelectedAnswer(choice)}
                      disabled={answered}
                    >
                      <div className="flex items-center space-x-2">
                        {answered && choice === gameData.correctAnswer && <CheckCircle className="h-4 w-4" />}
                        {answered && choice === selectedAnswer && choice !== gameData.correctAnswer && <XCircle className="h-4 w-4" />}
                        <span>{String.fromCharCode(65 + index)}. {choice}</span>
                      </div>
                    </Button>
                  ))}
                </div>

                {!answered && selectedAnswer && (
                  <Button 
                    onClick={handleAnswerSubmit}
                    className="w-full mt-4"
                    disabled={timeLeft === 0}
                  >
                    <Zap className="h-4 w-4 mr-2" />
                    Submit Answer
                  </Button>
                )}
              </CardContent>
            </Card>

            {/* Results and Explanation */}
            {answered && (
              <Card className="bg-gradient-to-r from-blue-50 to-purple-50">
                <CardContent className="pt-6">
                  <div className="space-y-3">
                    <div className="text-center">
                      <h3 className="text-lg font-semibold">
                        {selectedAnswer === gameData.correctAnswer ? "🎉 Excellent!" : "📚 Good Try!"}
                      </h3>
                      <p className="text-sm text-gray-600">You earned {score} points!</p>
                    </div>
                    
                    {(gameData.explanation || gameData.solution) && (
                      <div>
                        <h4 className="font-semibold text-sm mb-2">💡 Explanation:</h4>
                        <p className="text-sm">{gameData.explanation || gameData.solution}</p>
                      </div>
                    )}
                    
                    {(gameData.funFact || gameData.tip || gameData.facts || gameData.campusTip) && (
                      <div>
                        <h4 className="font-semibold text-sm mb-2">🌟 Did you know?</h4>
                        <p className="text-sm">{gameData.funFact || gameData.tip || gameData.facts || gameData.campusTip}</p>
                      </div>
                    )}
                    
                    <Button onClick={handleComplete} className="w-full">
                      Continue
                    </Button>
                  </div>
                </CardContent>
              </Card>
            )}
          </div>
        ) : (
          <div className="text-center py-8">
            <p>Failed to load game. Please try again.</p>
            <Button onClick={generateGame} className="mt-4">
              Retry
            </Button>
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
};