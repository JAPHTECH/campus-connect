import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Clock, MessageCircle, Share } from "lucide-react";
import { useIsMobile } from "@/hooks/use-mobile";
interface FunContent {
  id: number;
  type: string;
  title: string;
  author: string;
  avatar: string;
  timeAgo: string;
  image?: string;
  content?: string;
  reactions: {
    [key: string]: number;
  };
  comments: number;
  category: string;
  poll?: {
    question: string;
    options: {
      text: string;
      votes: number;
    }[];
    totalVotes: number;
  };
}
interface FunContentCardProps {
  content: FunContent;
  index: number;
  selectedPoll: {
    [key: number]: string;
  };
  onReaction: (postId: number, reactionType: string) => void;
  onPollVote: (postId: number, optionIndex: number) => void;
  onShare: (postId: number, title: string) => void;
}
export const FunContentCard = ({
  content,
  index,
  selectedPoll,
  onReaction,
  onPollVote,
  onShare
}: FunContentCardProps) => {
  const isMobile = useIsMobile();
  const reactionEmojis = {
    laugh: "😂",
    fire: "🔥",
    heart: "❤️",
    brain: "🤔"
  };
  return <div className="flex justify-center w-full">
      <Card className="bg-white/60 backdrop-blur-xl border-0 shadow-lg hover:bg-white/70 transition-all duration-300 hover:scale-105 transform animate-fade-in group w-full max-w-2xl mx-auto" style={{
      animationDelay: `${index * 0.1}s`
    }}>
        <CardContent className="p-3 sm:p-6">
          <div className="flex items-start justify-center space-x-2 sm:space-x-3 mb-3 sm:mb-4">
            
            
            <div className="flex-1 min-w-0 text-center sm:text-left">
              <div className="flex flex-col sm:flex-row sm:items-center space-y-1 sm:space-y-0 sm:space-x-2 mb-1 justify-center sm:justify-start">
                <span className="font-semibold text-gray-900 text-sm sm:text-base truncate">{content.author}</span>
                <div className="flex items-center space-x-1 sm:space-x-2 text-xs sm:text-sm text-gray-500 justify-center sm:justify-start">
                  <span className="hidden sm:inline">•</span>
                  <Clock className="h-3 w-3" />
                  <span>{content.timeAgo}</span>
                  <Badge variant="secondary" className="text-xs bg-gradient-to-r from-purple-50 to-pink-50 text-purple-700 border-purple-200 shadow-sm ml-2">
                    {content.category}
                  </Badge>
                </div>
              </div>
              
              <h3 className="text-base sm:text-lg font-bold text-gray-900 mb-2 sm:mb-2 group-hover:bg-gradient-to-r group-hover:from-purple-600 group-hover:to-pink-600 group-hover:bg-clip-text group-hover:text-transparent transition-all duration-300 leading-tight text-center sm:text-left">
                {content.title}
              </h3>

              {content.content && <p className="text-gray-700 mb-3 text-sm sm:text-base leading-relaxed text-center sm:text-left">{content.content}</p>}

              {content.image && <div className="mb-3 sm:mb-4 rounded-lg overflow-hidden shadow-md flex justify-center">
                  <img src={`https://images.unsplash.com/${content.image}?w=${isMobile ? '400' : '600'}&h=${isMobile ? '250' : '400'}&fit=crop`} alt="Fun content" className="w-full h-48 sm:h-64 object-cover group-hover:scale-105 transition-transform duration-300 max-w-md" />
                </div>}

              {content.poll && <div className="mb-3 sm:mb-4 space-y-2">
                  <h4 className="font-semibold text-gray-800 text-sm sm:text-base text-center sm:text-left">{content.poll.question}</h4>
                  {content.poll.options.map((option, optionIndex) => {
                const percentage = option.votes / content.poll.totalVotes * 100;
                const isSelected = selectedPoll[content.id] === optionIndex.toString();
                return <button key={optionIndex} onClick={() => onPollVote(content.id, optionIndex)} className={`w-full p-2 sm:p-3 rounded-lg border transition-all duration-300 hover:scale-105 transform touch-manipulation ${isSelected ? 'bg-gradient-to-r from-purple-100 to-pink-100 border-purple-300' : 'bg-white/80 border-gray-200 hover:bg-white'}`}>
                        <div className="flex justify-between items-center mb-1">
                          <span className="text-xs sm:text-sm font-medium text-left">{option.text}</span>
                          <span className="text-xs text-gray-500">{option.votes} kura</span>
                        </div>
                        <div className="w-full bg-gray-200 rounded-full h-1.5 sm:h-2">
                          <div className="bg-gradient-to-r from-purple-500 to-pink-500 h-1.5 sm:h-2 rounded-full transition-all duration-500" style={{
                      width: `${percentage}%`
                    }}></div>
                        </div>
                      </button>;
              })}
                </div>}

              <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between pt-3 border-t border-gray-100 space-y-3 sm:space-y-0">
                <div className="flex items-center justify-center sm:justify-start space-x-3 sm:space-x-4 overflow-x-auto">
                  {Object.entries(content.reactions).map(([reaction, count]) => <button key={reaction} onClick={() => onReaction(content.id, reaction)} className="flex items-center space-x-1 text-xs sm:text-sm text-gray-500 hover:text-purple-600 transition-colors duration-200 hover:scale-110 transform touch-manipulation min-w-0 flex-shrink-0">
                      <span className="text-sm sm:text-base">{reactionEmojis[reaction as keyof typeof reactionEmojis]}</span>
                      <span className="font-medium">{count}</span>
                    </button>)}
                </div>
                
                <div className="flex items-center justify-center sm:justify-end space-x-4 sm:space-x-3">
                  <button className="flex items-center space-x-1 text-xs sm:text-sm text-gray-500 hover:text-purple-600 transition-colors duration-200 hover:scale-110 transform touch-manipulation">
                    <MessageCircle className="h-3 w-3 sm:h-4 sm:w-4" />
                    <span>{content.comments}</span>
                  </button>
                  <button onClick={() => onShare(content.id, content.title)} className="flex items-center space-x-1 text-xs sm:text-sm text-gray-500 hover:text-purple-600 transition-colors duration-200 hover:scale-110 transform touch-manipulation">
                    <Share className="h-3 w-3 sm:h-4 sm:w-4" />
                    <span>Share</span>
                  </button>
                </div>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>;
};