
import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible";
import { ChevronDown, HelpCircle } from "lucide-react";

export const HelpCenter = () => {
  const [openItems, setOpenItems] = useState<number[]>([]);

  const toggleItem = (index: number) => {
    setOpenItems(prev => 
      prev.includes(index) 
        ? prev.filter(i => i !== index)
        : [...prev, index]
    );
  };

  const faqItems = [
    {
      question: "How do I upload study materials?",
      answer: "Go to the Study Materials section and click 'Upload Resource'. You can upload notes, past papers, and other academic materials. Make sure to select the correct course and year."
    },
    {
      question: "How do I find hostels near UDSM?",
      answer: "Visit the Hostels section to browse available accommodations. You can filter by price, location, and amenities. Contact hostel owners directly through the provided contact information."
    },
    {
      question: "How does the marketplace work?",
      answer: "The marketplace allows you to buy and sell items with fellow students. Click 'Sell Item' to list something, or browse existing items. All transactions are handled directly between students."
    },
    {
      question: "How do I join study groups?",
      answer: "Check the Forum section for study group announcements. You can also create your own study group by posting in the relevant course category."
    },
    {
      question: "How do I reset my password?",
      answer: "Go to Settings > Account > Change Password. If you've forgotten your password, use the 'Forgot Password' link on the login page."
    },
    {
      question: "How do I enable notifications?",
      answer: "Go to Settings > Notifications and toggle the options you want. You can enable push notifications, email notifications, and forum updates."
    },
    {
      question: "Can I edit my profile information?",
      answer: "Yes! Go to Profile > Edit Profile to update your personal information, course details, and profile picture."
    }
  ];

  return (
    <Card className="shadow-xl border-0 bg-white/80 backdrop-blur-sm">
      <CardHeader>
        <CardTitle className="flex items-center space-x-2">
          <HelpCircle className="h-5 w-5 text-blue-500" />
          <span>Help Center</span>
        </CardTitle>
        <CardDescription>Find answers to common questions</CardDescription>
      </CardHeader>
      <CardContent className="space-y-3">
        {faqItems.map((item, index) => (
          <Collapsible key={index} open={openItems.includes(index)}>
            <CollapsibleTrigger
              onClick={() => toggleItem(index)}
              className="flex items-center justify-between w-full p-3 bg-gradient-to-r from-gray-50 to-blue-50 rounded-lg hover:from-blue-50 hover:to-purple-50 transition-all duration-300 text-left"
            >
              <span className="font-medium text-gray-800">{item.question}</span>
              <ChevronDown 
                className={`h-4 w-4 text-gray-500 transition-transform duration-300 ${
                  openItems.includes(index) ? 'rotate-180' : ''
                }`} 
              />
            </CollapsibleTrigger>
            <CollapsibleContent className="px-3 pb-3">
              <div className="pt-2 text-gray-600 text-sm leading-relaxed">
                {item.answer}
              </div>
            </CollapsibleContent>
          </Collapsible>
        ))}
      </CardContent>
    </Card>
  );
};
