import { Card, CardContent, CardFooter, CardHeader } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { MessageCircle, Calendar, MapPin, Eye } from "lucide-react";
import { useState } from "react";

interface MarketplaceCardProps {
  item: {
    id: string;
    title: string;
    description: string | null;
    price: number;
    location: string | null;
    condition: string | null;
    status: string;
    images: string[] | null;
    created_at: string;
    user_id: string;
    contact_info: any;
  };
  seller?: {
    full_name: string | null;
    avatar_url: string | null;
  };
}

const MarketplaceCard = ({ item, seller }: MarketplaceCardProps) => {
  const [imageError, setImageError] = useState(false);

  const formatTimeAgo = (date: string) => {
    const now = new Date();
    const past = new Date(date);
    const diffInSeconds = Math.floor((now.getTime() - past.getTime()) / 1000);

    if (diffInSeconds < 60) return 'Just now';
    if (diffInSeconds < 3600) return `${Math.floor(diffInSeconds / 60)}m ago`;
    if (diffInSeconds < 86400) return `${Math.floor(diffInSeconds / 3600)}h ago`;
    if (diffInSeconds < 604800) return `${Math.floor(diffInSeconds / 86400)}d ago`;
    return past.toLocaleDateString();
  };

  const handleContact = () => {
    if (item.contact_info?.whatsapp) {
      window.open(`https://wa.me/${item.contact_info.whatsapp}`, '_blank');
    } else if (item.contact_info?.phone) {
      window.open(`tel:${item.contact_info.phone}`, '_blank');
    }
  };

  const getImageUrl = (imagePath: string) => {
    if (!imagePath) return '/placeholder.svg';
    
    // If it's already a full URL, return as is
    if (imagePath.startsWith('http')) return imagePath;
    
    // Otherwise construct Supabase storage URL
    return `https://xjkrbdnejjmvgbnxfpbj.supabase.co/storage/v1/object/public/marketplace_photos/${imagePath}`;
  };

  const primaryImage = item.images && item.images.length > 0 ? item.images[0] : null;

  return (
    <Card className="hover:shadow-lg transition-shadow duration-300 overflow-hidden">
      {/* Image */}
      <div className="aspect-video bg-gray-100 relative overflow-hidden">
        {primaryImage && !imageError ? (
          <img
            src={getImageUrl(primaryImage)}
            alt={item.title}
            className="w-full h-full object-cover"
            onError={() => setImageError(true)}
          />
        ) : (
          <div className="w-full h-full flex items-center justify-center bg-gray-200">
            <span className="text-gray-400 text-sm">No image</span>
          </div>
        )}
        
        {/* Status Badge */}
        <div className="absolute top-2 right-2">
          <Badge 
            variant={item.status === 'available' ? 'default' : 'secondary'}
            className="text-xs"
          >
            {item.status}
          </Badge>
        </div>

        {/* Price Badge */}
        <div className="absolute bottom-2 left-2">
          <Badge className="bg-green-600 text-white text-sm font-bold">
            TSh {item.price.toLocaleString()}
          </Badge>
        </div>
      </div>

      <CardHeader className="pb-3">
        <h3 className="font-semibold text-lg text-gray-900 line-clamp-2">
          {item.title}
        </h3>
        
        {item.description && (
          <p className="text-gray-600 text-sm line-clamp-2">
            {item.description}
          </p>
        )}

        <div className="flex items-center space-x-2 mt-2">
          {item.condition && (
            <Badge variant="outline" className="text-xs">
              {item.condition}
            </Badge>
          )}
          {item.location && (
            <div className="flex items-center text-xs text-gray-500">
              <MapPin className="h-3 w-3 mr-1" />
              {item.location}
            </div>
          )}
        </div>
      </CardHeader>

      <CardFooter className="pt-3 border-t">
        <div className="flex items-center justify-between w-full">
          <div className="flex items-center space-x-2">
            <Avatar className="h-6 w-6">
              <AvatarImage src={seller?.avatar_url || "/placeholder.svg"} />
              <AvatarFallback className="text-xs">
                {seller?.full_name?.charAt(0) || 'S'}
              </AvatarFallback>
            </Avatar>
            <div className="flex flex-col">
              <span className="text-sm text-gray-600">
                {seller?.full_name || 'Anonymous'}
              </span>
              <div className="flex items-center text-xs text-gray-500">
                <Calendar className="h-3 w-3 mr-1" />
                {formatTimeAgo(item.created_at)}
              </div>
            </div>
          </div>
          
          <Button
            onClick={handleContact}
            size="sm"
            className="bg-green-600 hover:bg-green-700"
            disabled={!item.contact_info?.whatsapp && !item.contact_info?.phone}
          >
            <MessageCircle className="h-4 w-4 mr-1" />
            Contact
          </Button>
        </div>
      </CardFooter>
    </Card>
  );
};

export default MarketplaceCard;
