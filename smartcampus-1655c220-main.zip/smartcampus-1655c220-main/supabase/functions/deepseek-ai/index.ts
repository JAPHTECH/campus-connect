import "https://deno.land/x/xhr@0.1.0/mod.ts";
import { serve } from "https://deno.land/std@0.168.0/http/server.ts";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

const DEEPSEEK_API_KEY = Deno.env.get('DEEPSEEK_API_KEY') || 'sk-4ad22e7271dc42c0ab7315f66645aed7';

serve(async (req) => {
  // Handle CORS preflight requests
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { prompt, gameType, difficulty = "medium", language = "english" } = await req.json();

    let systemPrompt = "";
    
    if (gameType === "swahili-word") {
      systemPrompt = `You are a Swahili language teacher creating word challenges. Generate a fun word puzzle using Tanzania Swahili (not Kenya Swahili). Include:
      1. A Swahili word or phrase to complete
      2. Multiple choice options (4 choices)
      3. The correct answer
      4. A brief explanation in Swahili
      5. Fun fact about the word
      Difficulty: ${difficulty}
      
      Return response as JSON with: question, choices, correctAnswer, explanation, funFact`;
    } else if (gameType === "math-puzzle") {
      systemPrompt = `You are a mathematics professor creating engaging math puzzles for university students. Create a ${difficulty} level problem with:
      1. A clear mathematical problem
      2. Step-by-step solution approach
      3. Multiple choice answers (4 options)
      4. The correct answer with explanation
      5. A helpful tip or insight
      
      Return response as JSON with: question, choices, correctAnswer, solution, tip`;
    } else if (gameType === "tanzania-trivia") {
      systemPrompt = `You are a Tanzania expert creating trivia questions about Tanzania's culture, history, geography, and traditions. Generate:
      1. An interesting question about Tanzania
      2. Four answer choices
      3. The correct answer
      4. Interesting facts about the topic
      5. Why this is important to know
      Difficulty: ${difficulty}
      
      Return response as JSON with: question, choices, correctAnswer, facts, importance`;
    } else if (gameType === "campus-quiz") {
      systemPrompt = `You are a UDSM (University of Dar es Salaam) expert creating campus-related questions. Generate:
      1. A question about UDSM campus, facilities, history, or academics
      2. Four answer choices
      3. The correct answer
      4. Additional information about the topic
      5. Campus tip or fun fact
      Difficulty: ${difficulty}
      
      Return response as JSON with: question, choices, correctAnswer, info, campusTip`;
    } else if (gameType === "generate-resources") {
      systemPrompt = `You are an academic resource finder. Based on the topic provided, suggest:
      1. 3-5 YouTube video recommendations with actual titles and creators
      2. Academic papers or books
      3. Online courses or tutorials
      4. Practice problems or exercises
      
      Return response as JSON with: videos, books, courses, exercises`;
    }

    const response = await fetch('https://api.deepseek.com/chat/completions', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${DEEPSEEK_API_KEY}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        model: 'deepseek-chat',
        messages: [
          { role: 'system', content: systemPrompt },
          { role: 'user', content: prompt }
        ],
        temperature: 0.7,
        max_tokens: 1000,
      }),
    });

    if (!response.ok) {
      throw new Error(`Deepseek API error: ${response.status}`);
    }

    const data = await response.json();
    const generatedContent = data.choices[0].message.content;

    // Try to parse as JSON, fallback to text
    let result;
    try {
      result = JSON.parse(generatedContent);
    } catch {
      result = { content: generatedContent };
    }

    return new Response(JSON.stringify({ result }), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  } catch (error) {
    console.error('Error in deepseek-ai function:', error);
    return new Response(JSON.stringify({ error: error.message }), {
      status: 500,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  }
});