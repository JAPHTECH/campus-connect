import { createClient } from 'https://esm.sh/@supabase/supabase-js@2.53.0';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

const supabaseUrl = 'https://jonaokelbczvhqkrslel.supabase.co';
const supabaseKey = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImpvbmFva2VsYmN6dmhxa3JzbGVsIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTM2OTg4MzksImV4cCI6MjA2OTI3NDgzOX0.3nmlRGPvCJiL2nknvHZ5rb1O7qYlP87t25MlXdlYwEo';

const supabase = createClient(supabaseUrl, supabaseKey);

Deno.serve(async (req) => {
  // Handle CORS preflight requests
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    console.log('Fetching news from UDSM website...');
    
    // Fetch the UDSM website
    const response = await fetch('https://www.udsm.ac.tz/');
    
    if (!response.ok) {
      throw new Error(`Failed to fetch UDSM website: ${response.status}`);
    }
    
    const html = await response.text();
    console.log('Successfully fetched UDSM website');
    
    // Simple regex to extract news items (this is a basic implementation)
    // In a real scenario, you might want to use a proper HTML parser
    const newsPattern = /<h[2-4][^>]*>([^<]+)<\/h[2-4]>/gi;
    const linkPattern = /<a[^>]+href="([^"]+)"[^>]*>([^<]+)<\/a>/gi;
    
    const newsItems = [];
    let match;
    
    // Extract headlines
    while ((match = newsPattern.exec(html)) !== null) {
      const title = match[1].trim();
      
      // Skip if title is too short or contains common navigation words
      if (title.length > 10 && 
          !title.toLowerCase().includes('menu') && 
          !title.toLowerCase().includes('home') &&
          !title.toLowerCase().includes('about')) {
        
        // Try to find a corresponding link
        let url = null;
        const linkMatch = html.match(new RegExp(`<a[^>]+href="([^"]+)"[^>]*>${title}`, 'i'));
        if (linkMatch) {
          url = linkMatch[1].startsWith('http') ? linkMatch[1] : `https://www.udsm.ac.tz${linkMatch[1]}`;
        }
        
        newsItems.push({
          title,
          url,
          published_date: new Date(),
          content: null
        });
        
        if (newsItems.length >= 5) break; // Limit to 5 items
      }
    }
    
    console.log(`Extracted ${newsItems.length} news items`);
    
    // Clear old news (keep only last 10 items)
    const { data: oldNews } = await supabase
      .from('udsm_news')
      .select('id')
      .order('created_at', { ascending: false })
      .limit(10);
    
    if (oldNews && oldNews.length > 0) {
      await supabase
        .from('udsm_news')
        .delete()
        .not('id', 'in', `(${oldNews.map(n => `'${n.id}'`).join(',')})`);
    }
    
    // Insert new news items
    if (newsItems.length > 0) {
      const { error: insertError } = await supabase
        .from('udsm_news')
        .insert(newsItems);
      
      if (insertError) {
        console.error('Error inserting news:', insertError);
        throw insertError;
      }
      
      console.log('Successfully inserted news items');
    }
    
    return new Response(
      JSON.stringify({ 
        success: true, 
        message: `Fetched and stored ${newsItems.length} news items`,
        items: newsItems 
      }),
      { 
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        status: 200 
      }
    );
    
  } catch (error) {
    console.error('Error in news fetcher:', error);
    return new Response(
      JSON.stringify({ 
        success: false, 
        error: error.message 
      }),
      { 
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        status: 500 
      }
    );
  }
});
