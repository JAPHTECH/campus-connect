
import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

interface DriveFile {
  id: string;
  name: string;
  mimeType: string;
  createdTime: string;
  modifiedTime: string;
  size?: string;
  webViewLink: string;
  webContentLink?: string;
  owners?: Array<{
    displayName: string;
    photoLink?: string;
    emailAddress: string;
  }>;
  description?: string;
}

serve(async (req) => {
  // Handle CORS preflight requests
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { folderId, searchQuery, searchInFolder } = await req.json();
    
    const apiKey = Deno.env.get('GOOGLE_DRIVE_API_KEY');
    if (!apiKey) {
      console.error('Google Drive API key not configured');
      return new Response(
        JSON.stringify({ error: 'Google Drive API not configured' }),
        { 
          status: 500, 
          headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
        }
      );
    }

    let driveUrl: string;
    
    if (searchQuery) {
      // Perform search across Google Drive
      console.log('Performing search for:', searchQuery);
      
      // Build search query - search by name and description
      let query = `name contains '${searchQuery.replace(/'/g, "\\'")}' or fullText contains '${searchQuery.replace(/'/g, "\\'")}'`;
      
      // If searchInFolder is provided, limit search to that folder and its subfolders
      if (searchInFolder) {
        query = `(${query}) and ('${searchInFolder}' in parents or parents in '${searchInFolder}')`;
      }
      
      driveUrl = `https://www.googleapis.com/drive/v3/files?q=${encodeURIComponent(query)}&fields=files(id,name,mimeType,createdTime,modifiedTime,size,webViewLink,webContentLink,owners,description,parents)&key=${apiKey}&pageSize=50`;
    } else if (folderId) {
      // Fetch files from specific folder
      console.log('Fetching files from folder:', folderId);
      driveUrl = `https://www.googleapis.com/drive/v3/files?q='${folderId}'+in+parents&fields=files(id,name,mimeType,createdTime,modifiedTime,size,webViewLink,webContentLink,owners,description)&key=${apiKey}`;
    } else {
      return new Response(
        JSON.stringify({ error: 'Either folderId or searchQuery is required' }),
        { 
          status: 400, 
          headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
        }
      );
    }
    
    console.log('Fetching from Google Drive:', driveUrl);
    
    const response = await fetch(driveUrl);
    
    if (!response.ok) {
      const errorData = await response.text();
      console.error('Google Drive API error:', response.status, errorData);
      return new Response(
        JSON.stringify({ 
          error: 'Failed to fetch files from Google Drive',
          details: errorData,
          status: response.status
        }),
        { 
          status: response.status, 
          headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
        }
      );
    }

    const data = await response.json();
    console.log('Google Drive response:', data);

    // Transform the data to match our interface
    const files: DriveFile[] = data.files?.map((file: any) => ({
      id: file.id,
      name: file.name,
      mimeType: file.mimeType,
      createdTime: file.createdTime,
      modifiedTime: file.modifiedTime,
      size: file.size,
      webViewLink: file.webViewLink,
      webContentLink: file.webContentLink,
      owners: file.owners,
      description: file.description
    })) || [];

    return new Response(
      JSON.stringify({ files }),
      { 
        headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
      }
    );

  } catch (error) {
    console.error('Error in google-drive function:', error);
    return new Response(
      JSON.stringify({ 
        error: 'Internal server error',
        details: error.message 
      }),
      { 
        status: 500, 
        headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
      }
    );
  }
});
