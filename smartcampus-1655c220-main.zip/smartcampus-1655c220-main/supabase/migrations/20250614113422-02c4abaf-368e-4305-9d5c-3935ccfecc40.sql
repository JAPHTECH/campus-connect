
-- Create the resources_files storage bucket
INSERT INTO storage.buckets (id, name, public)
VALUES ('resources_files', 'resources_files', true);

-- Create policy to allow authenticated users to upload files
CREATE POLICY "Allow authenticated users to upload files" ON storage.objects
FOR INSERT WITH CHECK (bucket_id = 'resources_files' AND auth.role() = 'authenticated');

-- Create policy to allow authenticated users to view files
CREATE POLICY "Allow authenticated users to view files" ON storage.objects
FOR SELECT USING (bucket_id = 'resources_files' AND auth.role() = 'authenticated');

-- Create policy to allow users to update their own files
CREATE POLICY "Allow users to update their own files" ON storage.objects
FOR UPDATE USING (bucket_id = 'resources_files' AND auth.uid()::text = (storage.foldername(name))[1]);

-- Create policy to allow users to delete their own files  
CREATE POLICY "Allow users to delete their own files" ON storage.objects
FOR DELETE USING (bucket_id = 'resources_files' AND auth.uid()::text = (storage.foldername(name))[1]);
