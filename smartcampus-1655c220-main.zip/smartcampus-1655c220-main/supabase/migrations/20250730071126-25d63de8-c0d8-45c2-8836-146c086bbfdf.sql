-- Add foreign key relationship between marketplace_items and profiles
ALTER TABLE public.marketplace_items 
ADD CONSTRAINT marketplace_items_user_id_fkey 
FOREIGN KEY (user_id) REFERENCES public.profiles(id) ON DELETE CASCADE;

-- Create a table for UDSM news
CREATE TABLE public.udsm_news (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  title TEXT NOT NULL,
  content TEXT,
  url TEXT,
  published_date TIMESTAMP WITH TIME ZONE,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable RLS for news
ALTER TABLE public.udsm_news ENABLE ROW LEVEL SECURITY;

-- Create policy for news (public read)
CREATE POLICY "News is viewable by everyone" 
ON public.udsm_news 
FOR SELECT 
USING (true);

-- Add trigger for updated_at
CREATE TRIGGER update_udsm_news_updated_at
BEFORE UPDATE ON public.udsm_news
FOR EACH ROW
EXECUTE FUNCTION public.update_updated_at_column();